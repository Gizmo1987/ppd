<?php

$config['logs_file_path'] = "http://127.0.0.1/logs/RA.log";
$config['last_commands_first'] = true;
$config['enable_wowhead_links'] = true;

