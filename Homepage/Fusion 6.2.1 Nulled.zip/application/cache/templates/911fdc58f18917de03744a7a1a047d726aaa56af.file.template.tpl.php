<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:55:11
         compiled from "application\themes\burning_theme\template.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2329454fdfa9f0fd274-12144810%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '911fdc58f18917de03744a7a1a047d726aaa56af' => 
    array (
      0 => 'application\\themes\\burning_theme\\template.tpl',
      1 => 1349043551,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2329454fdfa9f0fd274-12144810',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'head' => 0,
    'modals' => 0,
    'menu_top' => 0,
    'menu_1' => 0,
    'serverName' => 0,
    'menu_side' => 0,
    'menu_2' => 0,
    'image_path' => 0,
    'sideboxes' => 0,
    'sidebox' => 0,
    'show_slider' => 0,
    'slider' => 0,
    'image' => 0,
    'page' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdfa9f13f441_77745398',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdfa9f13f441_77745398')) {function content_54fdfa9f13f441_77745398($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['head']->value;?>

	<body>
		<!--[if lte IE 8]>
			<style type="text/css">
				body {
					background-image:url(images/bg.jpg);
					background-position:top center;
				}
			</style>
		<![endif]-->
		<section id="wrapper">
			<?php echo $_smarty_tpl->tpl_vars['modals']->value;?>

			<ul id="top_menu">
				<?php  $_smarty_tpl->tpl_vars['menu_1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu_top']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_1']->key => $_smarty_tpl->tpl_vars['menu_1']->value){
$_smarty_tpl->tpl_vars['menu_1']->_loop = true;
?>
					<li><a <?php echo $_smarty_tpl->tpl_vars['menu_1']->value['link'];?>
><?php echo $_smarty_tpl->tpl_vars['menu_1']->value['name'];?>
<p></p></a><span></span></li>
				<?php } ?>
			</ul>
            
            	<a id="server-logo" href="./" title=""><!--<?php echo $_smarty_tpl->tpl_vars['serverName']->value;?>
--></a>
            	
			<div id="main">
				<aside id="left">
					<article>
						<ul id="left_menu">
							<?php  $_smarty_tpl->tpl_vars['menu_2'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_2']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu_side']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_2']->key => $_smarty_tpl->tpl_vars['menu_2']->value){
$_smarty_tpl->tpl_vars['menu_2']->_loop = true;
?>
								<li><a <?php echo $_smarty_tpl->tpl_vars['menu_2']->value['link'];?>
><img src="<?php echo $_smarty_tpl->tpl_vars['image_path']->value;?>
bullet.png"><?php echo $_smarty_tpl->tpl_vars['menu_2']->value['name'];?>
</a></li>
							<?php } ?>
						</ul>
					</article>

					<?php  $_smarty_tpl->tpl_vars['sidebox'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['sidebox']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sideboxes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['sidebox']->key => $_smarty_tpl->tpl_vars['sidebox']->value){
$_smarty_tpl->tpl_vars['sidebox']->_loop = true;
?>
						<article>
							<h1 class="top"><p><?php echo $_smarty_tpl->tpl_vars['sidebox']->value['name'];?>
</p></h1>
							<section class="body">
								<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['data'];?>

							</section>
						</article>
					<?php } ?>                     
                        
				</aside>

				<aside id="right">
					<section id="slider_bg" <?php if (!$_smarty_tpl->tpl_vars['show_slider']->value){?>style="display:none;"<?php }?>>
						<div id="slider">
							<?php  $_smarty_tpl->tpl_vars['image'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['image']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['slider']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['image']->key => $_smarty_tpl->tpl_vars['image']->value){
$_smarty_tpl->tpl_vars['image']->_loop = true;
?>
								<a href="<?php echo $_smarty_tpl->tpl_vars['image']->value['link'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['image']->value['image'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['image']->value['text'];?>
"/></a>
							<?php } ?>
						</div>
					</section>
					<div class="ornament-bar"></div>
					<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

				</aside>

				<div class="clear"></div>
			</div>
			<footer>
             	<a href="http://evil.duloclan.com" id="evil-logo" target="_blank" title="Design by EvilSystem"><p></p><span></span></a>
				<a href="http://raxezdev.com/fusioncms" id="fcms-logo" target="_blank"><p></p><span></span></a>
				<h3>Unknown WoW &copy; Copyright 2012 </h3>
			</footer>
		</section>
	</body>
</html><?php }} ?>