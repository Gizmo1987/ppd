<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:44:14
         compiled from "application\modules\error\views\error.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2835654fdf80e951837-03958769%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6523f8ad5b86eb79a4fe20eb0b802d0ad5b83184' => 
    array (
      0 => 'application\\modules\\error\\views\\error.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2835654fdf80e951837-03958769',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'is404' => 0,
    'errorMessage' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf80e9a6fc3_23081808',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf80e9a6fc3_23081808')) {function content_54fdf80e9a6fc3_23081808($_smarty_tpl) {?><?php if (isset($_smarty_tpl->tpl_vars['is404']->value)&&$_smarty_tpl->tpl_vars['is404']->value){?>
	<center style='margin:10px;font-weight:bold;'><?php echo lang("404_long","error");?>
</center>
<?php }else{ ?>
	<center style='margin:10px;font-weight:bold;'><?php echo $_smarty_tpl->tpl_vars['errorMessage']->value;?>
</center>
<?php }?><?php }} ?>