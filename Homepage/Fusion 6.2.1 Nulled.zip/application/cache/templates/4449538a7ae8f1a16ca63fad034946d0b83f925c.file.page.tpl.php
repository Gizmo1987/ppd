<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:43:29
         compiled from "application\themes\default\views\page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:437354fdf7e1ae1998-80935353%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4449538a7ae8f1a16ca63fad034946d0b83f925c' => 
    array (
      0 => 'application\\themes\\default\\views\\page.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '437354fdf7e1ae1998-80935353',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf7e1ae7ff2_39265469',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf7e1ae7ff2_39265469')) {function content_54fdf7e1ae7ff2_39265469($_smarty_tpl) {?><article>
	<h1 class="top"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</h1>
	<section class="body">
		<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

	</section>
</article><?php }} ?>