<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:43:38
         compiled from "application\modules\tooltip\views\tooltip.tpl" */ ?>
<?php /*%%SmartyHeaderCode:443854fdf7eae57c44-91441097%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1fb206cb01baff7f682aaea9ad397e0212bd3d18' => 
    array (
      0 => 'application\\modules\\tooltip\\views\\tooltip.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '443854fdf7eae57c44-91441097',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'item' => 0,
    'attribute' => 0,
    'spell' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf7eb0410d0_80474185',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf7eb0410d0_80474185')) {function content_54fdf7eb0410d0_80474185($_smarty_tpl) {?><div style="max-width:350px;">
<span class='q<?php echo $_smarty_tpl->tpl_vars['item']->value['quality'];?>
' style='font-size: 16px'><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</span><br />

<?php if ($_smarty_tpl->tpl_vars['item']->value['bind']){?><?php echo $_smarty_tpl->tpl_vars['item']->value['bind'];?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['unique']){?><?php echo $_smarty_tpl->tpl_vars['item']->value['unique'];?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['slot']){?><div style='float:left;'><?php echo $_smarty_tpl->tpl_vars['item']->value['slot'];?>
</div><?php }?>
<div style='float:right;'><?php echo $_smarty_tpl->tpl_vars['item']->value['type'];?>
</div>
<div style="clear:both;"></div>
<?php if ($_smarty_tpl->tpl_vars['item']->value['armor']){?><?php echo $_smarty_tpl->tpl_vars['item']->value['armor'];?>
 <?php echo lang("armor","item");?>
<br /><?php }?>

<?php if ($_smarty_tpl->tpl_vars['item']->value['damage_min']){?>
	<div style='float:left;'><?php echo $_smarty_tpl->tpl_vars['item']->value['damage_min'];?>
 - <?php echo $_smarty_tpl->tpl_vars['item']->value['damage_max'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['damage_type'];?>
 <?php echo lang("damage","item");?>
</div>
	<div style='float:right;margin-left:15px;'><?php echo lang("speed","wow_tooltip");?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['speed'];?>
</div><br />
	(<?php echo $_smarty_tpl->tpl_vars['item']->value['dps'];?>
 <?php echo lang("dps","item");?>
)<br />
<?php }?>

<?php if (count($_smarty_tpl->tpl_vars['item']->value['attributes']['regular'])>0){?>
	<?php  $_smarty_tpl->tpl_vars['attribute'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['attribute']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value['attributes']['regular']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['attribute']->key => $_smarty_tpl->tpl_vars['attribute']->value){
$_smarty_tpl->tpl_vars['attribute']->_loop = true;
?>
		<?php echo $_smarty_tpl->tpl_vars['attribute']->value['text'];?>

	<?php } ?>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['item']->value['holy_res']){?>+ <?php echo $_smarty_tpl->tpl_vars['item']->value['holy_res'];?>
 <?php echo lang("holy","item");?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['nature_res']){?>+ <?php echo $_smarty_tpl->tpl_vars['item']->value['nature_res'];?>
 <?php echo lang("nature","item");?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['fire_res']){?>+ <?php echo $_smarty_tpl->tpl_vars['item']->value['fire_res'];?>
 <?php echo lang("fire","item");?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['frost_res']){?>+ <?php echo $_smarty_tpl->tpl_vars['item']->value['frost_res'];?>
 <?php echo lang("frost","item");?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['shadow_res']){?>+ <?php echo $_smarty_tpl->tpl_vars['item']->value['shadow_res'];?>
 <?php echo lang("shadow","item");?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['arcane_res']){?>+ <?php echo $_smarty_tpl->tpl_vars['item']->value['arcane_res'];?>
 <?php echo lang("arcane","item");?>
<br /><?php }?>

<?php if ($_smarty_tpl->tpl_vars['item']->value['sockets']){?><?php echo $_smarty_tpl->tpl_vars['item']->value['sockets'];?>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['item']->value['durability']){?><?php echo lang("durability","item");?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['durability'];?>
 / <?php echo $_smarty_tpl->tpl_vars['item']->value['durability'];?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['required']){?><?php echo lang("requires_level","item");?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['required'];?>
<br /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['level']){?><?php echo lang("item_level","item");?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['level'];?>
<br /><?php }?>

<?php if (count($_smarty_tpl->tpl_vars['item']->value['attributes']['spells'])>0){?>
	<?php  $_smarty_tpl->tpl_vars['attribute'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['attribute']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value['attributes']['spells']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['attribute']->key => $_smarty_tpl->tpl_vars['attribute']->value){
$_smarty_tpl->tpl_vars['attribute']->_loop = true;
?>
		<?php echo $_smarty_tpl->tpl_vars['attribute']->value['text'];?>

	<?php } ?>
<?php }?>

<?php if (count($_smarty_tpl->tpl_vars['item']->value['spells'])>0){?>
	<?php  $_smarty_tpl->tpl_vars['spell'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['spell']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value['spells']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['spell']->key => $_smarty_tpl->tpl_vars['spell']->value){
$_smarty_tpl->tpl_vars['spell']->_loop = true;
?>
		<a class="q2" href="https://wowhead.com/?spell=<?php echo $_smarty_tpl->tpl_vars['spell']->value['id'];?>
" target="_blank">
			<?php echo $_smarty_tpl->tpl_vars['spell']->value['trigger'];?>

		
			<?php if (!strlen($_smarty_tpl->tpl_vars['spell']->value['text'])){?>
				<?php echo lang("unknown_effect","item");?>

			<?php }else{ ?>
				<?php echo $_smarty_tpl->tpl_vars['spell']->value['text'];?>

			<?php }?>
		</a>
		<br />
	<?php } ?>
<?php }?>
</div><?php }} ?>