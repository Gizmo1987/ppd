<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:47:29
         compiled from "application\modules\admin\views\cachemanager\cache.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1310454fdf8d1d27838-97602181%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e373d015a5c1e17e168958318021eff03d30f3d4' => 
    array (
      0 => 'application\\modules\\admin\\views\\cachemanager\\cache.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1310454fdf8d1d27838-97602181',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf8d1d9eda2_85707298',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf8d1d9eda2_85707298')) {function content_54fdf8d1d9eda2_85707298($_smarty_tpl) {?><script type="text/javascript">
	$(document).ready(function()
	{
		function checkIfLoaded()
		{
			if(typeof Cache != "undefined")
			{
				Cache.load();
			}
			else
			{
				setTimeout(checkIfLoaded, 50);
			}
		}

		checkIfLoaded();
	});
</script>

<section class="box big">
	<h2>Cache</h2>
	<span>
		You can manually clear cache to force database a reload of certain data. To minimize the server load, we recommended you to keep item cache intact no matter how big it becomes.
	</span>

	<ul id="cache_data">
		<li>Loading cache statistics, please wait<span style="padding:0px;display:inline;" id="loading_dots">...</li>
	</ul>

	<?php if (hasPermission("emptyCache")){?>
		<span>
			<a class="nice_button" href="javascript:void(0)" onClick="Cache.clear('all_but_item')"><b>Clear all but the item cache</b></a>&nbsp;
			<a class="nice_button" href="javascript:void(0)" onClick="Cache.clear('website')">Clear all website cache</a>&nbsp;
			<a class="nice_button" href="javascript:void(0)" onClick="Cache.clear('message')">Clear all message cache</a>&nbsp;
			<a class="nice_button" href="javascript:void(0)" onClick="Cache.clear('all')">Clear all cache</a>
		</span>
	<?php }?>
</section><?php }} ?>