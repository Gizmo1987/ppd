<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:49:08
         compiled from "application\modules\admin\views\accounts\accounts_search.tpl" */ ?>
<?php /*%%SmartyHeaderCode:555454fdf9348153f0-49556671%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e3a9198b50012eb36969c176fd125ad6bf3a4049' => 
    array (
      0 => 'application\\modules\\admin\\views\\accounts\\accounts_search.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '555454fdf9348153f0-49556671',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'auto' => 0,
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf93487a1c1_70641241',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf93487a1c1_70641241')) {function content_54fdf93487a1c1_70641241($_smarty_tpl) {?><section class="box big" id="account_articles">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_users.png"/>
		Search
	</h2>

	<form style="margin-top:0px;" onSubmit="Accounts.searchAccount(); return false;">
		<input type="text" name="search_accounts" <?php if ($_smarty_tpl->tpl_vars['auto']->value){?>value="<?php echo $_smarty_tpl->tpl_vars['data']->value['username'];?>
" <?php }?>id="search_accounts" placeholder="Search by username or email" style="width:90%;margin-right:5px;"/>
		<input type="submit" value="Search" style="display:inline;padding:8px;" />
	</form>

	<div id="form_accounts_search">
		<?php if ($_smarty_tpl->tpl_vars['auto']->value){?>
			<script type="text/javascript">
				$(document).ready(function()
				{
					function checkIfLoaded()
					{
						if(typeof Accounts != "undefined")
						{
							Accounts.getAccount(<?php echo $_smarty_tpl->tpl_vars['data']->value['id'];?>
);
						}
						else
						{
							setTimeout(checkIfLoaded, 50);
						}
					}

					checkIfLoaded();
				});
			</script>
		<?php }else{ ?>
			<!-- results -->
		<?php }?>
	</div>
</section><?php }} ?>