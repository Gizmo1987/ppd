<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:41:50
         compiled from "application\modules\sidebox_info_login\views\login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3119954fdf77e28a981-29949194%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9126188630dc4c9e3a66b406d1f23ec812d03269' => 
    array (
      0 => 'application\\modules\\sidebox_info_login\\views\\login.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3119954fdf77e28a981-29949194',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf77e29a9a5_13681015',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf77e29a9a5_13681015')) {function content_54fdf77e29a9a5_13681015($_smarty_tpl) {?><?php echo form_open('login');?>

	<center id="sidebox_login">
		<input type="text" name="login_username" id="login_username" value="" placeholder="<?php echo lang("username","sidebox_info");?>
">
		<input type="password" name="login_password" id="login_password" value="" placeholder="<?php echo lang("password","sidebox_info");?>
">
		<input type="submit" name="login_submit" value="<?php echo lang("log_in","sidebox_info");?>
">
	</center>
</form><?php }} ?>