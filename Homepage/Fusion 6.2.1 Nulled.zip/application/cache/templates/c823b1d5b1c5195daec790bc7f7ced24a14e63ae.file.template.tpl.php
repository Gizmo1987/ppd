<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:41:50
         compiled from "application\themes\default\template.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2852954fdf77e4b3d88-63993271%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c823b1d5b1c5195daec790bc7f7ced24a14e63ae' => 
    array (
      0 => 'application\\themes\\default\\template.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2852954fdf77e4b3d88-63993271',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'head' => 0,
    'modals' => 0,
    'menu_top' => 0,
    'menu_1' => 0,
    'menu_side' => 0,
    'menu_2' => 0,
    'image_path' => 0,
    'sideboxes' => 0,
    'sidebox' => 0,
    'show_slider' => 0,
    'slider' => 0,
    'image' => 0,
    'page' => 0,
    'serverName' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf77e4f1817_12431386',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf77e4f1817_12431386')) {function content_54fdf77e4f1817_12431386($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['head']->value;?>

	<body>
		<!--[if lte IE 8]>
			<style type="text/css">
				body {
					background-image:url(images/bg.jpg);
					background-position:top center;
				}
			</style>
		<![endif]-->
		<section id="wrapper">
			<?php echo $_smarty_tpl->tpl_vars['modals']->value;?>

			<header id="hand"></header>
			<ul id="top_menu">
				<?php  $_smarty_tpl->tpl_vars['menu_1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu_top']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_1']->key => $_smarty_tpl->tpl_vars['menu_1']->value){
$_smarty_tpl->tpl_vars['menu_1']->_loop = true;
?>
					<li><a <?php echo $_smarty_tpl->tpl_vars['menu_1']->value['link'];?>
><?php echo $_smarty_tpl->tpl_vars['menu_1']->value['name'];?>
</a></li>
				<?php } ?>
			</ul>
			<div id="main">
				<aside id="left">
					<article>
						<h1 class="top">Main menu</h1>
						<ul id="left_menu">
							<?php  $_smarty_tpl->tpl_vars['menu_2'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_2']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu_side']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_2']->key => $_smarty_tpl->tpl_vars['menu_2']->value){
$_smarty_tpl->tpl_vars['menu_2']->_loop = true;
?>
								<li><a <?php echo $_smarty_tpl->tpl_vars['menu_2']->value['link'];?>
><img src="<?php echo $_smarty_tpl->tpl_vars['image_path']->value;?>
bullet.png"><?php echo $_smarty_tpl->tpl_vars['menu_2']->value['name'];?>
</a></li>
							<?php } ?>
						</ul>
					</article>

					<?php  $_smarty_tpl->tpl_vars['sidebox'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['sidebox']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sideboxes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['sidebox']->key => $_smarty_tpl->tpl_vars['sidebox']->value){
$_smarty_tpl->tpl_vars['sidebox']->_loop = true;
?>
						<article>
							<h1 class="top"><?php echo $_smarty_tpl->tpl_vars['sidebox']->value['name'];?>
</h1>
							<section class="body">
								<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['data'];?>

							</section>
						</article>
					<?php } ?>
				</aside>

				<aside id="right">
					<section id="slider_bg" <?php if (!$_smarty_tpl->tpl_vars['show_slider']->value){?>style="display:none;"<?php }?>>
						<div id="slider">
							<?php  $_smarty_tpl->tpl_vars['image'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['image']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['slider']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['image']->key => $_smarty_tpl->tpl_vars['image']->value){
$_smarty_tpl->tpl_vars['image']->_loop = true;
?>
								<a href="<?php echo $_smarty_tpl->tpl_vars['image']->value['link'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['image']->value['image'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['image']->value['text'];?>
"/></a>
							<?php } ?>
						</div>
					</section>

					<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

				</aside>

				<div class="clear"></div>
			</div>
			<footer>
				<a href="http://www.fusion-hub.com" id="logo" target="_blank"></a>
				<p>&copy; Copyright <?php echo date("Y");?>
 <?php echo $_smarty_tpl->tpl_vars['serverName']->value;?>
</p>
			</footer>
		</section>
	</body>
</html><?php }} ?>