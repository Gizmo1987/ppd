<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:47:30
         compiled from "application\modules\admin\views\cachemanager\cache_data.tpl" */ ?>
<?php /*%%SmartyHeaderCode:708154fdf8d220aef1-68112167%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1d3a911a5734923dea1bb227f5a43b31a4da988a' => 
    array (
      0 => 'application\\modules\\admin\\views\\cachemanager\\cache_data.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '708154fdf8d220aef1-68112167',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'item' => 0,
    'website' => 0,
    'message' => 0,
    'total' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf8d226db18_45558579',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf8d226db18_45558579')) {function content_54fdf8d226db18_45558579($_smarty_tpl) {?><li>
	<table width="100%">
		<tr>
			<td width="50%">Item cache</td>
			<td id="row_item"><?php echo $_smarty_tpl->tpl_vars['item']->value['files'];?>
 files (<?php echo $_smarty_tpl->tpl_vars['item']->value['sizeString'];?>
)</td>
		</tr>
	</table>
</li>

<li>
	<table width="100%">
		<tr>
			<td width="50%">Website cache</td>
			<td id="row_website"><?php echo $_smarty_tpl->tpl_vars['website']->value['files'];?>
 files (<?php echo $_smarty_tpl->tpl_vars['website']->value['sizeString'];?>
)</td>
		</tr>
	</table>
</li>

<li>
	<table width="100%">
		<tr>
			<td width="50%">Private message cache</td>
			<td id="row_message"><?php echo $_smarty_tpl->tpl_vars['message']->value['files'];?>
 files (<?php echo $_smarty_tpl->tpl_vars['message']->value['sizeString'];?>
)</td>
		</tr>
	</table>
</li>

<li>
	<table width="100%">
		<tr>
			<td width="50%"><b>Total</b></td>
			<td id="row_total"><b><?php echo $_smarty_tpl->tpl_vars['total']->value['files'];?>
 files (<?php echo $_smarty_tpl->tpl_vars['total']->value['size'];?>
)</b></td>
		</tr>
	</table>
</li><?php }} ?>