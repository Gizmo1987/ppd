<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:48:50
         compiled from "application\modules\ucp\views\avatar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:590854fdf922d63161-84645059%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e60a422941807b63b19eea70ad4a6a9aed5a9bb7' => 
    array (
      0 => 'application\\modules\\ucp\\views\\avatar.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '590854fdf922d63161-84645059',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'email' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf922db57c2_41071205',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf922db57c2_41071205')) {function content_54fdf922db57c2_41071205($_smarty_tpl) {?><section id="avatar_page">
	<h2><?php echo lang("make_use","ucp");?>
 <a href="http://gravatar.com" target="_blank">Gravatar</a> <?php echo lang("provides_way","ucp");?>
</h2>
	<br />
	<h3><?php echo lang("to_change","ucp");?>
 <a href="http://gravatar.com/site/signup/" target="_blank"><?php echo lang("sign_up_for","ucp");?>
</a> <?php echo lang("or","ucp");?>
 <a href="http://gravatar.com/site/login/" target="_blank"><?php echo lang("log_into","ucp");?>
</a> Gravatar <?php echo lang("using_email","ucp");?>
</h3>

	<center>
		<?php echo $_smarty_tpl->tpl_vars['email']->value;?>

	</center>
</section><?php }} ?>