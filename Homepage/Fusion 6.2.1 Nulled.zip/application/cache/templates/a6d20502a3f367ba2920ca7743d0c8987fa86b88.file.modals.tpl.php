<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:41:50
         compiled from "application\themes\default\views\modals.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2280854fdf77e4896c5-17617415%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a6d20502a3f367ba2920ca7743d0c8987fa86b88' => 
    array (
      0 => 'application\\themes\\default\\views\\modals.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2280854fdf77e4896c5-17617415',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'vote_reminder' => 0,
    'url' => 0,
    'vote_reminder_image' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf77e4941e4_88116075',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf77e4941e4_88116075')) {function content_54fdf77e4941e4_88116075($_smarty_tpl) {?><div id="popup_bg"></div>

<!-- confirm box -->
<div id="confirm" class="popup">
	<h1 class="popup_question" id="confirm_question"></h1>

	<div class="popup_links">
		<a href="javascript:void(0)" class="popup_button" id="confirm_button"></a>
		<a href="javascript:void(0)" class="popup_hide" id="confirm_hide" onClick="UI.hidePopup()">
			Cancel
		</a>
		<div style="clear:both;"></div>
	</div>
</div>

<!-- alert box -->
<div id="alert" class="popup">
	<h1 class="popup_message" id="alert_message"></h1>

	<div class="popup_links">
		<a href="javascript:void(0)" class="popup_button" id="alert_button">Okay</a>
		<div style="clear:both;"></div>
	</div>
</div>

<?php if ($_smarty_tpl->tpl_vars['vote_reminder']->value){?>
	<!-- Vote reminder popup -->
	<div id="vote_reminder">
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
vote">
			<img src="<?php echo $_smarty_tpl->tpl_vars['vote_reminder_image']->value;?>
" />
		</a>
	</div>
<?php }?><?php }} ?>