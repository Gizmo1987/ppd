<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:49:11
         compiled from "application\modules\admin\views\accounts\accounts_found.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1064154fdf937c69b82-67734992%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5152b061e188262fd4c887bb33b2743c0dcef92' => 
    array (
      0 => 'application\\modules\\admin\\views\\accounts\\accounts_found.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1064154fdf937c69b82-67734992',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'external_details' => 0,
    'internal_details' => 0,
    'url' => 0,
    'access_id' => 0,
    'expansions' => 0,
    'id' => 0,
    'expansion' => 0,
    'modules' => 0,
    'module' => 0,
    'name' => 0,
    'permissionName' => 0,
    'permission' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf937d39be4_91316868',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf937d39be4_91316868')) {function content_54fdf937d39be4_91316868($_smarty_tpl) {?><form onSubmit="Accounts.save(this, <?php echo $_smarty_tpl->tpl_vars['external_details']->value['id'];?>
); return false" id="submit_form">
	<label>Account</label>
	(<?php echo $_smarty_tpl->tpl_vars['external_details']->value['id'];?>
) <b><?php echo $_smarty_tpl->tpl_vars['external_details']->value['username'];?>
</b>

	<label>Last log in</label>
	<b><?php echo $_smarty_tpl->tpl_vars['external_details']->value['last_login'];?>
</b> by <b><?php echo $_smarty_tpl->tpl_vars['external_details']->value['last_ip'];?>
</b>

	<label for="vp">VP</label>
	<input type="text" id="vp" name="vp" value="<?php echo $_smarty_tpl->tpl_vars['internal_details']->value['vp'];?>
" <?php if (!hasPermission("editAccounts")){?>disabled="disabled"<?php }?>/>

	<label for="dp">DP</label>
	<input type="text" id="dp" name="dp" value="<?php echo $_smarty_tpl->tpl_vars['internal_details']->value['dp'];?>
" <?php if (!hasPermission("editAccounts")){?>disabled="disabled"<?php }?>/>

	<label for="nickname">Nickname</label>
	<input type="text" id="nickname" name="nickname" value="<?php echo $_smarty_tpl->tpl_vars['internal_details']->value['nickname'];?>
" <?php if (!hasPermission("editAccounts")){?>disabled="disabled"<?php }?>/>

	<label for="email">Email</label>
	<input type="text" id="email" name="email" value="<?php echo $_smarty_tpl->tpl_vars['external_details']->value['email'];?>
" <?php if (!hasPermission("editAccounts")){?>disabled="disabled"<?php }?>/>

	<label for="group">Website user group</label>
	<div style="background-color: #fff;border-radius: 5px;padding: 5px 10px;border: 1px solid #ccc;">Please assign groups at <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/groups">the group manager</a></div>

	<label for="password">Change password</label>
	<input type="text" id="password" name="password" placeholder="Enter a new password" <?php if (!hasPermission("editAccounts")){?>disabled="disabled"<?php }?>/>

	<label for="gm_level">GM level</label>
	<input type="text" id="gm_level" name="gm_level" value="<?php if (!$_smarty_tpl->tpl_vars['access_id']->value['gmlevel']){?>0<?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['access_id']->value['gmlevel'];?>
<?php }?>" <?php if (!hasPermission("editAccounts")){?>disabled="disabled"<?php }?>/>

	<label for="expansion">Expansion</label>
	<select id="expansion" name="expansion" <?php if (!hasPermission("editAccounts")){?>disabled="disabled"<?php }?>>
		<?php  $_smarty_tpl->tpl_vars['expansion'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['expansion']->_loop = false;
 $_smarty_tpl->tpl_vars['id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['expansions']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['expansion']->key => $_smarty_tpl->tpl_vars['expansion']->value){
$_smarty_tpl->tpl_vars['expansion']->_loop = true;
 $_smarty_tpl->tpl_vars['id']->value = $_smarty_tpl->tpl_vars['expansion']->key;
?>
			<option value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['external_details']->value['expansion']==$_smarty_tpl->tpl_vars['id']->value){?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['expansion']->value;?>
</option>
		<?php } ?>
	</select>

	<?php if (hasPermission("editAccounts")){?>
		<input type="submit" value="Save account" />
	<?php }?>

	<?php if (hasPermission("editPermissions")){?>

			<label data-tip="A user can be specifically allowed or denied to perform a certain action.<br />
			By setting a user permission, the value you set overrides the group roles<br />
			(example: the user group is allowed to submit comments, but you set the user<br />
			specifically not to be allowed to - then the user won't be allowed to, despite<br />
			being assigned to a group that is allowed to.)">User permissions <a>(?)</a></label>
			<div id="roles">
				<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['module']->_loop = false;
 $_smarty_tpl->tpl_vars['name'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['modules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
$_smarty_tpl->tpl_vars['module']->_loop = true;
 $_smarty_tpl->tpl_vars['name']->value = $_smarty_tpl->tpl_vars['module']->key;
?>
					<?php if ($_smarty_tpl->tpl_vars['module']->value['manifest']){?>
						<div class="role_module">
							<h3><?php echo ucfirst($_smarty_tpl->tpl_vars['module']->value['name']);?>
 <span onClick="Accounts.moduleState('arrow_<?php echo $_smarty_tpl->tpl_vars['module']->value['folderName'];?>
', '<?php echo $_smarty_tpl->tpl_vars['module']->value['folderName'];?>
')" style="float: right; padding: 0px;"><div id="arrow_<?php echo $_smarty_tpl->tpl_vars['module']->value['folderName'];?>
" class="arrow" style="cursor: pointer;">&rarr;</div></span></h3>
							<div id="<?php echo $_smarty_tpl->tpl_vars['module']->value['folderName'];?>
" style="display: none;">
								<table width="100%">
									<?php if ($_smarty_tpl->tpl_vars['module']->value['manifest']){?>
										<?php  $_smarty_tpl->tpl_vars['permission'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['permission']->_loop = false;
 $_smarty_tpl->tpl_vars['permissionName'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['module']->value['manifest']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['permission']->key => $_smarty_tpl->tpl_vars['permission']->value){
$_smarty_tpl->tpl_vars['permission']->_loop = true;
 $_smarty_tpl->tpl_vars['permissionName']->value = $_smarty_tpl->tpl_vars['permission']->key;
?>
											<tr>
												<td width="12%" style="text-align:center;">
													<select name="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['permissionName']->value;?>
" id="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['permissionName']->value;?>
" <?php if (!hasPermission("editAccounts")){?>disabled="disabled"<?php }?>>
														<option value="" selected>-</option>
														<option value="1">Allow</option>
														<option value="0">Deny</option>
													</select>
												</td>
												<td width="30%">&nbsp;&nbsp;<label for="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['permissionName']->value;?>
" style="display:inline;border:none;font-weight:bold;"><?php echo $_smarty_tpl->tpl_vars['permissionName']->value;?>
</label></td>
												<td style="font-size:10px;"><?php echo $_smarty_tpl->tpl_vars['permission']->value['description'];?>
 (default: <?php echo $_smarty_tpl->tpl_vars['permission']->value['default'] ? "allow" : "deny";?>
)</td>
											</tr>
										<?php } ?>
									<?php }?>
								</table>
							</div>
						</div>
					<?php }?>
				<?php } ?>
				<?php if (hasPermission("editAccounts")){?>
					<input type="submit" value="Save account" />
				<?php }?>
			</div>
	<?php }?>
</form><?php }} ?>