<?php /* Smarty version Smarty-3.1.8, created on 2015-03-10 20:57:33
         compiled from "application\themes\blueweb\views\page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:86054ff4cad8fcbc0-35193757%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c31098546c7545460e07aabd9f73bbef17b652ff' => 
    array (
      0 => 'application\\themes\\blueweb\\views\\page.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '86054ff4cad8fcbc0-35193757',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54ff4cad932a08_27408110',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54ff4cad932a08_27408110')) {function content_54ff4cad932a08_27408110($_smarty_tpl) {?><div class="right_box">
	<a class="right_box_top"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</a>
	<div style="padding:5px;"><?php echo $_smarty_tpl->tpl_vars['content']->value;?>
</div>
</div><?php }} ?>