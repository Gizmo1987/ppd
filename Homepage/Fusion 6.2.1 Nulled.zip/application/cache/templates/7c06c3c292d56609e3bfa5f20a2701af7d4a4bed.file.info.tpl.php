<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:43:29
         compiled from "application\modules\sidebox_info_login\views\info.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2359454fdf7e1b23257-65305840%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c06c3c292d56609e3bfa5f20a2701af7d4a4bed' => 
    array (
      0 => 'application\\modules\\sidebox_info_login\\views\\info.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2359454fdf7e1b23257-65305840',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'expansion' => 0,
    'lastIp' => 0,
    'currentIp' => 0,
    'vp' => 0,
    'dp' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf7e1b5ae49_92463517',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf7e1b5ae49_92463517')) {function content_54fdf7e1b5ae49_92463517($_smarty_tpl) {?><section class="sidebox_info">
	<table width="100%">
		<tr>
			<td width="50%"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/plugin.png" align="absmiddle" /> <?php echo lang("expansion","sidebox_info");?>
</td>
			<td>
				<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp/expansion" data-tip="Change expansion" style="float:right;margin-right:10px;">
					<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/cog.png" align="absbottom" />
				</a>
				<?php echo $_smarty_tpl->tpl_vars['expansion']->value;?>

			</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/computer_error.png" align="absmiddle" /> <?php echo lang("last_ip","sidebox_info");?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['lastIp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/computer.png" align="absmiddle" /> <?php echo lang("current_ip","sidebox_info");?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['currentIp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle" /> <?php echo lang("vp","sidebox_info");?>
</td>
			<td id="info_vp"><?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
</td>
		</tr>
		<tr>
			<td><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle" /> <?php echo lang("dp","sidebox_info");?>
</td>
			<td id="info_dp"><?php echo $_smarty_tpl->tpl_vars['dp']->value;?>
</td>
		</tr>
	</table>
	<center>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp" class="nice_button"><?php echo lang("user_panel","sidebox_info");?>
</a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
logout" class="nice_button"><?php echo lang("log_out","sidebox_info");?>
</a>
	</center>
</section><?php }} ?>