<?php /* Smarty version Smarty-3.1.8, created on 2015-03-10 20:43:55
         compiled from "application\modules\admin\views\config.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1016454ff497b8e0f46-81318474%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a54d3d67befe5bffce911e8c0f503555a47f8736' => 
    array (
      0 => 'application\\modules\\admin\\views\\config.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1016454ff497b8e0f46-81318474',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'configs' => 0,
    'title' => 0,
    'config' => 0,
    'moduleName' => 0,
    'label' => 0,
    'option' => 0,
    'value' => 0,
    'sub_option' => 0,
    'sub_label' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54ff497ba72698_46086883',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54ff497ba72698_46086883')) {function content_54ff497ba72698_46086883($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['config'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['config']->_loop = false;
 $_smarty_tpl->tpl_vars['title'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['configs']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['config']->key => $_smarty_tpl->tpl_vars['config']->value){
$_smarty_tpl->tpl_vars['config']->_loop = true;
 $_smarty_tpl->tpl_vars['title']->value = $_smarty_tpl->tpl_vars['config']->key;
?>

	<section class="box big">
		<h2><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
.php</h2>

		<?php if (array_key_exists('force_code_editor',$_smarty_tpl->tpl_vars['config']->value)&&$_smarty_tpl->tpl_vars['config']->value['force_code_editor']){?>
			<form onSubmit="Settings.submitConfigSource('<?php echo $_smarty_tpl->tpl_vars['moduleName']->value;?>
', '<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
');return false" id="advanced_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
">
				<label for="source_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
">Source code</label>

				<textarea id="source_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
" name="source_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
" rows="30" spellcheck="false"><?php echo $_smarty_tpl->tpl_vars['config']->value['source'];?>
</textarea>

				<input type="submit" value="Save config" />
			</form>
		<?php }else{ ?>
			<span>
				<a class="nice_button" href="javascript:void(0)" onClick="Settings.toggleSource('<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
', this)">Edit source code (advanced)</a>
			</span>

			<form onSubmit="Settings.submitConfigSource('<?php echo $_smarty_tpl->tpl_vars['moduleName']->value;?>
', '<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
');return false" id="advanced_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
" style="display:none;">
				<label for="source_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
">Source code</label>

				<textarea id="source_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
" name="source_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
" rows="30" spellcheck="false"><?php echo $_smarty_tpl->tpl_vars['config']->value['source'];?>
</textarea>

				<input type="submit" value="Save config" />
			</form>

			<form onSubmit="Settings.submitConfig(this, '<?php echo $_smarty_tpl->tpl_vars['moduleName']->value;?>
', '<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
');return false" id="gui_<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
">

				<?php  $_smarty_tpl->tpl_vars['option'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['option']->_loop = false;
 $_smarty_tpl->tpl_vars['label'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['config']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['option']->key => $_smarty_tpl->tpl_vars['option']->value){
$_smarty_tpl->tpl_vars['option']->_loop = true;
 $_smarty_tpl->tpl_vars['label']->value = $_smarty_tpl->tpl_vars['option']->key;
?>
					<?php if ($_smarty_tpl->tpl_vars['label']->value!="source"){?>
						<?php if (is_array($_smarty_tpl->tpl_vars['option']->value)&&ctype_digit(implode('',array_keys($_smarty_tpl->tpl_vars['option']->value)))){?>
							<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
"><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['label']->value));?>
</label>
							<input type="text" value="<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['option']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
$_smarty_tpl->tpl_vars['value']->_loop = true;
?><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
,<?php } ?>" id="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
" name="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
" />
						<?php }elseif(is_array($_smarty_tpl->tpl_vars['option']->value)){?>	
							<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
"><b><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['label']->value));?>
</b></label>
							<?php  $_smarty_tpl->tpl_vars['sub_option'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['sub_option']->_loop = false;
 $_smarty_tpl->tpl_vars['sub_label'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['option']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['sub_option']->key => $_smarty_tpl->tpl_vars['sub_option']->value){
$_smarty_tpl->tpl_vars['sub_option']->_loop = true;
 $_smarty_tpl->tpl_vars['sub_label']->value = $_smarty_tpl->tpl_vars['sub_option']->key;
?>		
								<?php if (is_array($_smarty_tpl->tpl_vars['sub_option']->value)&&ctype_digit(implode('',array_keys($_smarty_tpl->tpl_vars['sub_option']->value)))){?>
									<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
"><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['sub_label']->value));?>
</label>
									<input type="text" value="<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sub_option']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
$_smarty_tpl->tpl_vars['value']->_loop = true;
?><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
,<?php } ?>" id="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
" name="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
" />
								<?php }elseif(is_array($_smarty_tpl->tpl_vars['sub_option']->value)){?>
									<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
"><b><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['sub_label']->value));?>
</b></label>
									test
								<?php }elseif($_smarty_tpl->tpl_vars['sub_option']->value===true){?>
									<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
"><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['sub_label']->value));?>
</label>
									<select id="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
" name="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
">
										<option selected value="true">Yes</div>
										<option value="false">No</div>
									</select>
								<?php }elseif($_smarty_tpl->tpl_vars['sub_option']->value===false){?>
									<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
"><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['sub_label']->value));?>
</label>
									<select id="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
" name="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
">
										<option value="true">Yes</div>
										<option selected value="false">No</div>
									</select>
								<?php }else{ ?>
									<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
"><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['sub_label']->value));?>
</label>
									<input type="text" value="<?php echo $_smarty_tpl->tpl_vars['sub_option']->value;?>
" id="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
" name="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['sub_label']->value;?>
" />
								<?php }?>
							<?php } ?>
						<?php }elseif($_smarty_tpl->tpl_vars['option']->value===true){?>
							<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
"><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['label']->value));?>
</label>
							<select id="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
" name="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
">
								<option selected value="true">Yes</div>
								<option value="false">No</div>
							</select>
						<?php }elseif($_smarty_tpl->tpl_vars['option']->value===false){?>
							<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
"><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['label']->value));?>
</label>
							<select id="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
" name="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
">
								<option value="true">Yes</div>
								<option selected value="false">No</div>
							</select>
						<?php }else{ ?>
							<label for="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
"><?php echo ucfirst(preg_replace("/_/"," ",$_smarty_tpl->tpl_vars['label']->value));?>
</label>
							<input type="text" value="<?php echo $_smarty_tpl->tpl_vars['option']->value;?>
" id="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
" name="<?php echo $_smarty_tpl->tpl_vars['label']->value;?>
" />
						<?php }?>
					<?php }?>
				<?php } ?>

				<input type="submit" value="Save config" />
			</form>
		<?php }?>
	</section>
<?php } ?><?php }} ?>