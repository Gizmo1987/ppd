<?php /* Smarty version Smarty-3.1.8, created on 2015-03-11 00:23:04
         compiled from "application\modules\donate\views\donate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1835654ff7cd8766b29-24788286%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e32205b516dda0fca5965bf5fe0b018e63014dc4' => 
    array (
      0 => 'application\\modules\\donate\\views\\donate.tpl',
      1 => 1426029759,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1835654ff7cd8766b29-24788286',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'donate_paypal' => 0,
    'donate_paygol' => 0,
    'donate_paymentwall' => 0,
    'user_id' => 0,
    'url' => 0,
    'server_name' => 0,
    'currency' => 0,
    'key' => 0,
    'value' => 0,
    'currency_sign' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54ff7cd884fd47_87957795',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54ff7cd884fd47_87957795')) {function content_54ff7cd884fd47_87957795($_smarty_tpl) {?><div id="donate">
	<?php if ($_smarty_tpl->tpl_vars['donate_paypal']->value['use']||$_smarty_tpl->tpl_vars['donate_paygol']->value['use']||($_smarty_tpl->tpl_vars['donate_paymentwall']->value['use']||$_smarty_tpl->tpl_vars['donate_paymentwall']->value['test_mode']&&$_smarty_tpl->tpl_vars['user_id']->value==$_smarty_tpl->tpl_vars['donate_paymentwall']->value['test_user'])){?>
		<div id="donate_select">
			<?php if ($_smarty_tpl->tpl_vars['donate_paypal']->value['use']){?>
				<a href="javascript:void(0)" onClick="Donate.showPayPal(this)" class="nice_active nice_button"><?php echo lang("paypal","donate");?>
</a>
			<?php }?>
			
			<?php if ($_smarty_tpl->tpl_vars['donate_paygol']->value['use']){?>
				<a href="javascript:void(0)" onClick="Donate.showPayGol(this)" class="<?php if (!$_smarty_tpl->tpl_vars['donate_paypal']->value['use']){?>nice_active<?php }?> nice_button"><?php echo lang("paygol","donate");?>
</a>
			<?php }?>

			<?php if ($_smarty_tpl->tpl_vars['donate_paymentwall']->value['use']||($_smarty_tpl->tpl_vars['donate_paymentwall']->value['test_mode']&&$_smarty_tpl->tpl_vars['user_id']->value==$_smarty_tpl->tpl_vars['donate_paymentwall']->value['test_user'])){?>
				<a href="javascript:void(0)" onClick="Donate.showPaymentwall(this)" class="nice_button">Paymentwall</a>
			<?php }?>
		</div>

		<div class="ucp_divider"></div>

		<?php if ($_smarty_tpl->tpl_vars['donate_paypal']->value['use']){?>
		<section id="paypal_area" style="display:none;">
			<form action="https://www<?php if ($_smarty_tpl->tpl_vars['donate_paypal']->value['sandbox']){?>.sandbox<?php }?>.paypal.com/cgi-bin/webscr" method="post" class="page_form">
				<div class="right_image"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/misc/paypal_logo.png" /></div>
				<input type="hidden" name="cmd" value="_xclick" />
				<input type="hidden" name="business" value="<?php echo $_smarty_tpl->tpl_vars['donate_paypal']->value['email'];?>
" />
				<input type="hidden" name="item_name" value="<?php echo lang("donation_for","donate");?>
 <?php echo $_smarty_tpl->tpl_vars['server_name']->value;?>
" />
				<input type="hidden" name="quantity" value="1" />
				<input type="hidden" name="currency_code" value="<?php echo $_smarty_tpl->tpl_vars['currency']->value;?>
" />
				<input type="hidden" name="notify_url" value="<?php echo $_smarty_tpl->tpl_vars['donate_paypal']->value['postback_url'];?>
" />
				<input type="hidden" name="return" value="<?php echo $_smarty_tpl->tpl_vars['donate_paypal']->value['return_url'];?>
" />
				<input type="hidden" name="custom" value="<?php echo $_smarty_tpl->tpl_vars['user_id']->value;?>
" />
				
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['donate_paypal']->value['values']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
$_smarty_tpl->tpl_vars['value']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<label for="option_<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
">
						<input type="radio" name="amount" value="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" id="option_<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" <?php if (reset($_smarty_tpl->tpl_vars['donate_paypal']->value['values'])==$_smarty_tpl->tpl_vars['value']->value){?>checked="checked"<?php }?>/> <b><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
 <?php echo lang("dp","donate");?>
</b> <?php echo lang("for","donate");?>
 <b><?php echo $_smarty_tpl->tpl_vars['currency_sign']->value;?>
<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</b>
					</label>
				<?php } ?>

				<input type='submit' value='<?php echo lang("pay_paypal","donate");?>
' />
				<div class="clear"></div>
			</form>
		</section>
		<?php }?>

		<?php if ($_smarty_tpl->tpl_vars['donate_paygol']->value['use']){?>
		<section id="paygol_area" style="display:none;">
			<form action="http://www.paygol.com/micropayment/paynow_post" method="post" class="page_form">
				<div class="right_image"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/misc/paygol_logo.png" /></div>
				<input type="hidden" name="pg_custom" value="<?php echo $_smarty_tpl->tpl_vars['user_id']->value;?>
">
				<input type="hidden" name="pg_serviceid" value="<?php echo $_smarty_tpl->tpl_vars['donate_paygol']->value['service_id'];?>
">
				<input type="hidden" name="pg_currency" value="<?php echo $_smarty_tpl->tpl_vars['currency']->value;?>
">
				<input type="hidden" name="pg_name" value="<?php echo lang("donation_for","donate");?>
 <?php echo $_smarty_tpl->tpl_vars['server_name']->value;?>
">

				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['donate_paygol']->value['values']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
$_smarty_tpl->tpl_vars['value']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<label for="option_<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
">
						<input type="radio" name="pg_price" value="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" id="option_<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" <?php if (reset($_smarty_tpl->tpl_vars['donate_paygol']->value['values'])==$_smarty_tpl->tpl_vars['value']->value){?>checked="checked"<?php }?>/> <b><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
 <?php echo lang("dp","donate");?>
</b> <?php echo lang("for","donate");?>
 <b><?php echo $_smarty_tpl->tpl_vars['currency_sign']->value;?>
<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</b>
					</label>
				<?php } ?>
				<input type="hidden" name="pg_return_url" value="<?php echo $_smarty_tpl->tpl_vars['donate_paygol']->value['return_url'];?>
">
				<input type="hidden" name="pg_cancel_url" value="<?php echo $_smarty_tpl->tpl_vars['donate_paygol']->value['cancel_url'];?>
">
				<input type='submit' value='<?php echo lang("pay_paygol","donate");?>
' />
				<div class="clear"></div>
			</form>
		</section>
		<?php }?>

		<?php if ($_smarty_tpl->tpl_vars['donate_paymentwall']->value['use']||($_smarty_tpl->tpl_vars['donate_paymentwall']->value['test_mode']&&$_smarty_tpl->tpl_vars['donate_paymentwall']->value['test_user']==$_smarty_tpl->tpl_vars['user_id']->value)){?>
		<section id="paymentwall_area" style="display:none;">
			<div id="donate">
				<iframe
					src="https://wallapi.com/api/ps/?key=<?php echo $_smarty_tpl->tpl_vars['donate_paymentwall']->value['key'];?>
&uid=<?php echo $_smarty_tpl->tpl_vars['user_id']->value;?>
&widget=<?php echo $_smarty_tpl->tpl_vars['donate_paymentwall']->value['widget_code'];?>
"
					width="90%"
					style="margin-left:auto;margin-right:auto;display:block;overflow:auto;"
					height="600" 
					frameborder="0">
				</iframe>
			</div>
		</section>
		<?php }?>
	<?php }else{ ?>
		<?php echo lang("no_methods","donate");?>

	<?php }?>
</div><?php }} ?>