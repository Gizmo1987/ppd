<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 21:00:31
         compiled from "application\themes\burning_theme\modules\news\articles.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2379954fdfbdf29c0b2-18496364%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5e3803dc639e0c3c0bb7de10085ff3ebcd6c61e1' => 
    array (
      0 => 'application\\themes\\burning_theme\\modules\\news\\articles.tpl',
      1 => 1344587352,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2379954fdfbdf29c0b2-18496364',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'articles' => 0,
    'article' => 0,
    'url' => 0,
    'pagination' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdfbdf30db24_85648522',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdfbdf30db24_85648522')) {function content_54fdfbdf30db24_85648522($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['article'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['article']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['articles']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['article']->key => $_smarty_tpl->tpl_vars['article']->value){
$_smarty_tpl->tpl_vars['article']->_loop = true;
?>

	<article>
		<a <?php echo $_smarty_tpl->tpl_vars['article']->value['link'];?>
 class="top"><?php echo $_smarty_tpl->tpl_vars['article']->value['headline'];?>
</a>
		<section class="body">
			<?php if ($_smarty_tpl->tpl_vars['article']->value['avatar']){?>
				<div class="avatar">
					<img src="<?php echo $_smarty_tpl->tpl_vars['article']->value['avatar'];?>
" alt="avatar" height="120" width="120">
				</div>
			<?php }?>
			
			<?php echo $_smarty_tpl->tpl_vars['article']->value['content'];?>

			
			<div class="clear"></div>
			
			<div class="news_bottom">

				<?php if ($_smarty_tpl->tpl_vars['article']->value['comments']!=-1){?>
					<a <?php echo $_smarty_tpl->tpl_vars['article']->value['link'];?>
 class="comments_button" <?php echo $_smarty_tpl->tpl_vars['article']->value['comments_button_id'];?>
>
						Comments (<?php echo $_smarty_tpl->tpl_vars['article']->value['comments'];?>
)
					</a>
				<?php }?>
				
				Posted by <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
profile/<?php echo $_smarty_tpl->tpl_vars['article']->value['author_id'];?>
" data-tip="View profile"><?php echo $_smarty_tpl->tpl_vars['article']->value['author'];?>
</a> on <?php echo $_smarty_tpl->tpl_vars['article']->value['date'];?>

			</div>

			<div class="comments" <?php echo $_smarty_tpl->tpl_vars['article']->value['comments_id'];?>
></div>
		</section>
	</article>

<?php } ?>
<?php echo $_smarty_tpl->tpl_vars['pagination']->value;?>
<?php }} ?>