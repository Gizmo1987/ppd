<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:44:31
         compiled from "application\themes\admin\template.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2673954fdf81f714432-57801419%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd9642c7fb57aa26efa9964bbf820c54ba788998c' => 
    array (
      0 => 'application\\themes\\admin\\template.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2673954fdf81f714432-57801419',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'url' => 0,
    'extra_css' => 0,
    'cdn' => 0,
    'defaultLanguage' => 0,
    'languages' => 0,
    'language' => 0,
    'extra_js' => 0,
    'current_page' => 0,
    'nickname' => 0,
    'menu' => 0,
    'group' => 0,
    'text' => 0,
    'link' => 0,
    'page' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf81f7a85c6_83596353',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf81f7a85c6_83596353')) {function content_54fdf81f7a85c6_83596353($_smarty_tpl) {?><!DOCTYPE html>
<html>
	<head>
		<title><?php if ($_smarty_tpl->tpl_vars['title']->value){?><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
<?php }?>FusionCMS</title>

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 

		<link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/favicon.png" />
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/css/main.css" type="text/css" />
		<?php if ($_smarty_tpl->tpl_vars['extra_css']->value){?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/<?php echo $_smarty_tpl->tpl_vars['extra_css']->value;?>
" type="text/css" /><?php }?>

		<script src="<?php if ($_smarty_tpl->tpl_vars['cdn']->value){?>//html5shiv.googlecode.com/svn/trunk/html5.js<?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/html5shiv.js<?php }?>"></script>
		<script type="text/javascript" src="<?php if ($_smarty_tpl->tpl_vars['cdn']->value){?>https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js<?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/jquery.min.js<?php }?>"></script>

		<script type="text/javascript">
		
			if(!window.console)
			{
				var console = {
				
					log: function()
					{
						// Prevent stupid browsers from doing stupid things
					}
				};
			}

			function getCookie(c_name)
			{
				var i, x, y, ARRcookies = document.cookie.split(";");

				for(i = 0; i < ARRcookies.length;i++)
				{
					x = ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
					y = ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
					x = x.replace(/^\s+|\s+$/g,"");
					
					if(x == c_name)
					{
						return unescape(y);
					}
				}
			}

			var Config = {
				URL: "<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
",
				CSRF: getCookie('csrf_cookie_name'),
				isACP: true,
				defaultLanguage: "<?php echo $_smarty_tpl->tpl_vars['defaultLanguage']->value;?>
",
				languages: [ <?php  $_smarty_tpl->tpl_vars['language'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['language']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['language']->key => $_smarty_tpl->tpl_vars['language']->value){
$_smarty_tpl->tpl_vars['language']->_loop = true;
?>"<?php echo $_smarty_tpl->tpl_vars['language']->value;?>
",<?php } ?> ]
			};
		</script>

		<script src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/js/router.js" type="text/javascript"></script>
		<script src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/require.js" type="text/javascript" ></script>
		
		<script type="text/javascript">

			var scripts = [
				"<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/jquery.placeholder.min.js",
				"<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/jquery.transit.min.js",
				"<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/ui.js",
				"<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/js/fusioneditor.js"
				<?php if ($_smarty_tpl->tpl_vars['extra_js']->value){?>,"<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/<?php echo $_smarty_tpl->tpl_vars['extra_js']->value;?>
"<?php }?>
			];

			require(scripts, function()
			{
				$(document).ready(function()
				{
					UI.initialize();

					<?php if ($_smarty_tpl->tpl_vars['extra_css']->value){?>
						Router.loadedCSS.push("<?php echo $_smarty_tpl->tpl_vars['extra_css']->value;?>
");
					<?php }?>

					<?php if ($_smarty_tpl->tpl_vars['extra_js']->value){?>
						Router.loadedJS.push("<?php echo $_smarty_tpl->tpl_vars['extra_js']->value;?>
");
					<?php }?>
				});
			});

		</script>

		<!--[if IE]>
			<style type="text/css">
			#main .right h2 img {
				position:relative;
			}
			</style>
		<![endif]-->

		<!--[if LTE IE 7]>
			<style type="text/css">
			#main .right .statistics span {
				width:320px;
			}
			</style>
		<![endif]-->
	</head>

	<body>
		<div id="popup_bg"></div>

		<!-- confirm box -->
		<div id="confirm" class="popup">
			<h1 class="popup_question" id="confirm_question"></h1>

			<div class="popup_links">
				<a href="javascript:void(0)" class="popup_button" id="confirm_button"></a>
				<a href="javascript:void(0)" class="popup_hide" id="confirm_hide" onClick="UI.hidePopup()">
					Cancel
				</a>
				<div style="clear:both;"></div>
			</div>
		</div>

		<!-- alert box -->
		<div id="alert" class="popup">
			<h1 class="popup_message" id="alert_message"></h1>

			<div class="popup_links">
				<a href="javascript:void(0)" class="popup_button" id="alert_button">Okay</a>
				<div style="clear:both;"></div>
			</div>
		</div>

		<!-- Top bar -->
		<header>
			<div class="center_1020">
				<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/" class="logo"></a>

				<!-- Top menu -->
				<aside class="right">
					<nav>
						<a target="_blank" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
ucp" data-hasevent="1">
							<div class="icon logout"></div>
							Go back
						</a>

						<?php if (hasPermission("editSystemSettings","admin")){?>
							<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/settings" <?php if ($_smarty_tpl->tpl_vars['current_page']->value=="admin/settings"){?>class="active"<?php }?>>
								<div class="icon settings"></div>
								Settings
							</a>
						<?php }?>

						<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/" <?php if ($_smarty_tpl->tpl_vars['current_page']->value=="admin/"){?>class="active"<?php }?>>
							<div class="icon dashboard"></div>
							Dashboard
						</a>
					</nav>

					<div class="welcome">
						Welcome, <b><?php echo $_smarty_tpl->tpl_vars['nickname']->value;?>
</b>
					</div>
				</aside>
			</div>
		</header>

		<!-- Main content -->
		<section id="wrapper">
			<div id="top_spacer"></div>
			<div class="center_1020" id="main">

				<!-- Main Left column -->
				<aside class="left">
					<nav>
						<?php  $_smarty_tpl->tpl_vars['group'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['group']->_loop = false;
 $_smarty_tpl->tpl_vars['text'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['menu']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['group']->key => $_smarty_tpl->tpl_vars['group']->value){
$_smarty_tpl->tpl_vars['group']->_loop = true;
 $_smarty_tpl->tpl_vars['text']->value = $_smarty_tpl->tpl_vars['group']->key;
?>
							<?php if (count($_smarty_tpl->tpl_vars['group']->value['links'])){?>
								<a><div class="icon <?php echo $_smarty_tpl->tpl_vars['group']->value['icon'];?>
"></div> <?php echo $_smarty_tpl->tpl_vars['text']->value;?>
</a>

								<section class="sub">
									<?php  $_smarty_tpl->tpl_vars['link'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['link']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['group']->value['links']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['link']->key => $_smarty_tpl->tpl_vars['link']->value){
$_smarty_tpl->tpl_vars['link']->_loop = true;
?>
										<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
<?php echo $_smarty_tpl->tpl_vars['link']->value['module'];?>
/<?php echo $_smarty_tpl->tpl_vars['link']->value['controller'];?>
" <?php if (isset($_smarty_tpl->tpl_vars['link']->value['active'])){?>class="active"<?php }?>><div class="icon <?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
"></div> <?php echo $_smarty_tpl->tpl_vars['link']->value['text'];?>
</a>
									<?php } ?>
								</section>
							<?php }?>
						<?php } ?>
					</nav>

					<article>
						<h1>Welcome to FusionCMS</h1>
						<b>Dear customer</b>, We are happy to introduce you to the next major version of our very own FusionCMS. Years have passed since the initial release and the system has grown better and stronger for every version. The core of this beast is powered by clean, object oriented PHP code, kept in shape by the incredibly powerful CodeIgniter framework. On the front we also make sure to amaze your visitors with more Javascript-powered live interactions than ever before.
						<div class="clear"></div>
					</article>
					<div class="spacer"></div>
				</aside>

				<!-- Main right column -->
				<aside class="right">
					<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

				</aside>

				<div class="clear"></div>
			</div>
		</section>

		<!-- Footer -->
		<footer>
			<div class="center_1020">
				<div class="divider2"></div>
				<aside id="logo"><a href="#" class="logo"></a></aside>
				<div class="divider"></div>
				<aside id="links">
					<a href="http://www.fusion-hub.com" target="_blank">FusionHub</a>
					<a href="http://www.fusion-hub.com/modules" target="_blank">Modules</a>
					<a href="http://www.fusion-hub.com/themes" target="_blank">Themes</a>
					<a href="http://www.fusion-hub.com/support" target="_blank">Support</a>
				</aside>
				<div class="divider"></div>
				<aside id="facebook">
					<h1>Like us on Facebook!</h1>
					<div id="fb_icon"></div>
					<a href="http://facebook.com/HeroicForge" target="_blank">HeroicForge</a>
				</aside>
				<div class="divider"></div>
				<aside id="html5">
					<a href="http://www.w3.org/html/logo/" data-tip="This website makes use of the next generation of web technologies">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/html5.png">
					</a>
				</aside>
				<div class="divider"></div>
				<div class="clear"></div>
			</div>
		</footer>
	</body>
</html><?php }} ?>