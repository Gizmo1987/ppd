<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:43:58
         compiled from "application\modules\online\views\online.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2675354fdf7fe7c4e32-38768843%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ee0d7da754415b7254712e23fe5321a1f681f52b' => 
    array (
      0 => 'application\\modules\\online\\views\\online.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2675354fdf7fe7c4e32-38768843',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'realms' => 0,
    'realm' => 0,
    'url' => 0,
    'character' => 0,
    'realmsObj' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf7fe8ca715_88619313',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf7fe8ca715_88619313')) {function content_54fdf7fe8ca715_88619313($_smarty_tpl) {?><section id="online_page">
	<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
		<?php if ($_smarty_tpl->tpl_vars['realm']->value->isOnline()){?>
		<a class="online_realm_button" href="javascript:void(0)" onClick="$('#online_realm_<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
').fadeToggle(400)"><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
 (<?php echo $_smarty_tpl->tpl_vars['realm']->value->getOnline();?>
)</a>
		<section class="online_realm" id="online_realm_<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
" <?php if (count($_smarty_tpl->tpl_vars['realms']->value)==1){?>style="display:block;"<?php }?>>
			<?php if ($_smarty_tpl->tpl_vars['realm']->value->getOnline()>0){?>
			<table class="nice_table" cellspacing="0" cellpadding="0">
				<tr>
					<td width="15%"><a href="javascript:void(0)" onClick="Sort.name(<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
)"><?php echo lang("character","online");?>
</a></td>
					<td width="15%" align="center"><a href="javascript:void(0)" onClick="Sort.level(<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
)"><?php echo lang("level","online");?>
</a></td>
					<td width="15%" align="center"><?php echo lang("race","online");?>
</td>
					<td width="15%" align="center"><?php echo lang("class","online");?>
</td>
					<td width="40%"><a href="javascript:void(0)" onClick="Sort.location(<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
)"><?php echo lang("location","online");?>
</a></td>
				</tr>

				<?php  $_smarty_tpl->tpl_vars['character'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['character']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realm']->value->getCharacters()->getOnlinePlayers(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['character']->key => $_smarty_tpl->tpl_vars['character']->value){
$_smarty_tpl->tpl_vars['character']->_loop = true;
?>
				<tr>
					<td width="15%"><a data-tip="<?php echo lang("view_profile","online");?>
" href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
character/<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
/<?php echo $_smarty_tpl->tpl_vars['character']->value['guid'];?>
"><?php echo $_smarty_tpl->tpl_vars['character']->value['name'];?>
</a></td>
					<td width="15%" align="center"><?php echo $_smarty_tpl->tpl_vars['character']->value['level'];?>
</td>
					<td width="15%" align="center"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/stats/<?php echo $_smarty_tpl->tpl_vars['character']->value['race'];?>
-<?php echo $_smarty_tpl->tpl_vars['character']->value['gender'];?>
.gif" /></td>
					<td width="15%" align="center"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/stats/<?php echo $_smarty_tpl->tpl_vars['character']->value['class'];?>
.gif" /></td>
					<td width="40%"><?php echo $_smarty_tpl->tpl_vars['realmsObj']->value->getZone($_smarty_tpl->tpl_vars['character']->value['zone']);?>
</td>
				</tr>
				<?php } ?>
			</table>
			<?php }else{ ?>
				<center style="margin-bottom:10px;"><?php echo lang("no_players","online");?>
</center>
			<?php }?>
		</section>
		<?php }else{ ?>
			<a class="online_realm_button"><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
 (<?php echo lang("offline","online");?>
)</a>
		<?php }?>
	<?php } ?>
</section><?php }} ?>