<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:55:10
         compiled from "application\themes\burning_theme\views\page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1049954fdfa9ee42cf4-90387794%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '838043871560e87e540eceb57a5d22ad16fee03c' => 
    array (
      0 => 'application\\themes\\burning_theme\\views\\page.tpl',
      1 => 1344586340,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1049954fdfa9ee42cf4-90387794',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdfa9ee85c19_56681708',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdfa9ee85c19_56681708')) {function content_54fdfa9ee85c19_56681708($_smarty_tpl) {?><article>
	<h1 class="top"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</h1>
	<section class="body">
		<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

	</section>
</article><?php }} ?>