<?php /* Smarty version Smarty-3.1.8, created on 2015-03-09 20:44:02
         compiled from "application\modules\armory\views\search.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3203854fdf8021372d7-23721577%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0be43312f0104615634d302c36bc4a2c10150c6b' => 
    array (
      0 => 'application\\modules\\armory\\views\\search.tpl',
      1 => 1412761085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3203854fdf8021372d7-23721577',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54fdf802174042_34140995',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54fdf802174042_34140995')) {function content_54fdf802174042_34140995($_smarty_tpl) {?><script type="text/javascript">
	if(typeof Search != "undefined")
	{
		Search.current = null;
	}
</script>
<div id="search_box">
	<form onSubmit="Search.submit();return false;">
		<table width="100%">
			<tr>
				<td><input type="text" placeholder="<?php echo lang('search_placeholder','armory');?>
" id="search_field" /></td>
				<td width="70px"><input type="submit" value="<?php echo lang('search_button','armory');?>
" /></td>
			<tr>
		</table>
		<div class="clear"></div>
	</form>

	<div id="search_results"></div>
</div><?php }} ?>