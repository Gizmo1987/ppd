<?php
$config['facebook_application_id'] = 519941048062599;
$config['server_upload_path'] = './uploads/';
$config['url_image_path'] = 'uploads';
$config['images_per_page'] = 32;
