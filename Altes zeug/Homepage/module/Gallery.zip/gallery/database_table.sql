CREATE  TABLE IF NOT EXISTS `gallery_images` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `file` VARCHAR(255) NOT NULL ,
  `user_id` INT(11) NULL DEFAULT NULL ,
  `created` DATETIME NULL DEFAULT NULL ,
  `allow_comments` INT(1) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `USER` (`user_id` ASC) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;


ALTER TABLE `gallery_images` CHANGE COLUMN `user_id` `user_id` INT(11) NOT NULL  , CHANGE COLUMN `allow_comments` `allow_comments` INT(1) NULL DEFAULT 1  , ADD COLUMN `title` VARCHAR(100) NULL DEFAULT NULL  AFTER `id` ;

ALTER TABLE `gallery_images` ADD COLUMN `hits` INT(11) NOT NULL DEFAULT 0  AFTER `allow_comments`;

ALTER TABLE `gallery_images` DROP COLUMN `gallery_imagescol`
, ADD INDEX `hits` (`hits` ASC)
, ADD INDEX `created` (`created` ASC) ;
