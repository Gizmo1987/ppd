<?php
    $config['horizontal_bar_height'] =  "14px";
    $config['show_uptime'] =  true;
    $config['auto_refresh_online_players'] =  false;
    $config['auto_refresh_interval_in_seconds'] = 20;
