<?php

$config['realmid'] = 1;
$config['minimize_groups_by_default'] = true;
$config['questionnr'] = 8; // Define how many questions should be enabled.
$config['info1'] = "How long have you been playing on the Forsaken Realms?";
$config['info2'] = "Have you ever been GM on a server before? If so, on what server and for how long?";
$config['info3'] = "Why do you think we should accept you as a GM?";
$config['info4'] = "Have you ever been banned for any reason? (From any server, retail or ptivate servers)";
$config['info5'] = "Name three strengths a game master must have.";
$config['info6'] = "What can we expect from you?";
$config['info7'] = "Do you have any knowledge in any programming language?";
$config['info8'] = "Tell us some more about your self. (Not WoW related)";
$config['info9'] = "How long have you been playing on the Forsaken Realms?";
$config['info10'] = "How long have you been playing on the Forsaken Realms?";
$config['info11'] = "How long have you been playing on the Forsaken Realms?";
$config['info12'] = "How long have you been playing on the Forsaken Realms?";
$config['info13'] = "How long have you been playing on the Forsaken Realms?";
$config['info14'] = "How long have you been playing on the Forsaken Realms?";
$config['info15'] = "How long have you been playing on the Forsaken Realms?";