if not TukuiCF["unitframes"].enable == true then return end

------------------------------------------------------------------------
--	Variables
------------------------------------------------------------------------

local db = TukuiCF["unitframes"]
local font1 = TukuiCF["media"].uffont
local font2 = TukuiCF["media"].font
local normTex = TukuiCF["media"].normTex
local glowTex = TukuiCF["media"].glowTex
local bubbleTex = TukuiCF["media"].bubbleTex

local backdrop = {
	bgFile = TukuiCF["media"].blank,
	insets = {top = -TukuiDB.mult, left = -TukuiDB.mult, bottom = -TukuiDB.mult, right = -TukuiDB.mult},
}

------------------------------------------------------------------------
--	Layout
------------------------------------------------------------------------

local function Shared(self, unit)
	-- set our own colors
	self.colors = TukuiDB.oUF_colors
	
	-- register click
	self:RegisterForClicks('AnyUp')
	self:SetScript('OnEnter', UnitFrame_OnEnter)
	self:SetScript('OnLeave', UnitFrame_OnLeave)
	
	-- menu? lol
	self.menu = TukuiDB.SpawnMenu
	self:SetAttribute('type2', 'menu')
	
	-- an update script to all elements
	self:HookScript("OnShow", TukuiDB.updateAllElements)

	-- backdrop for every units
	self:SetBackdrop(backdrop)
	self:SetBackdropColor(0, 0, 0)
	
	-- border for all frames
	local FrameBorder = CreateFrame("Frame", nil, self)
	FrameBorder:SetPoint("TOPLEFT", self, "TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
	FrameBorder:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
	TukuiDB.SetTemplate(FrameBorder)
	FrameBorder:SetBackdropBorderColor(unpack(TukuiCF["media"].altbordercolor))
	FrameBorder:SetFrameLevel(2)
	self.FrameBorder = FrameBorder
	
	TukuiDB.CreateShadow(self.FrameBorder)
	self.FrameBorder.shadow:SetFrameLevel(0)
	self.FrameBorder.shadow:SetFrameStrata("BACKGROUND")
	------------------------------------------------------------------------
	--	Player and Target units layout (mostly mirror'd)
	------------------------------------------------------------------------
	
	if (unit == "player" or unit == "target") then
		local unitheight = TukuiDB.Scale(40)
		local unitwidth = TukuiDB.Scale(220)
		-- health bar
		local health = CreateFrame('StatusBar', nil, self)
		health:SetPoint("TOPLEFT")
		health:SetPoint("BOTTOMRIGHT")
		health:SetStatusBarTexture(normTex)
		self.health = health
		
		-- health bar background
		local healthBG = health:CreateTexture(nil, 'BORDER')
		healthBG:SetAllPoints()
		healthBG:SetTexture(.1, .1, .1)
		health.value = TukuiDB.SetFontString(health, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
		health.value:SetPoint("RIGHT", health, "RIGHT", TukuiDB.Scale(-4), TukuiDB.Scale(1))
		health.PostUpdate = TukuiDB.PostUpdateHealth
		self.Health = health
		self.Health.bg = healthBG

		health.frequentUpdates = true
		if db.showsmooth == true then
			health.Smooth = true
		end
		
		if db.classcolor ~= true then
			health.colorTapping = false
			health.colorClass = false
			health:SetStatusBarColor(unpack(TukuiCF["unitframes"].healthcolor))	
		else
			health.colorTapping = true	
			health.colorClass = true
			health.colorReaction = true			
		end
		health.colorDisconnected = false
		
		
		-- power frame
		local PowerFrame = CreateFrame("Frame", nil, self)
		PowerFrame:SetHeight(unitheight)
		PowerFrame:SetWidth(unitwidth)
		PowerFrame:SetFrameLevel(self:GetFrameLevel() - 1)
		if unit == "target" then
			PowerFrame:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", TukuiDB.Scale(-7), TukuiDB.Scale(-7))
		else
			PowerFrame:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", TukuiDB.Scale(7), TukuiDB.Scale(-7))
		end
		TukuiDB.SetTemplate(PowerFrame)
		PowerFrame:SetBackdropBorderColor(unpack(TukuiCF["media"].altbordercolor))	
		
		self.PowerFrame = PowerFrame
		TukuiDB.CreateShadow(self.PowerFrame)
		-- power
		local power = CreateFrame('StatusBar', nil, self)
		power:SetPoint("TOPLEFT", PowerFrame, "TOPLEFT", TukuiDB.mult*2, -TukuiDB.mult*2)
		power:SetPoint("BOTTOMRIGHT", PowerFrame, "BOTTOMRIGHT", -TukuiDB.mult*2, TukuiDB.mult*2)
		power:SetStatusBarTexture(normTex)
		power:SetFrameLevel(PowerFrame:GetFrameLevel()+1)
				
		local powerBG = power:CreateTexture(nil, 'BORDER')
		powerBG:SetAllPoints(power)
		powerBG:SetTexture(normTex)
		powerBG.multiplier = 0.3
		power.value = TukuiDB.SetFontString(health, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
		power.value:SetPoint("LEFT", health, "LEFT", TukuiDB.Scale(4), TukuiDB.Scale(1))
		power.PreUpdate = TukuiDB.PreUpdatePower
		power.PostUpdate = TukuiDB.PostUpdatePower
				
		self.Power = power
		self.Power.bg = powerBG
		
		power.frequentUpdates = true
		power.colorDisconnected = true

		power.colorPower = true
		power.colorTapping = false
		power.colorDisconnected = true
		
		if db.showsmooth == true then
			power.Smooth = true
		end
		

		
		if TukuiCF["unitframes"].debuffhighlight == true then
			local dbh = health:CreateTexture(nil, "OVERLAY", health)
			dbh:SetAllPoints(health)
			dbh:SetTexture(TukuiCF["media"].normTex)
			dbh:SetBlendMode("ADD")
			dbh:SetVertexColor(0,0,0,0)
			self.DebuffHighlight = dbh
			self.DebuffHighlightFilter = true
			self.DebuffHighlightAlpha = 0.4		
		end
		
		-- portraits
		if (db.charportrait == true) then
			local PFrame = CreateFrame("Frame", nil, self)
			if unit == "player" then
				PFrame:SetPoint('TOPRIGHT', self,'TOPLEFT', TukuiDB.Scale(-6), TukuiDB.Scale(2))
			else
				PFrame:SetPoint('TOPLEFT', self,'TOPRIGHT', TukuiDB.Scale(6), TukuiDB.Scale(2))
			end
			PFrame:SetWidth(unitwidth*.2)
			PFrame:SetHeight(unitheight+TukuiDB.Scale(3.8)+TukuiDB.Scale(5))
			TukuiDB.SetTemplate(PFrame)
			PFrame:SetBackdropBorderColor(unpack(TukuiCF["media"].altbordercolor))
			self.PFrame = PFrame
			TukuiDB.CreateShadow(self.PFrame)			
			local portrait = CreateFrame("PlayerModel", nil, PFrame)
			portrait:SetFrameLevel(2)
			if unit == "target" then
				portrait:SetPoint('TOPLEFT', PFrame, 'TOPLEFT', TukuiDB.mult*2.2, -TukuiDB.mult*2)
			else
				portrait:SetPoint('TOPLEFT', PFrame, 'TOPLEFT', TukuiDB.mult*2, -TukuiDB.mult*2)
			end
			portrait:SetPoint('BOTTOMRIGHT', PFrame, 'BOTTOMRIGHT', -TukuiDB.mult*2, TukuiDB.mult*2)			
			table.insert(self.__elements, TukuiDB.HidePortrait)
		
			self.Portrait = portrait
		end

		if (unit == "player") then			
			-- combat icon
			local Combat = health:CreateTexture(nil, "OVERLAY")
			Combat:SetHeight(TukuiDB.Scale(19))
			Combat:SetWidth(TukuiDB.Scale(19))
			Combat:SetPoint("CENTER",0,7)
			Combat:SetVertexColor(0.69, 0.31, 0.31)
			self.Combat = Combat

			-- custom info (low mana warning)
			FlashInfo = CreateFrame("Frame", "FlashInfo", self)
			FlashInfo:SetScript("OnUpdate", TukuiDB.UpdateManaLevel)
			FlashInfo.parent = self
			FlashInfo:SetToplevel(true)
			FlashInfo:SetAllPoints(health)
			FlashInfo.ManaLevel = TukuiDB.SetFontString(FlashInfo, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
			FlashInfo.ManaLevel:SetPoint("CENTER", health, "CENTER", 0, TukuiDB.Scale(-5))
			self.FlashInfo = FlashInfo
			
			-- pvp status text
			local status = TukuiDB.SetFontString(health, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
			status:SetPoint("CENTER", health, "CENTER", 0, TukuiDB.Scale(-5))
			status:SetTextColor(0.69, 0.31, 0.31, 0)
			self.Status = status
			self:Tag(status, "[pvp]")
			
			-- script for pvp status and low mana
			self:SetScript("OnEnter", function(self) FlashInfo.ManaLevel:Hide() status:SetAlpha(1) UnitFrame_OnEnter(self) end)
			self:SetScript("OnLeave", function(self) FlashInfo.ManaLevel:Show() status:SetAlpha(0) UnitFrame_OnLeave(self) end)
			
			-- leader icon
			local Leader = health:CreateTexture(nil, "OVERLAY")
			Leader:SetHeight(TukuiDB.Scale(14))
			Leader:SetWidth(TukuiDB.Scale(14))
			Leader:SetPoint("TOPLEFT", TukuiDB.Scale(2), TukuiDB.Scale(8))
			self.Leader = Leader
			
			-- master looter
			local MasterLooter = health:CreateTexture(nil, "OVERLAY")
			MasterLooter:SetHeight(TukuiDB.Scale(14))
			MasterLooter:SetWidth(TukuiDB.Scale(14))
			self.MasterLooter = MasterLooter
			self:RegisterEvent("PARTY_LEADER_CHANGED", TukuiDB.MLAnchorUpdate)
			self:RegisterEvent("PARTY_MEMBERS_CHANGED", TukuiDB.MLAnchorUpdate)
						
			-- the threat bar on info left health ? :P
			if (db.showthreat == true) and not IsAddOnLoaded("Omen") then
				local ThreatBar = CreateFrame("StatusBar", self:GetName()..'_ThreatBar', TukuiInfoRight)
				ThreatBar:SetPoint("TOPLEFT", TukuiInfoRight, TukuiDB.Scale(2), TukuiDB.Scale(-2))
				ThreatBar:SetPoint("BOTTOMRIGHT", TukuiInfoRight, TukuiDB.Scale(-2), TukuiDB.Scale(2))
			  
				ThreatBar:SetStatusBarTexture(normTex)
				ThreatBar:GetStatusBarTexture():SetHorizTile(false)
				ThreatBar:SetBackdrop(backdrop)
				ThreatBar:SetBackdropColor(0, 0, 0, 0)
		   
				ThreatBar.Text = TukuiDB.SetFontString(ThreatBar, font2, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
				ThreatBar.Text:SetPoint("RIGHT", ThreatBar, "RIGHT", TukuiDB.Scale(-30), 0 )
		
				ThreatBar.Title = TukuiDB.SetFontString(ThreatBar, font2, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
				ThreatBar.Title:SetText(tukuilocal.unitframes_ouf_threattext)
				ThreatBar.Title:SetPoint("LEFT", ThreatBar, "LEFT", TukuiDB.Scale(30), 0 )
					  
				ThreatBar.bg = ThreatBar:CreateTexture(nil, 'BORDER')
				ThreatBar.bg:SetAllPoints(ThreatBar)
				ThreatBar.bg:SetTexture(0.1,0.1,0.1)
		   
				ThreatBar.useRawThreat = false
				self.ThreatBar = ThreatBar
			end
			
			-- swingbar
			if db.swingbar == true then
				local Swing = CreateFrame("StatusBar", self:GetName().."_SwingBar", TukuiActionBarBackground)
				Swing:SetStatusBarTexture(normTex)
				Swing:SetStatusBarColor(unpack(TukuiCF["media"].bordercolor))
				Swing:GetStatusBarTexture():SetHorizTile(false)
				self.Swing = Swing
				
				self.Swing:SetHeight(TukuiDB.Scale(4))
				self.Swing:SetWidth(TukuiActionBarBackground:GetWidth()-TukuiDB.Scale(4))
				self.Swing:SetPoint("BOTTOM", TukuiActionBarBackground, "TOP", 0, TukuiDB.Scale(4))
				
				self.Swing.bg = CreateFrame("Frame", nil, self.Swing)
				self.Swing.bg:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
				self.Swing.bg:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
				self.Swing.bg:SetFrameStrata("BACKGROUND")
				self.Swing.bg:SetFrameLevel(self.Swing:GetFrameLevel() - 1)
				TukuiDB.SetTemplate(self.Swing.bg)
			end
			
			-- experience bar on player via mouseover for player currently levelling a character
			if TukuiDB.level ~= MAX_PLAYER_LEVEL then
				local Experience = CreateFrame("StatusBar", self:GetName().."_Experience", self)
				Experience:SetStatusBarTexture(normTex)
				Experience:SetStatusBarColor(0, 0.4, 1, .8)
				Experience:SetWidth(unitwidth)
				Experience:SetHeight(TukuiDB.Scale(5))
				Experience:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, TukuiDB.Scale(-12))
				Experience.Tooltip = false
				Experience:EnableMouse(true)
				self.Experience = Experience

				
				Experience.Text = self.Experience:CreateFontString(nil, 'OVERLAY')
				Experience.Text:SetFont(font1, TukuiCF["unitframes"].fontsize, "OUTLINE")
				Experience.Text:SetPoint('CENTER', self.Experience)
				Experience.Text:Hide()
				self.Experience.Text = Experience.Text
				self.Experience.OverrideText = TukuiDB.ExperienceText
				
				Experience:SetScript("OnEnter", function(self) if not InCombatLockdown() then Experience:SetHeight(TukuiDB.Scale(20)) Experience.Text:Show() end end)
				Experience:SetScript("OnLeave", function(self) if not InCombatLockdown() then Experience:SetHeight(TukuiDB.Scale(5)) Experience.Text:Hide() end end)
				
				self.Experience.Rested = CreateFrame('StatusBar', nil, self)
				self.Experience.Rested:SetAllPoints(self.Experience)
				self.Experience.Rested:SetStatusBarTexture(normTex)
				self.Experience.Rested:SetStatusBarColor(1, 0, 1, 0.2)
				self.Experience.Rested:SetBackdrop(backdrop)
				self.Experience.Rested:SetBackdropColor(unpack(TukuiCF["media"].backdropcolor))

				
				local Resting = Experience:CreateTexture(nil, "OVERLAY", Experience.Rested)
				Resting:SetHeight(22)
				Resting:SetWidth(22)
				Resting:SetPoint("CENTER", self, "TOPLEFT", TukuiDB.Scale(-3), TukuiDB.Scale(6))
				Resting:SetTexture([=[Interface\CharacterFrame\UI-StateIcon]=])
				Resting:SetTexCoord(0, 0.5, 0, 0.421875)
				Resting:Hide()
				self.Resting = Resting
				
				self.Experience.F = CreateFrame("Frame", nil, self.Experience)
				TukuiDB.SetTemplate(self.Experience.F)
				self.Experience.F:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
				self.Experience.F:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
				self.Experience.F:SetFrameLevel(self.Experience:GetFrameLevel() - 1)
				self:RegisterEvent("PLAYER_UPDATE_RESTING", TukuiDB.RestingIconUpdate)
			end
			
			-- reputation bar for max level character
			if TukuiDB.level == MAX_PLAYER_LEVEL then
				local Reputation = CreateFrame("StatusBar", self:GetName().."_Reputation", self)
				Reputation:SetStatusBarTexture(normTex)
				Reputation:SetBackdrop(backdrop)
				Reputation:SetBackdropColor(unpack(TukuiCF["media"].backdropcolor))
				Reputation:SetWidth(unitwidth)
				Reputation:SetHeight(TukuiDB.Scale(5))
				Reputation:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, TukuiDB.Scale(-12))
				Reputation.Tooltip = true

				Reputation:HookScript("OnEnter", function(self)
					if not InCombatLockdown() then
							Reputation:SetHeight(TukuiDB.Scale(20))
					end
				end)
				
				Reputation:HookScript("OnLeave", function(self)
					if not InCombatLockdown() then
							Reputation:SetHeight(TukuiDB.Scale(5))
					end
				end)

				Reputation.PostUpdate = TukuiDB.UpdateReputationColor
				
				self.Reputation = Reputation
				self.Reputation.F = CreateFrame("Frame", nil, self.Reputation)
				TukuiDB.SetTemplate(self.Reputation.F)
				self.Reputation.F:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
				self.Reputation.F:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
				self.Reputation.F:SetFrameLevel(self.Reputation:GetFrameLevel() - 1)
			end
			
			-- show druid mana when shapeshifted in bear, cat or whatever
			if TukuiDB.myclass == "DRUID" then
				CreateFrame("Frame"):SetScript("OnUpdate", function() TukuiDB.UpdateDruidMana(self) end)
				local DruidMana = TukuiDB.SetFontString(health, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
				DruidMana:SetTextColor(1, 0.49, 0.04)
				self.DruidMana = DruidMana
			end

			-- deathknight runes
			if TukuiDB.myclass == "DEATHKNIGHT" and db.runebar == true then
				local Runes = CreateFrame("Frame", nil, self)
				Runes:SetPoint("BOTTOMLEFT", self, "TOPLEFT", 0, TukuiDB.Scale(5))
				Runes:SetHeight(TukuiDB.Scale(6))
				Runes:SetWidth(unitwidth)

				Runes:SetBackdrop(backdrop)
				Runes:SetBackdropColor(0, 0, 0)

				for i = 1, 6 do
					Runes[i] = CreateFrame("StatusBar", self:GetName().."_Runes"..i, self)
					Runes[i]:SetHeight(TukuiDB.Scale(6))
					Runes[i]:SetWidth((unitwidth - 5) / 6)

					if (i == 1) then
						Runes[i]:SetPoint("BOTTOMLEFT", self, "TOPLEFT", 0, TukuiDB.Scale(5))
					else
						Runes[i]:SetPoint("TOPLEFT", Runes[i-1], "TOPRIGHT", TukuiDB.Scale(1), 0)
					end
					Runes[i]:SetStatusBarTexture(normTex)
					Runes[i]:GetStatusBarTexture():SetHorizTile(false)
				end

				Runes.FrameBackdrop = CreateFrame("Frame", nil, Runes)
				TukuiDB.SetTemplate(Runes.FrameBackdrop)
				Runes.FrameBackdrop:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
				Runes.FrameBackdrop:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
				Runes.FrameBackdrop:SetFrameLevel(Runes:GetFrameLevel() - 1)
				self.Runes = Runes
			end
			
			-- shaman totem bar
			if TukuiDB.myclass == "SHAMAN" and db.totemtimer == true then
				local TotemBar = {}
				TotemBar.Destroy = true
				for i = 1, 4 do
					TotemBar[i] = CreateFrame("StatusBar", self:GetName().."_TotemBar"..i, self)
					if (i == 1) then
					   TotemBar[i]:SetPoint("BOTTOMLEFT", self, "TOPLEFT", 0, TukuiDB.Scale(5))
					else
					   TotemBar[i]:SetPoint("TOPLEFT", TotemBar[i-1], "TOPRIGHT", TukuiDB.Scale(1), 0)
					end
					TotemBar[i]:SetStatusBarTexture(normTex)
					TotemBar[i]:SetHeight(TukuiDB.Scale(6))
					TotemBar[i]:SetWidth((unitwidth - 3) / 4)

					TotemBar[i]:SetBackdrop(backdrop)
					TotemBar[i]:SetBackdropColor(0, 0, 0)
					TotemBar[i]:SetMinMaxValues(0, 1)

					TotemBar[i].bg = TotemBar[i]:CreateTexture(nil, "BORDER")
					TotemBar[i].bg:SetAllPoints(TotemBar[i])
					TotemBar[i].bg:SetTexture(normTex)
					TotemBar[i].bg.multiplier = 0.3
									
					TotemBar[i].FrameBackdrop = CreateFrame("Frame", nil, TotemBar[i])
					TukuiDB.SetTemplate(TotemBar[i].FrameBackdrop)
					TotemBar[i].FrameBackdrop:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
					TotemBar[i].FrameBackdrop:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
					TotemBar[i].FrameBackdrop:SetFrameLevel(TotemBar[i]:GetFrameLevel() - 1)
				end
				self.TotemBar = TotemBar
			end
		end
		
		if (unit == "target") then			
			-- Unit name on target
			local Name = health:CreateFontString(nil, "OVERLAY")
			Name:SetPoint("LEFT", health, "LEFT", 0, TukuiDB.Scale(1))
			Name:SetJustifyH("LEFT")
			Name:SetFont(font1, TukuiCF["unitframes"].fontsize, "OUTLINE")
			Name:SetShadowColor(0, 0, 0)
			Name:SetShadowOffset(1.25, -1.25)
			self:Tag(Name, '[Tukui:getnamecolor][Tukui:namelong] [Tukui:diffcolor][level] [shortclassification]')
			self.Name = Name
		end
		-- auras 
		if (unit == "player" and TukuiCF["auras"].playerauras) then
			local buffs = CreateFrame("Frame", nil, self)
			local debuffs = CreateFrame("Frame", nil, self)

			debuffs:SetHeight(((26 / 220) * unitwidth))
			debuffs:SetWidth(unitwidth + 2)
			if TukuiDB.myclass == "SHAMAN" or TukuiDB.myclass == "DEATHKNIGHT" or TukuiDB.myclass == "ROGUE" or TukuiDB.myclass == "DRUID" then
				debuffs:SetPoint("BOTTOM", self, "TOP", 0, 18)
			else
				debuffs:SetPoint("BOTTOM", self, "TOP", 0, 4)
			end
			debuffs.size = ((26 / 220) * unitwidth)
			debuffs.num = 8
			debuffs.spacing = 2
			debuffs.initialAnchor = 'TOPRIGHT'
			debuffs["growth-y"] = "UP"
			debuffs["growth-x"] = "LEFT"
			debuffs.PostCreateIcon = TukuiDB.PostCreateAura
			debuffs.PostUpdateIcon = TukuiDB.PostUpdateAura
			
			if TukuiCF["auras"].playershowonlydebuffs == false then
				buffs:SetPoint("BOTTOM", debuffs, "TOP", 0, 2)
				buffs:SetHeight(((26 / 220) * unitwidth))
				buffs:SetWidth(unitwidth + 2)
				buffs.size = ((26 / 220) * unitwidth)
				buffs.num = 8
				buffs.spacing = 2
				buffs.initialAnchor = 'TOPLEFT'
				buffs.PostCreateIcon = TukuiDB.PostCreateAura
				buffs.PostUpdateIcon = TukuiDB.PostUpdateAura
				self.Buffs = buffs	
			end
			
			self.Debuffs = debuffs
			-- Debuff Aura Filter
			self.Debuffs.CustomFilter = TukuiDB.AuraFilter
		end
		
		if (unit == "target" and TukuiCF["auras"].targetauras) then
			local buffs = CreateFrame("Frame", nil, self)
			local debuffs = CreateFrame("Frame", nil, self)
					
			buffs:SetPoint("BOTTOM", self, "TOP", 0, 4)
			buffs:SetHeight(((26 / 220) * unitwidth))
			buffs:SetWidth(unitwidth + 2)
			buffs.size = ((26 / 220) * unitwidth)
			buffs.num = 8
				
			debuffs:SetHeight(((26 / 220) * unitwidth))
			debuffs:SetWidth(unitwidth + 2)
			debuffs:SetPoint("BOTTOM", buffs, "TOP", 0, 2)
			debuffs.size = ((26 / 220) * unitwidth)
			debuffs.num = 8
				
			buffs.spacing = 2
			buffs.initialAnchor = 'TOPLEFT'
			buffs.PostCreateIcon = TukuiDB.PostCreateAura
			buffs.PostUpdateIcon = TukuiDB.PostUpdateAura
			self.Buffs = buffs	
						
			debuffs.spacing = 2
			debuffs.initialAnchor = 'TOPRIGHT'
			debuffs["growth-y"] = "UP"
			debuffs["growth-x"] = "LEFT"
			debuffs.PostCreateIcon = TukuiDB.PostCreateAura
			debuffs.PostUpdateIcon = TukuiDB.PostUpdateAura
			
			self.Debuffs = debuffs
			
			-- Debuff Aura Filter
			self.Debuffs.CustomFilter = TukuiDB.AuraFilter
		end
		
		-- cast bar for player and target
		if TukuiCF["castbar"].unitcastbar == true then
			local castbar = CreateFrame("StatusBar", self:GetName().."_Castbar", self)
			if unit == "player" and TukuiCF["castbar"].castermode == true then
				castbar:SetWidth(TukuiActionBarInvBackground:GetWidth() - TukuiDB.Scale(2))
				castbar:SetPoint("BOTTOMRIGHT", TukuiActionBarInvBackground, "TOPRIGHT", TukuiDB.Scale(-2), TukuiDB.Scale(5))
			else
				castbar:SetWidth(unitwidth)
				castbar:SetPoint("TOPRIGHT", self, "BOTTOMRIGHT", 0, TukuiDB.Scale(-14))
			end
 
			castbar:SetHeight(TukuiDB.Scale(20))
			castbar:SetStatusBarTexture(normTex)
			castbar:SetFrameLevel(6)
 
			castbar.bg = CreateFrame("Frame", nil, castbar)
			TukuiDB.SetTemplate(castbar.bg)
			castbar.bg:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
			castbar.bg:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
			castbar.bg:SetFrameLevel(5)
            TukuiDB.CreateShadow(castbar.bg)
 
			castbar.time = TukuiDB.SetFontString(castbar, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
			castbar.time:SetPoint("RIGHT", castbar, "RIGHT", TukuiDB.Scale(-4), TukuiDB.Scale(1))
			castbar.time:SetTextColor(0.84, 0.75, 0.65)
			castbar.time:SetJustifyH("RIGHT")
			castbar.CustomTimeText = CustomCastTimeText
 
			castbar.Text = TukuiDB.SetFontString(castbar, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
			castbar.Text:SetPoint("LEFT", castbar, "LEFT", 4, 1)
			castbar.Text:SetTextColor(0.84, 0.75, 0.65)
 
			castbar.CustomDelayText = TukuiDB.CustomCastDelayText
			castbar.PostCastStart = TukuiDB.PostCastStart
			castbar.PostChannelStart = TukuiDB.PostCastStart
 
			-- cast bar latency on player
			if unit == "player" and TukuiCF["castbar"].cblatency == true then
				castbar.safezone = castbar:CreateTexture(nil, "ARTWORK")
				castbar.safezone:SetTexture(normTex)
				castbar.safezone:SetVertexColor(0.69, 0.31, 0.31, 0.75)
				castbar.SafeZone = castbar.safezone
			end			
 
			if TukuiCF["castbar"].cbicons == true then
				castbar.button = CreateFrame("Frame", nil, castbar)
				castbar.button:SetHeight(castbar:GetHeight()+TukuiDB.Scale(4))
				castbar.button:SetWidth(castbar:GetHeight()+TukuiDB.Scale(4))
				castbar.button:SetPoint("RIGHT", castbar, "LEFT", TukuiDB.Scale(-4), 0)
				TukuiDB.SetTemplate(castbar.button)
 
				castbar.icon = castbar.button:CreateTexture(nil, "ARTWORK")
				castbar.icon:SetPoint("TOPLEFT", castbar.button, TukuiDB.Scale(2), TukuiDB.Scale(-2))
				castbar.icon:SetPoint("BOTTOMRIGHT", castbar.button, TukuiDB.Scale(-2), TukuiDB.Scale(2))
				castbar.icon:SetTexCoord(0.08, 0.92, 0.08, .92)
				if TukuiCF["castbar"].castermode == true and unit == "player" then
					castbar:SetWidth(TukuiActionBarInvBackground:GetWidth() - castbar.button:GetWidth() - TukuiDB.Scale(6))
				else
					castbar:SetWidth(unitwidth - castbar.button:GetWidth() - TukuiDB.Scale(2))
				end
			end
 
			self.Castbar = castbar
			self.Castbar.Time = castbar.time
			self.Castbar.Icon = castbar.icon
		end
		-- add combat feedback support
		if db.combatfeedback == true then
			local CombatFeedbackText 
			CombatFeedbackText = TukuiDB.SetFontString(health, font1, TukuiCF["unitframes"].fontsize*1.1, "OUTLINE")

			CombatFeedbackText:SetPoint("CENTER", 0, -5)
			CombatFeedbackText.colors = {
				DAMAGE = {0.69, 0.31, 0.31},
				CRUSHING = {0.69, 0.31, 0.31},
				CRITICAL = {0.69, 0.31, 0.31},
				GLANCING = {0.69, 0.31, 0.31},
				STANDARD = {0.84, 0.75, 0.65},
				IMMUNE = {0.84, 0.75, 0.65},
				ABSORB = {0.84, 0.75, 0.65},
				BLOCK = {0.84, 0.75, 0.65},
				RESIST = {0.84, 0.75, 0.65},
				MISS = {0.84, 0.75, 0.65},
				HEAL = {0.33, 0.59, 0.33},
				CRITHEAL = {0.33, 0.59, 0.33},
				ENERGIZE = {0.31, 0.45, 0.63},
				CRITENERGIZE = {0.31, 0.45, 0.63},
			}
			self.CombatFeedbackText = CombatFeedbackText
		end
		
		-- player aggro
		if db.playeraggro == true then
			table.insert(self.__elements, TukuiDB.UpdateThreat)
			self:RegisterEvent('PLAYER_TARGET_CHANGED', TukuiDB.UpdateThreat)
			self:RegisterEvent('UNIT_THREAT_LIST_UPDATE', TukuiDB.UpdateThreat)
			self:RegisterEvent('UNIT_THREAT_SITUATION_UPDATE', TukuiDB.UpdateThreat)
		end
		
		-- update all frames when changing area, to fix exiting instance while in vehicle
		self:RegisterEvent("ZONE_CHANGED_NEW_AREA", TukuiDB.updateAllElements)
		
		-- set width and height of player and target
		self:SetAttribute('initial-width', unitwidth)
		self:SetAttribute('initial-height', unitheight)
	end
	
	------------------------------------------------------------------------
	--	Target of Target, Pet unit layout mirrored
	------------------------------------------------------------------------
	
	if (unit == "targettarget" or unit == "pet" or unit == "focustarget" or unit == "focus") then
		local unitheight = TukuiDB.Scale(30)
		local unitwidth = TukuiDB.Scale(95)
		
		-- health bar
		local health = CreateFrame('StatusBar', nil, self)
		health:SetPoint("TOPLEFT")
		health:SetPoint("BOTTOMRIGHT")
		health:SetStatusBarTexture(normTex)
		
		local healthBG = health:CreateTexture(nil, 'BORDER')
		healthBG:SetAllPoints()
		healthBG:SetTexture(.1, .1, .1)
		
		self.Health = health
		self.Health.bg = healthBG
		
		health.frequentUpdates = true
		if db.showsmooth == true then
			health.Smooth = true
		end
		
		if db.classcolor ~= true then
			health.colorTapping = false
			health.colorClass = false
			health:SetStatusBarColor(unpack(TukuiCF["unitframes"].healthcolor))	
		else
			health.colorTapping = true	
			health.colorClass = true
			health.colorReaction = true			
		end
		health.colorDisconnected = false
		healthBG.multiplier = 0.3
		
		-- power frame
		local PowerFrame = CreateFrame("Frame", nil, self)
		PowerFrame:SetHeight(unitheight)
		PowerFrame:SetWidth(unitwidth)
		PowerFrame:SetFrameLevel(self:GetFrameLevel() - 1)
		if TukuiCF["raidframes"].centerheallayout == true then
			if unit == "focustarget" or unit == "pet" then
				PowerFrame:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", TukuiDB.Scale(7), TukuiDB.Scale(-7))
			elseif unit == "targettarget" or unit == "focus" then
				PowerFrame:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", TukuiDB.Scale(-7), TukuiDB.Scale(-7))
			end
		else
		if unit == "focus" or unit == "focustarget" then
			PowerFrame:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", TukuiDB.Scale(7), TukuiDB.Scale(-7))
		elseif unit == "targettarget" or unit == "pet" then
			PowerFrame:SetPoint("TOPLEFT", self, "TOPLEFT", TukuiDB.Scale(-7), 0)
			PowerFrame:SetPoint("TOPRIGHT", self, "TOPRIGHT", TukuiDB.Scale(7), 0)
			PowerFrame:SetPoint("BOTTOM", self, "BOTTOM", 0, TukuiDB.Scale(-7))
		end		
		end
		PowerFrame:SetFrameStrata("LOW")
		TukuiDB.SetTemplate(PowerFrame)
		PowerFrame:SetBackdropBorderColor(unpack(TukuiCF["media"].altbordercolor))	
		TukuiDB.CreateShadow(PowerFrame)
		
		-- power
		local power = CreateFrame('StatusBar', nil, self)
		power:SetPoint("TOPLEFT", PowerFrame, "TOPLEFT", TukuiDB.mult*2, -TukuiDB.mult*2)
		power:SetPoint("BOTTOMRIGHT", PowerFrame, "BOTTOMRIGHT", -TukuiDB.mult*2, TukuiDB.mult*2)
		power:SetStatusBarTexture(normTex)
		power:SetFrameLevel(PowerFrame:GetFrameLevel()+1)
		power:SetFrameStrata("LOW")
		
		local powerBG = power:CreateTexture(nil, 'BORDER')
		powerBG:SetAllPoints(power)
		powerBG:SetTexture(normTex)
		powerBG.multiplier = 0.3

				
		self.Power = power
		self.Power.bg = powerBG
		
		power.frequentUpdates = true
		power.colorDisconnected = true

		local dbh = health:CreateTexture(nil, "OVERLAY", health)
		dbh:SetAllPoints(health)
		dbh:SetTexture(TukuiCF["media"].normTex)
		dbh:SetBlendMode("ADD")
		dbh:SetVertexColor(0,0,0,0)
		self.DebuffHighlight = dbh
		self.DebuffHighlightFilter = true
		self.DebuffHighlightAlpha = 0.4	
		
		if db.showsmooth == true then
			power.Smooth = true
		end
		
		power.colorPower = true
		powerBG.multiplier = 0.3
		power.colorTapping = false
		power.colorDisconnected = true
		
		-- Unit name
		local Name = health:CreateFontString(nil, "OVERLAY")
		Name:SetPoint("CENTER", health, "CENTER", 0, TukuiDB.Scale(1))
		Name:SetFont(font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
		Name:SetJustifyH("CENTER")
		Name:SetShadowColor(0, 0, 0)
		Name:SetShadowOffset(1.25, -1.25)
		
		self:Tag(Name, '[Tukui:getnamecolor][Tukui:namemedium]')
		self.Name = Name
		
		if unit == "targettarget" and TukuiCF["auras"].totdebuffs == true then
			local debuffs = CreateFrame("Frame", nil, health)
			debuffs:SetHeight((20 / 100) * unitwidth)
			debuffs:SetWidth(unitwidth)
			debuffs.size = ((20 / 100) * unitwidth)
			debuffs.spacing = 2
			debuffs.num = 4

			debuffs:SetPoint("TOP", self, "BOTTOM", TukuiDB.Scale(7), -TukuiDB.Scale(10))
			debuffs.initialAnchor = "TOPLEFT"
			debuffs["growth-y"] = "UP"
			debuffs.PostCreateIcon = TukuiDB.PostCreateAuraSmall
			debuffs.PostUpdateIcon = TukuiDB.PostUpdateAura
			self.Debuffs = debuffs
			-- Debuff Aura Filter
			self.Debuffs.CustomFilter = TukuiDB.AuraFilter
		end
		
		if unit == "pet" then
			if (TukuiCF["castbar"].unitcastbar == true) then
				local castbar = CreateFrame("StatusBar", self:GetName().."_Castbar", self)
				castbar:SetStatusBarTexture(normTex)
				self.Castbar = castbar
			end
		end
		
		if TukuiCF["castbar"].unitcastbar == true and unit == "focus" then
			local castbar = CreateFrame("StatusBar", self:GetName().."_Castbar", self)
			castbar:SetHeight(TukuiDB.Scale(20))
			castbar:SetWidth(TukuiDB.Scale(240))
			castbar:SetStatusBarTexture(normTex)
			castbar:SetFrameLevel(6)
			castbar:SetPoint("CENTER", UIParent, "CENTER", 0, 250)		
			
			castbar.bg = CreateFrame("Frame", nil, castbar)
			TukuiDB.SetTemplate(castbar.bg)
			castbar.bg:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
			castbar.bg:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
			castbar.bg:SetFrameLevel(5)
			
			castbar.time = TukuiDB.SetFontString(castbar, font1, TukuiCF["unitframes"].fontsize)
			castbar.time:SetPoint("RIGHT", castbar, "RIGHT", TukuiDB.Scale(-4), TukuiDB.Scale(1))
			castbar.time:SetTextColor(0.84, 0.75, 0.65)
			castbar.time:SetJustifyH("RIGHT")
			castbar.CustomTimeText = CustomCastTimeText

			castbar.Text = TukuiDB.SetFontString(castbar, font1, TukuiCF["unitframes"].fontsize)
			castbar.Text:SetPoint("LEFT", castbar, "LEFT", 4, 1)
			castbar.Text:SetTextColor(0.84, 0.75, 0.65)
			
			castbar.CustomDelayText = TukuiDB.CustomCastDelayText
			castbar.PostCastStart = TukuiDB.PostCastStart
			castbar.PostChannelStart = TukuiDB.PostCastStart
			
			castbar.CastbarBackdrop = CreateFrame("Frame", nil, castbar)
			castbar.CastbarBackdrop:SetPoint("TOPLEFT", castbar, "TOPLEFT", TukuiDB.Scale(-6), TukuiDB.Scale(6))
			castbar.CastbarBackdrop:SetPoint("BOTTOMRIGHT", castbar, "BOTTOMRIGHT", TukuiDB.Scale(6), TukuiDB.Scale(-6))
			castbar.CastbarBackdrop:SetParent(castbar)
			castbar.CastbarBackdrop:SetFrameStrata("BACKGROUND")
			castbar.CastbarBackdrop:SetFrameLevel(4)
			castbar.CastbarBackdrop:SetBackdrop({
				edgeFile = glowTex, edgeSize = 4,
				insets = {left = 3, right = 3, top = 3, bottom = 3}
			})
			castbar.CastbarBackdrop:SetBackdropColor(0, 0, 0, 0)
			castbar.CastbarBackdrop:SetBackdropBorderColor(0, 0, 0, 0.7)
			
			if TukuiCF["castbar"].cbicons == true then
				castbar.button = CreateFrame("Frame", nil, castbar)
				castbar.button:SetHeight(TukuiDB.Scale(40))
				castbar.button:SetWidth(TukuiDB.Scale(40))
				castbar.button:SetPoint("CENTER", 0, TukuiDB.Scale(50))
				TukuiDB.SetTemplate(castbar.button)
				
				castbar.icon = castbar.button:CreateTexture(nil, "ARTWORK")
				castbar.icon:SetPoint("TOPLEFT", castbar.button, TukuiDB.Scale(2), TukuiDB.Scale(-2))
				castbar.icon:SetPoint("BOTTOMRIGHT", castbar.button, TukuiDB.Scale(-2), TukuiDB.Scale(2))
				castbar.icon:SetTexCoord(0.08, 0.92, 0.08, .92)
				
				castbar.IconBackdrop = CreateFrame("Frame", nil, self)
				castbar.IconBackdrop:SetPoint("TOPLEFT", castbar.button, "TOPLEFT", TukuiDB.Scale(-4), TukuiDB.Scale(4))
				castbar.IconBackdrop:SetPoint("BOTTOMRIGHT", castbar.button, "BOTTOMRIGHT", TukuiDB.Scale(4), TukuiDB.Scale(-4))
				castbar.IconBackdrop:SetParent(castbar)
				castbar.IconBackdrop:SetBackdrop({
					edgeFile = glowTex, edgeSize = 4,
					insets = {left = 3, right = 3, top = 3, bottom = 3}
				})
				castbar.IconBackdrop:SetBackdropColor(0, 0, 0, 0)
				castbar.IconBackdrop:SetBackdropBorderColor(0, 0, 0, 0.7)
			end

			self.Castbar = castbar
			self.Castbar.Time = castbar.time
			self.Castbar.Icon = castbar.icon
		end
		
		self:RegisterEvent("UNIT_PET", TukuiDB.updateAllElements)	
		-- width and height of target of target
		self:SetAttribute("initial-height", unitheight)
		self:SetAttribute("initial-width", unitwidth)

	end

	
	------------------------------------------------------------------------
	--	Arena or boss units layout (both mirror'd)
	------------------------------------------------------------------------
	
	if (unit and unit:find("arena%d") and TukuiCF["arena"].unitframes == true) or (unit and unit:find("boss%d") and TukuiCF["raidframes"].showboss == true) then
		-- Right-click focus on arena or boss units
		self:SetAttribute("type2", "focus")
		
		local unitheight = TukuiDB.Scale(23)
		local unitwidth = TukuiDB.Scale(180)
		
		-- health bar
		local health = CreateFrame('StatusBar', nil, self)
		health:SetHeight(unitheight)
		health:SetPoint("TOPLEFT")
		if (unit and unit:find('arena%d')) then
			health:SetPoint("TOPRIGHT", -unitheight*.80, 0)
		else
			health:SetPoint("TOPRIGHT")
		end
		health:SetStatusBarTexture(normTex)

		health.frequentUpdates = true
		if db.showsmooth == true then
			health.Smooth = true
		end
		
		local healthBG = health:CreateTexture(nil, 'BORDER')
		healthBG:SetAllPoints()
		healthBG:SetTexture(.1, .1, .1)

		health.value = TukuiDB.SetFontString(health, font1,TukuiCF["unitframes"].fontsize, "OUTLINE")
		health.value:SetPoint("LEFT", TukuiDB.Scale(2), TukuiDB.Scale(1))
		health.PostUpdate = TukuiDB.PostUpdateHealth
				
		self.Health = health
		self.Health.bg = healthBG
		
		health.frequentUpdates = true
		if db.showsmooth == true then
			health.Smooth = true
		end
		
		if db.classcolor ~= true then
			health.colorTapping = false
			health.colorClass = false
			health:SetStatusBarColor(unpack(TukuiCF["unitframes"].healthcolor))	
		else
			health.colorTapping = true	
			health.colorClass = true
			health.colorReaction = true			
		end
		health.colorDisconnected = false
		healthBG.multiplier = 0.3
		
		-- power frame
		local PowerFrame = CreateFrame("Frame", nil, self)
		PowerFrame:SetHeight(unitheight)
		PowerFrame:SetWidth(unitwidth)
		PowerFrame:SetFrameLevel(self:GetFrameLevel() - 1)
		PowerFrame:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", TukuiDB.Scale(7), TukuiDB.Scale(-7))
		
		TukuiDB.SetTemplate(PowerFrame)
		PowerFrame:SetBackdropBorderColor(unpack(TukuiCF["media"].altbordercolor))	
		TukuiDB.CreateShadow(PowerFrame)
		
		-- power
		local power = CreateFrame('StatusBar', nil, self)
		power:SetPoint("TOPLEFT", PowerFrame, "TOPLEFT", TukuiDB.mult*2, -TukuiDB.mult*2)
		power:SetPoint("BOTTOMRIGHT", PowerFrame, "BOTTOMRIGHT", -TukuiDB.mult*2, TukuiDB.mult*2)
		power:SetStatusBarTexture(normTex)
		power:SetFrameLevel(PowerFrame:GetFrameLevel()+1)		
		
		power.frequentUpdates = true
		power.colorPower = true
		power.colorDisconnected = true
		
		if db.showsmooth == true then
			power.Smooth = true
		end

		local powerBG = power:CreateTexture(nil, 'BORDER')
		powerBG:SetAllPoints(power)
		powerBG:SetTexture(normTex)
		powerBG.multiplier = 0.3
		
		power.colorPower = true
		powerBG.multiplier = 0.3
		power.colorTapping = false
		power.colorDisconnected = true
		
		if (unit and unit:find('arena%d')) then
			power.value = TukuiDB.SetFontString(health, font1, TukuiCF["unitframes"].fontsize, "OUTLINE")
			power.value:SetPoint("RIGHT", health, "RIGHT", TukuiDB.Scale(-4), TukuiDB.Scale(1))
			power.PreUpdate = TukuiDB.PreUpdatePower
			power.PostUpdate = TukuiDB.PostUpdatePower
		end

		
		self.Power = power
		self.Power.bg = powerBG
		
		-- names
		local Name
		if (unit and unit:find('arena%d')) then
			Name = health:CreateFontString(nil, "OVERLAY")
			Name:SetPoint("CENTER", health, "CENTER", 0, TukuiDB.Scale(1))
			Name:SetJustifyH("CENTER")
			Name:SetFont(font1, TukuiCF["unitframes"].fontsize, "OUTLINE")
			Name:SetShadowColor(0, 0, 0)
			Name:SetShadowOffset(1.25, -1.25)
		else
			Name = health:CreateFontString(nil, "OVERLAY")
			Name:SetPoint("RIGHT", health, "RIGHT", TukuiDB.Scale(-2), TukuiDB.Scale(1))
			Name:SetJustifyH("RIGHT")
			Name:SetFont(font1, TukuiCF["unitframes"].fontsize, "OUTLINE")
			Name:SetShadowColor(0, 0, 0)
			Name:SetShadowOffset(1.25, -1.25)		
		end
		
		self:Tag(Name, '[Tukui:getnamecolor][Tukui:nameshort] [Tukui:diffcolor][level] [shortclassification]')
		self.Name = Name
					
		-- trinket feature via trinket plugin
		if not IsAddOnLoaded("Gladius") then
			if (unit and unit:find('arena%d')) then
				local Trinketbg = CreateFrame("Frame", nil, self)
				Trinketbg:SetHeight(unitheight)
				Trinketbg:SetWidth(unitheight)
				Trinketbg:SetPoint("TOPRIGHT", self, "TOPRIGHT")				
				TukuiDB.SetTemplate(Trinketbg)
				Trinketbg:SetFrameLevel(self.Health:GetFrameLevel()+1)
				self.Trinketbg = Trinketbg
				
				local Trinket = CreateFrame("Frame", nil, Trinketbg)
				Trinket:SetAllPoints(Trinketbg)
				Trinket:SetPoint("TOPLEFT", Trinketbg, TukuiDB.Scale(2), TukuiDB.Scale(-2))
				Trinket:SetPoint("BOTTOMRIGHT", Trinketbg, TukuiDB.Scale(-2), TukuiDB.Scale(2))
				Trinket:SetFrameLevel(Trinketbg:GetFrameLevel()+1)
				Trinket.trinketUseAnnounce = true
				self.Trinket = Trinket
			end
		end
		
		--only need to see debuffs for arena frames
		if (unit and unit:find("arena%d")) and TukuiCF["auras"].arenadebuffs == true then
			-- create arena/boss debuff/buff spawn point
			local buffs = CreateFrame("Frame", nil, self)
			buffs:SetHeight(unitheight)
			buffs:SetWidth(252)
			buffs:SetPoint("RIGHT", self, "LEFT", TukuiDB.Scale(-4), 0)
			buffs.size = unitheight
			buffs.num = 3
			buffs.spacing = 2
			buffs.initialAnchor = 'RIGHT'
			buffs["growth-x"] = "LEFT"
			buffs.PostCreateIcon = TukuiDB.PostCreateAura
			buffs.PostUpdateIcon = TukuiDB.PostUpdateAura
			self.Buffs = buffs
			
			local debuffs = CreateFrame("Frame", nil, self)
			debuffs:SetHeight(unitheight)
			debuffs:SetWidth(252)
			debuffs:SetPoint("LEFT", self, "RIGHT", TukuiDB.Scale(4), 0)
			debuffs.size = unitheight
			debuffs.num = 3
			debuffs.spacing = 2
			debuffs.initialAnchor = 'LEFT'
			debuffs["growth-x"] = "RIGHT"
			debuffs.PostCreateIcon = TukuiDB.PostCreateAura
			debuffs.PostUpdateIcon = TukuiDB.PostUpdateAura
			self.Debuffs = debuffs
			
			--set filter for buffs/debuffs
			self.Buffs.CustomFilter = TukuiDB.ArenaBuffFilter
			self.Debuffs.CustomFilter = TukuiDB.ArenaDebuffFilter
		end
		
		
		if TukuiCF["castbar"].unitcastbar == true then
			local castbar = CreateFrame("StatusBar", self:GetName().."_Castbar", self)
			castbar:SetWidth(unitwidth)
			castbar:SetPoint("TOPRIGHT", self, "BOTTOMRIGHT", 0, TukuiDB.Scale(-12))		
			
			castbar:SetHeight(TukuiDB.Scale(14))
			castbar:SetStatusBarTexture(normTex)
			castbar:SetFrameLevel(6)
			
			castbar.bg = CreateFrame("Frame", nil, castbar)
			TukuiDB.SetTemplate(castbar.bg)
			castbar.bg:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
			castbar.bg:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
			castbar.bg:SetFrameLevel(5)
			TukuiDB.CreateShadow(castbar.bg)
			
			castbar.time = TukuiDB.SetFontString(castbar, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
			castbar.time:SetPoint("RIGHT", castbar, "RIGHT", TukuiDB.Scale(-4), TukuiDB.Scale(1))
			castbar.time:SetTextColor(0.84, 0.75, 0.65)
			castbar.time:SetJustifyH("RIGHT")
			castbar.CustomTimeText = CustomCastTimeText

			castbar.Text = TukuiDB.SetFontString(castbar, font1, TukuiCF["unitframes"].fontsize, "THINOUTLINE")
			castbar.Text:SetPoint("LEFT", castbar, "LEFT", 4, 1)
			castbar.Text:SetTextColor(0.84, 0.75, 0.65)
			
			castbar.CustomDelayText = TukuiDB.CustomCastDelayText
			castbar.PostCastStart = TukuiDB.PostCastStart
			castbar.PostChannelStart = TukuiDB.PostCastStart
									
			if TukuiCF["castbar"].cbicons == true then
				castbar.button = CreateFrame("Frame", nil, castbar)
				castbar.button:SetHeight(castbar:GetHeight()+TukuiDB.Scale(4))
				castbar.button:SetWidth(castbar:GetHeight()+TukuiDB.Scale(4))
				castbar.button:SetPoint("RIGHT", castbar, "LEFT", TukuiDB.Scale(-4), 0)
				TukuiDB.SetTemplate(castbar.button)
				TukuiDB.CreateShadow(castbar.button)
				castbar.icon = castbar.button:CreateTexture(nil, "ARTWORK")
				castbar.icon:SetPoint("TOPLEFT", castbar.button, TukuiDB.Scale(2), TukuiDB.Scale(-2))
				castbar.icon:SetPoint("BOTTOMRIGHT", castbar.button, TukuiDB.Scale(-2), TukuiDB.Scale(2))
				castbar.icon:SetTexCoord(0.08, 0.92, 0.08, .92)
				castbar:SetWidth(unitwidth - castbar.button:GetWidth() - TukuiDB.Scale(2))
			end

			self.Castbar = castbar
			self.Castbar.Time = castbar.time
			self.Castbar.Icon = castbar.icon
		end		
		
		self:SetAttribute("initial-height", unitheight)
		self:SetAttribute("initial-width", unitwidth)
	end

	------------------------------------------------------------------------
	--	Main tanks and Main Assists layout (both mirror'd)
	------------------------------------------------------------------------
	
	if(self:GetParent():GetName():match"oUF_MainTank" or self:GetParent():GetName():match"oUF_MainAssist") then
		-- Right-click focus on maintank or mainassist units
		self:SetAttribute("type2", "focus")
		
		-- health 
		local health = CreateFrame('StatusBar', nil, self)
		health:SetHeight(TukuiDB.Scale(20))
		health:SetPoint("TOPLEFT")
		health:SetPoint("TOPRIGHT")
		health:SetStatusBarTexture(normTex)
		
		local healthBG = health:CreateTexture(nil, 'BORDER')
		healthBG:SetAllPoints()
		healthBG:SetTexture(.1, .1, .1)
				
		self.Health = health
		self.Health.bg = healthBG
		
		health.frequentUpdates = true
		if db.showsmooth == true then
			health.Smooth = true
		end
		
		if db.classcolor ~= true then
			health.colorTapping = false
			health.colorClass = false
			health:SetStatusBarColor(unpack(TukuiCF["unitframes"].healthcolor))	
		else
			health.colorTapping = true	
			health.colorClass = true
			health.colorReaction = true			
		end
		health.colorDisconnected = false
		
		-- names
		local Name = health:CreateFontString(nil, "OVERLAY")
		Name:SetPoint("CENTER", health, "CENTER", 0, TukuiDB.Scale(1))
		Name:SetJustifyH("CENTER")
		Name:SetFont(font1, TukuiCF["unitframes"].fontsize, "OUTLINE")
		Name:SetShadowColor(0, 0, 0)
		Name:SetShadowOffset(1.25, -1.25)
		
		self:Tag(Name, '[Tukui:getnamecolor][Tukui:nameshort]')
		self.Name = Name
			
		self:SetAttribute("initial-height", TukuiDB.Scale(20))
		self:SetAttribute("initial-width", TukuiDB.Scale(100))	
	end

	------------------------------------------------------------------------
	--	Features we want for all units at the same time
	------------------------------------------------------------------------
	
	-- here we create an invisible frame for all element we want to show over health/power.
	-- because we can only use self here, and self is under all elements.
	local InvFrame = CreateFrame("Frame", nil, self)
	InvFrame:SetFrameStrata("HIGH")
	InvFrame:SetFrameLevel(5)
	InvFrame:SetAllPoints()
	
	-- symbols, now put the symbol on the frame we created above.
	local RaidIcon = InvFrame:CreateTexture(nil, "OVERLAY")
	RaidIcon:SetTexture("Interface\\AddOns\\Tukui\\media\\textures\\raidicons.blp") 
	RaidIcon:SetHeight(20)
	RaidIcon:SetWidth(20)
	RaidIcon:SetPoint("TOP", 0, 8)
	self.RaidIcon = RaidIcon
	
	return self
end

------------------------------------------------------------------------
--	Default position of Tukui unitframes
------------------------------------------------------------------------

oUF:RegisterStyle('Tukz', Shared)
oUF:SetActiveStyle('Tukz')
if TukuiCF["raidframes"].centerheallayout == false then
	local yOffset = 0
	if TukuiCF["castbar"].castermode == true then
		yOffset = yOffset + 28
	end
	
	oUF:Spawn('player', "oUF_Tukz_player"):SetPoint("BOTTOM", TukuiActionBarInvBackground, "TOPLEFT", TukuiDB.Scale(11),TukuiDB.Scale(40 + yOffset))
	oUF:Spawn('target', "oUF_Tukz_target"):SetPoint("BOTTOM", TukuiActionBarInvBackground, "TOPRIGHT", TukuiDB.Scale(-11),TukuiDB.Scale(40 + yOffset))
	oUF:Spawn('focus', "oUF_Tukz_focus"):SetPoint("BOTTOMLEFT", oUF_Tukz_target, "TOPRIGHT", TukuiDB.Scale(10),TukuiDB.Scale(30))
	oUF:Spawn('targettarget', "oUF_Tukz_targettarget"):SetPoint("BOTTOM", TukuiActionBarInvBackground, "TOP", 0,TukuiDB.Scale(40 + yOffset))
	oUF:Spawn('pet', "oUF_Tukz_pet"):SetPoint("BOTTOM", oUF_Tukz_targettarget, "TOP", 0, TukuiDB.Scale(15))

	if db.showfocustarget == true then oUF:Spawn("focustarget", "oUF_Tukz_focustarget"):SetPoint("BOTTOM", oUF_Tukz_focus, "TOP", 0, TukuiDB.Scale(8)) end
else

	oUF:Spawn('player', "oUF_Tukz_player"):SetPoint("BOTTOMRIGHT", TukuiActionBarInvBackground, "TOPLEFT", TukuiDB.Scale(-13),TukuiDB.Scale(185))
	oUF:Spawn('target', "oUF_Tukz_target"):SetPoint("BOTTOMLEFT", TukuiActionBarInvBackground, "TOPRIGHT", TukuiDB.Scale(13),TukuiDB.Scale(185))
	oUF:Spawn('focus', "oUF_Tukz_focus"):SetPoint("BOTTOMLEFT", oUF_Tukz_target, "TOPRIGHT", TukuiDB.Scale(10),TukuiDB.Scale(30))
	oUF:Spawn('targettarget', "oUF_Tukz_targettarget"):SetPoint("TOPRIGHT", oUF_Tukz_target, "BOTTOMRIGHT", 0,TukuiDB.Scale(-42))
	oUF:Spawn('pet', "oUF_Tukz_pet"):SetPoint("TOPLEFT", oUF_Tukz_player, "BOTTOMLEFT", 0,TukuiDB.Scale(-42))

	if db.showfocustarget == true then oUF:Spawn("focustarget", "oUF_Tukz_focustarget"):SetPoint("BOTTOM", oUF_Tukz_focus, "TOP", 0,TukuiDB.Scale(8)) end
end

if not IsAddOnLoaded("Gladius") then
	local arena = {}
	for i = 1, 5 do
		arena[i] = oUF:Spawn("arena"..i, "oUF_Arena"..i)
		if i == 1 then
			arena[i]:SetPoint("BOTTOMLEFT", ChatRBackground, "TOPLEFT", -40, 285)
		else
			arena[i]:SetPoint("BOTTOM", arena[i-1], "TOP", 0, 34)
		end
	end
end

for i = 1,MAX_BOSS_FRAMES do
	local t_boss = _G["Boss"..i.."TargetFrame"]
	t_boss:UnregisterAllEvents()
	t_boss.Show = TukuiDB.dummy
	t_boss:Hide()
	_G["Boss"..i.."TargetFrame".."HealthBar"]:UnregisterAllEvents()
	_G["Boss"..i.."TargetFrame".."ManaBar"]:UnregisterAllEvents()
end

local boss = {}
for i = 1, MAX_BOSS_FRAMES do
	boss[i] = oUF:Spawn("boss"..i, "oUF_Boss"..i)
	if i == 1 then
		boss[i]:SetPoint("BOTTOMLEFT", ChatRBackground, "TOPLEFT", -40, 285)
	else
		boss[i]:SetPoint('BOTTOM', boss[i-1], 'TOP', 0, 34)             
	end
end

if TukuiCF["raidframes"].centerheallayout == false then
	if TukuiCF["raidframes"].maintank == true then
		local tank = oUF:SpawnHeader("oUF_MainTank", nil, 'raid, party, solo', 
			"showRaid", true, "groupFilter", "MAINTANK", "yOffset", 5, "point" , "BOTTOM",
			"template", "oUF_tukzMtt"
		)
		tank:SetPoint("BOTTOMLEFT", ChatLBackground, "TOPLEFT", TukuiDB.Scale(5), TukuiDB.Scale(510))
	end

	if TukuiCF["raidframes"].mainassist == true then
		local assist = oUF:SpawnHeader("oUF_MainAssist", nil, 'raid, party, solo', 
			"showRaid", true, "groupFilter", "MAINASSIST", "yOffset", 5, "point" , "BOTTOM",
			"template", "oUF_tukzMtt"
		)
		assist:SetPoint("BOTTOMLEFT", ChatLBackground, "TOPLEFT", TukuiDB.Scale(5), TukuiDB.Scale(450))
	end
else
	if TukuiCF["raidframes"].maintank == true then
		local tank = oUF:SpawnHeader("oUF_MainTank", nil, 'raid, party, solo', 
			"showRaid", true, "groupFilter", "MAINTANK", "yOffset", 5, "point" , "BOTTOM",
			"template", "oUF_tukzMtt"
		)
		tank:SetPoint("BOTTOMLEFT", ChatLBackground, "TOPLEFT", TukuiDB.Scale(5), TukuiDB.Scale(410))
	end

	if TukuiCF["raidframes"].mainassist == true then
		local assist = oUF:SpawnHeader("oUF_MainAssist", nil, 'raid, party, solo', 
			"showRaid", true, "groupFilter", "MAINASSIST", "yOffset", 5, "point" , "BOTTOM",
			"template", "oUF_tukzMtt"
		)
		assist:SetPoint("BOTTOMLEFT", ChatLBackground, "TOPLEFT", TukuiDB.Scale(5), TukuiDB.Scale(350))
	end
end
local party = oUF:SpawnHeader("oUF_noParty", nil, "party", "showParty", true)

------------------------------------------------------------------------
--	Right-Click on unit frames menu.
------------------------------------------------------------------------

do
	UnitPopupMenus["SELF"] = { "PVP_FLAG", "LOOT_METHOD", "LOOT_THRESHOLD", "OPT_OUT_LOOT_TITLE", "LOOT_PROMOTE", "DUNGEON_DIFFICULTY", "RAID_DIFFICULTY", "RESET_INSTANCES", "RAID_TARGET_ICON", "LEAVE", "CANCEL" };
	UnitPopupMenus["PET"] = { "PET_PAPERDOLL", "PET_RENAME", "PET_ABANDON", "PET_DISMISS", "CANCEL" };
	UnitPopupMenus["PARTY"] = { "MUTE", "UNMUTE", "PARTY_SILENCE", "PARTY_UNSILENCE", "RAID_SILENCE", "RAID_UNSILENCE", "BATTLEGROUND_SILENCE", "BATTLEGROUND_UNSILENCE", "WHISPER", "PROMOTE", "PROMOTE_GUIDE", "LOOT_PROMOTE", "VOTE_TO_KICK", "UNINVITE", "INSPECT", "ACHIEVEMENTS", "TRADE", "FOLLOW", "DUEL", "RAID_TARGET_ICON", "PVP_REPORT_AFK", "RAF_SUMMON", "RAF_GRANT_LEVEL", "CANCEL" }
	UnitPopupMenus["PLAYER"] = { "WHISPER", "INSPECT", "INVITE", "ACHIEVEMENTS", "TRADE", "FOLLOW", "DUEL", "RAID_TARGET_ICON", "RAF_SUMMON", "RAF_GRANT_LEVEL", "CANCEL" }
	UnitPopupMenus["RAID_PLAYER"] = { "MUTE", "UNMUTE", "RAID_SILENCE", "RAID_UNSILENCE", "BATTLEGROUND_SILENCE", "BATTLEGROUND_UNSILENCE", "WHISPER", "INSPECT", "ACHIEVEMENTS", "TRADE", "FOLLOW", "DUEL", "RAID_TARGET_ICON", "RAID_LEADER", "RAID_PROMOTE", "RAID_DEMOTE", "LOOT_PROMOTE", "RAID_REMOVE", "PVP_REPORT_AFK", "RAF_SUMMON", "RAF_GRANT_LEVEL", "CANCEL" };
	UnitPopupMenus["RAID"] = { "MUTE", "UNMUTE", "RAID_SILENCE", "RAID_UNSILENCE", "BATTLEGROUND_SILENCE", "BATTLEGROUND_UNSILENCE", "RAID_LEADER", "RAID_PROMOTE", "RAID_MAINTANK", "RAID_MAINASSIST", "RAID_TARGET_ICON", "LOOT_PROMOTE", "RAID_DEMOTE", "RAID_REMOVE", "PVP_REPORT_AFK", "CANCEL" };
	UnitPopupMenus["VEHICLE"] = { "RAID_TARGET_ICON", "VEHICLE_LEAVE", "CANCEL" }
	UnitPopupMenus["TARGET"] = { "RAID_TARGET_ICON", "CANCEL" }
	UnitPopupMenus["ARENAENEMY"] = { "CANCEL" }
	UnitPopupMenus["FOCUS"] = { "RAID_TARGET_ICON", "CANCEL" }
	UnitPopupMenus["BOSS"] = { "RAID_TARGET_ICON", "CANCEL" }
end

