if not TukuiCF["raidframes"].enable == true == true then return end

local function Shared(self, unit)
	local unitwidth
	local unitheight
	if TukuiCF["raidframes"].centerheallayout == false then
		unitwidth = TukuiDB.Scale(65/350 * TukuiCF["chat"].chatwidth)*TukuiCF["raidframes"].scale
		unitheight = TukuiDB.Scale(42)*TukuiCF["raidframes"].scale
	else
		unitwidth = TukuiDB.Scale((TukuiActionBarInvBackground:GetWidth() / 5) - 7)*TukuiCF["raidframes"].scale
		unitheight = TukuiDB.Scale(42)*TukuiCF["raidframes"].scale
	end
	 
	
	self.colors = TukuiDB.oUF_colors
	self:RegisterForClicks('AnyUp')
	self:SetScript('OnEnter', UnitFrame_OnEnter)
	self:SetScript('OnLeave', UnitFrame_OnLeave)
	
	self.menu = TukuiDB.SpawnMenu
	self:SetAttribute('type2', 'menu')
	
	-- an update script to all elements
	self:HookScript("OnShow", TukuiDB.updateAllElementsRaid)
	
	self:SetAttribute('initial-height', unitheight)
	self:SetAttribute('initial-width', unitwidth)
	
	self:SetBackdrop({bgFile = TukuiCF["media"].blank, insets = {top = -TukuiDB.mult, left = -TukuiDB.mult, bottom = -TukuiDB.mult, right = -TukuiDB.mult}})
	self:SetBackdropColor(0.1, 0.1, 0.1)
	
	local health = CreateFrame('StatusBar', nil, self)
	health:SetHeight(unitheight*.83)
	health:SetPoint("TOPLEFT")
	health:SetPoint("TOPRIGHT")
	health:SetStatusBarTexture(TukuiCF["media"].normTex)
	if TukuiCF["raidframes"].gridhealthvertical == true then
		health:SetOrientation("VERTICAL")
	end
	self.Health = health
	
	health.bg = health:CreateTexture(nil, 'BORDER')
	health.bg:SetAllPoints(health)
	health.bg:SetTexture(TukuiCF["media"].normTex)
	health.bg:SetTexture(0.1, 0.1, 0.1)
	
	self.Health.bg = health.bg
	
	health.value = health:CreateFontString(nil, "OVERLAY")
	health.value:SetPoint("BOTTOM", health, "BOTTOM", 0, TukuiDB.Scale(4))
	health.value:SetFont(TukuiCF["media"].uffont, (TukuiCF["raidframes"].fontsize*.83)*TukuiCF["raidframes"].scale, "THINOUTLINE")
	health.value:SetTextColor(1,1,1)
	health.value:SetShadowOffset(1, -1)
	self.Health.value = health.value		
	
	health.PostUpdate = TukuiDB.PostUpdateHealthRaid
	health.frequentUpdates = true
	
	if TukuiCF["unitframes"].classcolor ~= true then
		health.colorTapping = false
		health.colorClass = false
		health:SetStatusBarColor(unpack(TukuiCF["unitframes"].healthcolor))	
	else
		health.colorTapping = true	
		health.colorClass = true
		health.colorReaction = true			
	end
	health.colorDisconnected = false
	
	-- border for all frames
	local FrameBorder = CreateFrame("Frame", nil, self)
	FrameBorder:SetPoint("TOPLEFT", self, "TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
	FrameBorder:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
	TukuiDB.SetTemplate(FrameBorder)
	FrameBorder:SetBackdropBorderColor(unpack(TukuiCF["media"].altbordercolor))
	FrameBorder:SetFrameLevel(2)
	self.FrameBorder = FrameBorder
	
	-- power
	local power = CreateFrame('StatusBar', nil, self)
	power:SetPoint("TOPLEFT", health, "BOTTOMLEFT", 0, TukuiDB.Scale(-1)+(-TukuiDB.mult*2))
	power:SetPoint("TOPRIGHT", health, "BOTTOMRIGHT", 0, TukuiDB.Scale(-1)+(-TukuiDB.mult*2))
	power:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, 0)
	power:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, 0)
	power:SetStatusBarTexture(TukuiCF["media"].normTex)
	self.Power = power
	if TukuiCF["raidframes"].hidenonmana == true then
		power.PostUpdate = TukuiDB.PostUpdatePowerRaid
	end
	-- border between health and power
	self.HealthBorder = CreateFrame("Frame", nil, power)
	self.HealthBorder:SetPoint("TOPLEFT", health, "BOTTOMLEFT", 0, -TukuiDB.mult)
	self.HealthBorder:SetPoint("TOPRIGHT", health, "BOTTOMRIGHT", 0, -TukuiDB.mult)
	self.HealthBorder:SetPoint("BOTTOMLEFT", power, "TOPLEFT", 0, TukuiDB.mult)
	self.HealthBorder:SetPoint("BOTTOMRIGHT", power, "TOPRIGHT", 0, TukuiDB.mult)
	TukuiDB.SetTemplate(self.HealthBorder)
	self.HealthBorder:SetBackdropBorderColor(unpack(TukuiCF["media"].altbordercolor))	
	
	power.frequentUpdates = true

	power.bg = self.Power:CreateTexture(nil, "BORDER")
	power.bg:SetAllPoints(power)
	power.bg:SetTexture(TukuiCF["media"].normTex)
	power.bg.multiplier = 0.3
	self.Power.bg = power.bg
	
	power.colorPower = true
	power.colorTapping = false
	power.colorDisconnected = true
	
	local name = health:CreateFontString(nil, "OVERLAY")
    name:SetPoint("TOP", health, 0, TukuiDB.Scale(-2))
	name:SetFont(TukuiCF["media"].uffont, TukuiCF["raidframes"].fontsize*TukuiCF["raidframes"].scale, "THINOUTLINE")
	name:SetShadowOffset(1, -1)
	self:Tag(name, "[Tukui:getnamecolor][Tukui:nameshort]")
	self.Name = name
	
    if TukuiCF["unitframes"].aggro == true then
		table.insert(self.__elements, TukuiDB.UpdateThreat)
		self:RegisterEvent('PLAYER_TARGET_CHANGED', TukuiDB.UpdateThreat)
		self:RegisterEvent('UNIT_THREAT_LIST_UPDATE', TukuiDB.UpdateThreat)
		self:RegisterEvent('UNIT_THREAT_SITUATION_UPDATE', TukuiDB.UpdateThreat)
	end
	
	if TukuiCF["unitframes"].showsymbols == true then
		local RaidIcon = health:CreateTexture(nil, 'OVERLAY')
		RaidIcon:SetHeight(TukuiDB.Scale(15)*TukuiCF["raidframes"].scale)
		RaidIcon:SetWidth(TukuiDB.Scale(15)*TukuiCF["raidframes"].scale)
		RaidIcon:SetPoint('CENTER', self, 'TOP', 0, 3)
		RaidIcon:SetTexture('Interface\\AddOns\\Tukui\\media\\textures\\raidicons.blp')
		self.RaidIcon = RaidIcon
	end
	
	local ReadyCheck = self.Health:CreateTexture(nil, "OVERLAY")
	ReadyCheck:SetHeight(TukuiDB.Scale(12)*TukuiCF["raidframes"].scale)
	ReadyCheck:SetWidth(TukuiDB.Scale(12)*TukuiCF["raidframes"].scale)
	ReadyCheck:SetPoint('CENTER', 0, -8) 	
	self.ReadyCheck = ReadyCheck
	
		if TukuiCF["unitframes"].debuffhighlight == true then
			local dbh = health:CreateTexture(nil, "OVERLAY", health)
			dbh:SetAllPoints(health)
			dbh:SetTexture(TukuiCF["media"].normTex)
			dbh:SetBlendMode("ADD")
			dbh:SetVertexColor(0,0,0,0)
			self.DebuffHighlight = dbh
			self.DebuffHighlightFilter = true
			self.DebuffHighlightAlpha = 0.4		
		end
	
	local rescomm = CreateFrame("Frame", nil, self.FrameBorder)
	TukuiDB.SetTemplate(rescomm)
	rescomm:SetAllPoints(self.FrameBorder)
	rescomm:SetBackdropColor(0, 0, 0, 0)
	rescomm:SetBackdropBorderColor(0, 0.85, 0, 1)
		
	self.ResComm = rescomm
	rescomm.OthersOnly = true
	
	if TukuiCF["raidframes"].healcomm == true then
		self.HealCommBar = CreateFrame('StatusBar', nil, health)
		self.HealCommBar:SetHeight(0)
		self.HealCommBar:SetWidth(0)
		self.HealCommBar:SetStatusBarTexture(self.Health:GetStatusBarTexture():GetTexture())
		self.HealCommBar:SetStatusBarColor(0, 1, 0, 0.25)
		self.HealCommBar:SetPoint('LEFT', health, 'LEFT')
		self.allowHealCommOverflow = false
	end
	

	local debuffs = CreateFrame('Frame', nil, self)
	debuffs:SetPoint('CENTER', self, 'CENTER', 0, TukuiDB.Scale(-6))
	debuffs:SetHeight((unitwidth / 2)*.73)
	debuffs:SetWidth(unitwidth)
	debuffs.size = ((unitwidth / 2) *.73)
	debuffs.spacing = 0
	debuffs.initialAnchor = 'CENTER'
	debuffs.num = 1
	debuffs.PostCreateIcon = TukuiDB.PostCreateAuraSmallHealer25
	debuffs.PostUpdateIcon = TukuiDB.PostUpdateAura
	self.Debuffs = debuffs
	self.Debuffs.CustomFilter = TukuiDB.HealerFilter

			
	if TukuiCF["raidframes"].showrange == true then
		local range = {insideAlpha = 1, outsideAlpha = TukuiCF["raidframes"].raidalphaoor}
		self.Range = range
	end
	
	if TukuiCF["unitframes"].showsmooth == true then
		health.Smooth = true
		if self.Power then
			power.Smooth = true
		end
	end	
	
	if TukuiCF["auras"].raidunitbuffwatch == true then
		TukuiDB.createAuraWatch(self,unit)
    end
	
	if TukuiCF["raidframes"].hidenonmana == true then
		self:RegisterEvent("UNIT_DISPLAYPOWER", TukuiDB.CheckPowerRaid)	
	end
	self:RegisterEvent("UNIT_PET", TukuiDB.updateAllElementsRaid)
	
	return self
end


oUF:RegisterStyle('TukuiHealR6R25', Shared)

oUF:Factory(function(self)
	oUF:SetActiveStyle("TukuiHealR6R25")	
	local raid
	if TukuiCF["raidframes"].centerheallayout == false then
		raid = self:SpawnHeader("oUF_TukuiHealR6R25", nil, nil,
			"showRaid", true, 
			"showParty", true,
			"showPlayer", TukuiCF["raidframes"].showplayerinparty,
			"xoffset", TukuiDB.Scale(6),
			"yOffset", TukuiDB.Scale(-6),
			"point", "LEFT",
			"groupFilter", "1,2,3,4,5",
			"groupingOrder", "1,2,3,4,5",
			"groupBy", "GROUP",
			"maxColumns", 5,
			"unitsPerColumn", 5,
			"columnSpacing", TukuiDB.Scale(6),
			"columnAnchorPoint", "TOP"		
		)
		raid:SetPoint("BOTTOMLEFT", ChatLBackground, "TOPLEFT", TukuiDB.Scale(2), TukuiDB.Scale(40))
	else
		local yOffset = 0
		if TukuiCF["castbar"].castermode == true then
			yOffset = yOffset + 28
		end
		raid = self:SpawnHeader("oUF_TukuiHealR6R25", nil, nil,
			"showRaid", true, 
			"showParty", true,
			"showPlayer", TukuiCF["raidframes"].showplayerinparty,
			"xoffset", TukuiDB.Scale(6),
			"yOffset", TukuiDB.Scale(-6),
			"point", "LEFT",
			"groupFilter", "1,2,3,4,5",
			"groupingOrder", "1,2,3,4,5",
			"groupBy", "GROUP",
			"maxColumns", 5,
			"unitsPerColumn", 5,
			"columnSpacing", TukuiDB.Scale(6),
			"columnAnchorPoint", "TOP"		
		)
		raid:SetPoint("BOTTOM", TukuiActionBarInvBackground, "TOP", 0, TukuiDB.Scale(6+yOffset))	
	end
	
	local raidToggle = CreateFrame("Frame")
	raidToggle:RegisterEvent("PLAYER_LOGIN")
	raidToggle:RegisterEvent("RAID_ROSTER_UPDATE")
	raidToggle:RegisterEvent("PARTY_LEADER_CHANGED")
	raidToggle:RegisterEvent("PARTY_MEMBERS_CHANGED")
	raidToggle:SetScript("OnEvent", function(self)
		if InCombatLockdown() then
			self:RegisterEvent("PLAYER_REGEN_ENABLED")
		else
			self:UnregisterEvent("PLAYER_REGEN_ENABLED")
			local numraid = GetNumRaidMembers()
			if TukuiDB.Show25RaidLayout == true then
				raid:Show()
			elseif TukuiCF["raidframes"].gridonly == true then
				if numraid > 25 then
					raid:Hide()
				else
					raid:Show()
				end
			else
				if numraid >= 6 and numraid <= 25 then -- between 6 and 25, reminder for when i'm editing
					raid:Show()
				else
					raid:Hide()	
				end
			end
		end
	end)
end)