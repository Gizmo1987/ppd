--Written by eClipse, edited by elv22, don't worry this should work with any edit of tukui, not just my own edited version

if TukuiCF["unitframes"].eComboBar and TukuiCF["unitframes"].eComboBar ~= true then return end

local combotex = [[Interface\AddOns\Tukui\media\textures\normTex]]
local fadeIn = 0.5
local fadeOut = 0.5
local frameFadeIn = 0.2
local frameFadeOut = 0.2
local hideooc = false
local hidenoenergy = true
local incombat = false

--only edit below this unless you know what your doing
local visible
local powertype = nil
local unit = "player"
local points = 0

if TukuiCF["unitframes"].ComboHideOOC then
	hideooc = TukuiCF["unitframes"].ComboHideOOC
end

if TukuiCF["unitframes"].ComboHideNoEnergy then
	hidenoenergy = TukuiCF["unitframes"].ComboHideNoEnergy
end

local comboFrame = CreateFrame("Frame", "eCombo", UIParent)
function comboFrame:new()
	self:ClearAllPoints()
	self:SetHeight(8)
	if oUF_Tukz_player then
		self:SetPoint("BOTTOM", oUF_Tukz_player, "TOP", 0, 5)
		self:SetWidth(oUF_Tukz_player:GetWidth())
	else
		self:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
		self:SetWidth(250)
	end
	


	self.backdrop = self:CreateTexture(nil, "overlay")
	self.backdrop:ClearAllPoints()
	self.backdrop:SetPoint("TOPLEFT", self, "TOPLEFT", TukuiDB.Scale(-1), TukuiDB.Scale(1))
	self.backdrop:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", TukuiDB.Scale(1), TukuiDB.Scale(-1))
	self.backdrop:SetTexture(combotex)
	self.backdrop:SetVertexColor(unpack(TukuiCF["media"].backdropcolor))

	
	self.border = CreateFrame("Frame", nil, self)
	TukuiDB.SetTemplate(self.border)
	self.border:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
	self.border:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
	self.border:SetFrameLevel(self:GetFrameLevel() - 1)

	self.comboWidth = (self:GetWidth()-4) / 5
	
	self.combos = {}
	self.CPoints = {}
	local cx = 0
		for i = 1, 5 do
		local combo = CreateFrame("Frame", nil, self)
		combo:ClearAllPoints()
		combo:SetPoint("TOPLEFT", self, "TOPLEFT", cx, 0)
		combo:SetPoint("BOTTOMRIGHT", self, "BOTTOMLEFT", cx + self.comboWidth, 0)
		self.CPoints[i] = combo:CreateTexture(nil, "BACKGROUND")
		self.CPoints[i]:ClearAllPoints()
		self.CPoints[i]:SetAllPoints(combo)
		self.CPoints[i]:SetTexture(combotex)
		combo:SetAlpha(0.2)
		self.combos[i] = combo

		cx = cx + self.comboWidth + 1
	end			
	self.CPoints[1]:SetVertexColor(0.69, 0.31, 0.31)		
	self.CPoints[2]:SetVertexColor(0.69, 0.31, 0.31)
	self.CPoints[3]:SetVertexColor(0.65, 0.63, 0.35)
	self.CPoints[4]:SetVertexColor(0.65, 0.63, 0.35)
	self.CPoints[5]:SetVertexColor(0.33, 0.59, 0.33)

	self:RegisterEvent("PLAYER_LOGIN")
	self:RegisterEvent("UNIT_DISPLAYPOWER")
	self:RegisterEvent("UNIT_COMBO_POINTS")
	self:RegisterEvent("PLAYER_TARGET_CHANGED")
	if hideooc then
		self:RegisterEvent("PLAYER_REGEN_DISABLED")
		self:RegisterEvent("PLAYER_REGEN_ENABLED")
	end
	self:RegisterEvent("UNIT_ENTERED_VEHICLE")
	self:RegisterEvent("UNIT_EXITED_VEHICLE")

	self:SetScript("OnEvent", self.event)
end

function comboFrame:toggleCombo()
	if not hideooc and not hidenoenergy then
		return
	end
	
	if hideooc then
		if incombat == true then
			if hidenoenergy then
				if powertype == "ENERGY" then
					if not visible then
						UIFrameFadeIn(self, frameFadeIn)
						visible = true
					end
				else
					if visible then
						UIFrameFadeOut(self, frameFadeOut)
						visible = false
					end
				end
			end
		else
			if visible then
				UIFrameFadeOut(self, frameFadeOut)
				visible = false
			end
		end
	else
		if hidenoenergy then
			if powertype == "ENERGY" then
				if not visible then
					UIFrameFadeIn(self, frameFadeIn)
					visible = true
				end
			else
				if visible then
					UIFrameFadeOut(self, frameFadeOut)
					visible = false
				end
			end
		end	
	end
end

function comboFrame:updateCombo()
	local pt = GetComboPoints(unit)
	if pt == points then
		self:toggleCombo()
		return
	end
	
	if pt > points then
		for i = points + 1, pt do
			UIFrameFadeIn(self.combos[i], fadeIn)
		end
	else
		for i = pt + 1, points do
			UIFrameFadeOut(self.combos[i], fadeOut, nil, 0.2)
		end
	end
	
	points = pt
	
	self:toggleCombo()
end

function comboFrame:event(event, ...)
	if event == "PLAYER_LOGIN" then
		if powertype ~= nil then return end

		_, powertype = UnitPowerType("player")
		if UnitHasVehicleUI("player") then
			local _, powervehicle = UnitPowerType("vehicle")
			if powervehicle == "ENERGY" then
				unit = "vehicle"
				powertype = powervehicle
			end
		end

		if (hideooc and not InCombatLockdown()) or (hidenoenergy and powertype ~= "ENERGY") then
			visible = false
			self:SetAlpha(0)
		else
			visible = true
			self:SetAlpha(1)		
		end
	elseif event == "UNIT_COMBO_POINTS" then
		local curunit = select(1, ...)
		if curunit ~= unit then return end
		
		self:updateCombo()
	elseif event == "PLAYER_TARGET_CHANGED" then
		self:updateCombo()
	elseif event == "PLAYER_REGEN_DISABLED" then
		incombat = true

		self:toggleCombo()
	elseif event == "PLAYER_REGEN_ENABLED" then
		incombat = false

		self:toggleCombo()
	elseif event == "UNIT_DISPLAYPOWER" then
		local curunit = select(1, ...)
		if curunit ~= unit then return end
		
		_, powertype = UnitPowerType(unit)
		
		self:toggleCombo()
	elseif event == "UNIT_ENTERED_VEHICLE" then
		local curunit = select(1, ...)
		if curunit ~= "player" then return end

		local _, powervehicle = UnitPowerType("vehicle")
		if powervehicle == "ENERGY" then
			unit = "vehicle"
			points = 0
			powertype = powervehicle

			self:toggleCombo()
		end
	elseif event == "UNIT_EXITED_VEHICLE" then
		local curunit = select(1, ...)
		if curunit ~= "player" then return end

		unit = "player"
		points = 0
		_, powertype = UnitPowerType(unit)

		self:toggleCombo()
	end
end

comboFrame:new()