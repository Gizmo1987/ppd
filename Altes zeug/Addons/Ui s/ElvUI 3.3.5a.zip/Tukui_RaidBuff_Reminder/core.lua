if TukuiCF["raidbuffreminder"] then
	if TukuiCF["raidbuffreminder"].enable ~= true then 
		return 
	end 
end

--Locals
local flaskbuffs = BuffReminderRaidBuffs["Flask"]
local battleelixirbuffs = BuffReminderRaidBuffs["BattleElixir"]
local guardianelixirbuffs = BuffReminderRaidBuffs["GuardianElixir"]
local foodbuffs = BuffReminderRaidBuffs["Food"]
local visible
local flasked		
local battleelixired	
local guardianelixired	
local food		
local spell3
local spell4
local spell5
local spell6


--Disable ingame config options if we are not running Elv's edit.
if TukuiCF["raidbuffreminder"] then
	alwaysshow_watch = TukuiCF["raidbuffreminder"].alwaysshow_watch
end

if TukuiCF["raidbuffreminder"] then
	raidbuff_yOffset = TukuiCF["raidbuffreminder"].raidbuff_yOffset
end

if TukuiCF["raidbuffreminder"] then
	buff_fadealpha = TukuiCF["raidbuffreminder"].buff_fadealpha
end

--function determines what roll you play, only need to run this if we're not running my edit of tukui
if not TukuiDB.IsElvsEdit then
	function CheckPlayerRoll(self, event, unit)
		if event == "UNIT_AURA" and unit ~= "player" then return end
		if (TukuiDB.myclass == "PALADIN" and UnitBuff("player", GetSpellInfo(25780))) and GetCombatRatingBonus(CR_DEFENSE_SKILL) > 100 or 
		(TukuiDB.myclass == "WARRIOR" and GetBonusBarOffset() == 2) or 
		(TukuiDB.myclass == "DEATHKNIGHT" and UnitBuff("player", GetSpellInfo(48263))) or
		(TukuiDB.myclass == "DRUID" and GetBonusBarOffset() == 3) then
			TukuiDB.Role = "Tank"
		else
			local playerint = select(2, UnitStat("player", 4))
			local playeragi	= select(2, UnitStat("player", 2))
			local base, posBuff, negBuff = UnitAttackPower("player");
			local playerap = base + posBuff + negBuff;

			if ((playerap > playerint) or (playeragi > playerint)) and not (UnitBuff("player", GetSpellInfo(24858)) or UnitBuff("player", GetSpellInfo(65139))) then
				TukuiDB.Role = "Melee"
			else
				TukuiDB.Role = "Caster"
			end
		end
	end	
end

--Set buffs 3-6 depending on your roll
local function SetCasterBuffs()
	Spell3Buff = {
		20217, --"Blessing of Kings",
		25898, --"Greater Blessing of Kings",
	}
	Spell4Buff = {
		48469, --"Mark of the Wild",
		72588, --"Gift of the Wild",
	}
	Spell5Buff = {
		42995, --"Arcane Intellect"
		43002, --"Arcane Brilliance"
		61316, --"Dalaran Brilliance"
	}
	Spell6Buff = {
		48936, --"Blessing of Wisdom"
		48938, --"Greater Blessing Of Wisdom"		
		58777, --"Mana Spring Totem"
	}
end

local function SetTankBuffs()
	Spell3Buff = {
		20217, --"Blessing of Kings",
		25898, --"Greater Blessing of Kings",
	}
	Spell4Buff = {
		48469, --"Mark of the Wild",
		72588, --"Gift of the Wild",
	}
	Spell5Buff = {
		48161, --"Power Word: Fortitude"
		48162, --"Prayer of Fortitude"
	}
	Spell6Buff = {
		20911, --"Blessing of Sanctuary"
		25899, --"Greater Blessing Of Sanctuary"
	}
end

local function SetMeleeBuffs()
	Spell3Buff = {
		20217, --"Blessing of Kings",
		25898, --"Greater Blessing of Kings",
	}
	Spell4Buff = {
		48469, --"Mark of the Wild",
		72588, --"Gift of the Wild",
	}
	Spell5Buff = {
		48161, --"Power Word: Fortitude"
		48162, --"Prayer of Fortitude"
	}
	Spell6Buff = {
		48932, --"Blessing of Might"
		48934, --"Greater Blessing Of Might"
		47436, --"Battle Shout"
	}
end


-- we need to check if you have two differant elixirs if your not flasked, before we say your not flasked
local function CheckElixir(unit)
	if (battleelixirbuffs and battleelixirbuffs[1]) then
		for i, battleelixirbuffs in pairs(battleelixirbuffs) do
			local spellname = select(1, GetSpellInfo(battleelixirbuffs))
			if UnitAura("player", spellname) then
				FlaskFrame.t:SetTexture(select(3, GetSpellInfo(battleelixirbuffs)))
				battleelixired = true
				break
			else
				battleelixired = false
			end
		end
	end
	
	if (guardianelixirbuffs and guardianelixirbuffs[1]) then
		for i, guardianelixirbuffs in pairs(guardianelixirbuffs) do
			local spellname = select(1, GetSpellInfo(guardianelixirbuffs))
			if UnitAura("player", spellname) then
				guardianelixired = true
				if not battleelixired then
					FlaskFrame.t:SetTexture(select(3, GetSpellInfo(guardianelixirbuffs)))
				end
				break
			else
				guardianelixired = false
			end
		end
	end	
	
	if guardianelixired == true and battleelixired == true then
		FlaskFrame:SetAlpha(buff_fadealpha)
		flasked = true
		return
	else
		FlaskFrame:SetAlpha(1)
		flasked = false
	end
end


--Main Script
local function OnAuraChange(self, event, arg1, unit)
	if (event == "UNIT_AURA" and arg1 ~= "player") then 
		return
	end
	
	if not TukuiCF["raidbuffreminder"] then 
		CheckPlayerRoll()
	end
	if TukuiDB.Role == "Melee" then SetMeleeBuffs() end
	if TukuiDB.Role == "Caster" then SetCasterBuffs() end
	if TukuiDB.Role == "Tank" then SetTankBuffs() end	
	
	
	--Start checking buffs to see if we can find a match from the list
	if (flaskbuffs and flaskbuffs[1]) then
		FlaskFrame.t:SetTexture(select(3, GetSpellInfo(flaskbuffs[1])))
		for i, flaskbuffs in pairs(flaskbuffs) do
			local spellname = select(1, GetSpellInfo(flaskbuffs))
			if UnitAura("player", spellname) then
				FlaskFrame.t:SetTexture(select(3, GetSpellInfo(flaskbuffs)))
				FlaskFrame:SetAlpha(buff_fadealpha)
				flasked = true
				break
			else
				CheckElixir()
			end
		end
	end
	
	if (foodbuffs and foodbuffs[1]) then
		FoodFrame.t:SetTexture(select(3, GetSpellInfo(foodbuffs[1])))
		for i, foodbuffs in pairs(foodbuffs) do
			local spellname = select(1, GetSpellInfo(foodbuffs))
			if UnitAura("player", spellname) then
				FoodFrame:SetAlpha(buff_fadealpha)
				FoodFrame.t:SetTexture(select(3, GetSpellInfo(foodbuffs)))
				food = true
				break
			else
				FoodFrame:SetAlpha(1)
				food = false
			end
		end
	end
	
	for i, Spell3Buff in pairs(Spell3Buff) do
		local spellname = select(1, GetSpellInfo(Spell3Buff))
		if UnitAura("player", spellname) then
			Spell3Frame:SetAlpha(buff_fadealpha)
			Spell3Frame.t:SetTexture(select(3, GetSpellInfo(Spell3Buff)))
			spell3 = true
			break
		else
			Spell3Frame:SetAlpha(1)
			Spell3Frame.t:SetTexture(select(3, GetSpellInfo(Spell3Buff)))
			spell3 = false
		end
	end
	
	for i, Spell4Buff in pairs(Spell4Buff) do
		local spellname = select(1, GetSpellInfo(Spell4Buff))
		if UnitAura("player", spellname) then
			Spell4Frame:SetAlpha(buff_fadealpha)
			Spell4Frame.t:SetTexture(select(3, GetSpellInfo(Spell4Buff)))
			spell4 = true
			break
		else
			Spell4Frame:SetAlpha(1)
			Spell4Frame.t:SetTexture(select(3, GetSpellInfo(Spell4Buff)))
			spell4 = false
		end
	end
	
	for i, Spell5Buff in pairs(Spell5Buff) do
		local spellname = select(1, GetSpellInfo(Spell5Buff))
		if UnitAura("player", spellname) then
			Spell5Frame:SetAlpha(buff_fadealpha)
			Spell5Frame.t:SetTexture(select(3, GetSpellInfo(Spell5Buff)))
			spell5 = true
			break
		else
			Spell5Frame:SetAlpha(1)
			Spell5Frame.t:SetTexture(select(3, GetSpellInfo(Spell5Buff)))
			spell5 = false
		end
	end	

	for i, Spell6Buff in pairs(Spell6Buff) do
		local spellname = select(1, GetSpellInfo(Spell6Buff))
		if UnitAura("player", spellname) then
			Spell6Frame:SetAlpha(buff_fadealpha)
			Spell6Frame.t:SetTexture(select(3, GetSpellInfo(Spell6Buff)))
			spell6 = true
			break
		else
			Spell6Frame:SetAlpha(1)
			Spell6Frame.t:SetTexture(select(3, GetSpellInfo(Spell6Buff)))
			spell6 = false
		end
	end

	local inInstance, instanceType = IsInInstance()
	if not (inInstance and (instanceType == "raid")) and alwaysshow_watch == false then
		RaidBuffReminder:SetAlpha(0)
		visible = false
	elseif flasked == true and food == true and spell3 == true and spell4 == true and spell5 == true and spell6 == true then
		if not visible then
			RaidBuffReminder:SetAlpha(0)
			visible = false
		end
		if visible then
			UIFrameFadeOut(RaidBuffReminder, 0.5)
			visible = false
		end
	else
		if not visible then
			UIFrameFadeIn(RaidBuffReminder, 0.5)
			visible = true
		end
	end
end


--Check if we have yOffset set to lower the spawn position
local yOffset = -3
yOffset = yOffset + raidbuff_yOffset

--Create the Main bar
local raidbuff_reminder = CreateFrame("Frame", "RaidBuffReminder", TukuiMinimap)
TukuiDB.CreatePanel(raidbuff_reminder, (TukuiMinimap:GetWidth() + TukuiDB.Scale(4)), TukuiDB.Scale(28), "TOPLEFT", TukuiMinimap, "BOTTOMLEFT", 0, TukuiDB.Scale(-22 + yOffset))
raidbuff_reminder:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
raidbuff_reminder:RegisterEvent("UNIT_INVENTORY_CHANGED")
raidbuff_reminder:RegisterEvent("UNIT_AURA")
raidbuff_reminder:RegisterEvent("PLAYER_ENTERING_WORLD")
raidbuff_reminder:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
raidbuff_reminder:RegisterEvent("CHARACTER_POINTS_CHANGED")
raidbuff_reminder:RegisterEvent("ZONE_CHANGED_NEW_AREA")
raidbuff_reminder:SetScript("OnEvent", OnAuraChange)

--Function to create buttons
local function CreateButton(name, relativeTo, firstbutton)
	local button = CreateFrame("Frame", name, RaidBuffReminder)
	if firstbutton == true then
		TukuiDB.CreatePanel(button, TukuiDB.Scale(20), TukuiDB.Scale(20), "BOTTOMLEFT", relativeTo, "BOTTOMLEFT", TukuiDB.Scale(4), TukuiDB.Scale(4))
	else
		TukuiDB.CreatePanel(button, TukuiDB.Scale(20), TukuiDB.Scale(20), "LEFT", relativeTo, "RIGHT", TukuiDB.Scale(4), 0)
	end
	button:SetFrameLevel(RaidBuffReminder:GetFrameLevel() + 2)
	button:SetBackdropBorderColor(0,0,0,0)
	
	button.FrameBackdrop = CreateFrame("Frame", nil, button)
	TukuiDB.SetTemplate(button.FrameBackdrop)
	button.FrameBackdrop:SetPoint("TOPLEFT", TukuiDB.Scale(-2), TukuiDB.Scale(2))
	button.FrameBackdrop:SetPoint("BOTTOMRIGHT", TukuiDB.Scale(2), TukuiDB.Scale(-2))
	button.FrameBackdrop:SetFrameLevel(button:GetFrameLevel() - 1)	
	
	button.t = button:CreateTexture(name..".t", "OVERLAY")
	button.t:SetTexCoord(0.1, 0.9, 0.1, 0.9)
	button.t:SetAllPoints(button)
end

--Create Buttons
do
	CreateButton("FlaskFrame", RaidBuffReminder, true)
	CreateButton("FoodFrame", FlaskFrame, false)
	CreateButton("Spell3Frame", FoodFrame, false)
	CreateButton("Spell4Frame", Spell3Frame, false)
	CreateButton("Spell5Frame", Spell4Frame, false)
	CreateButton("Spell6Frame", Spell5Frame, false)
end