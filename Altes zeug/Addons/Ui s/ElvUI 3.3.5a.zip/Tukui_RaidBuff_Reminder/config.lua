if TukuiCF["raidbuffreminder"] then 
	if TukuiCF["raidbuffreminder"].enable ~= true then 
		return 
	end 
end

--Config starts here don't touch above

alwaysshow_watch = true --show frame always, will still hide if your full buffed
raidbuff_yOffset = 0 --adjust higher to move the frame up, negative number to lower the frame
buff_fadealpha = 0.2 -- the alpha level of individual buffs when they are currently active.


--raid buff reminder
BuffReminderRaidBuffs = {
	Flask = {
		67016, --"Flask of the North-SP"
		67017, --"Flask of the North-AP"
		67018, --"Flask of the North-STR"
		53758, --"Flask of Stoneblood"
		53755, --"Flask of the Frost Wyrm",
		54212, --"Flask of Pure Mojo",
		53760, --"Flask of Endless Rage",
		17627, --"Flask of Distilled Wisdom", 
	},
	BattleElixir = {
		33721, --"Spellpower Elixir",
		53746, --"Wrath Elixir",
		28497, --"Elixir of Mighty Agility",
		53748, --"Elixir of Mighty Strength",
		60346, --"Elixir of Lightning Speed",
		60344, --"Elixir of Expertise",
		60341, --"Elixir of Deadly Strikes",
		60345, --"Elixir of Armor Piercing",
		60340, --"Elixir of Accuracy",
		53749, --"Guru's Elixir",
	},
	GuardianElixir = {
		60343, --"Elixir of Mighty Defense",
		53751, --"Elixir of Mighty Fortitude",
		53764, --"Elixir of Mighty Mageblood",
		60347, --"Elixir of Mighty Thoughts",
		53763, --"Elixir of Protection",
		53747, --"Elixir of Spirit",
	},
	Food = {
		57325, -- 80 AP
		57327, -- 46 SP
		57329, -- 40 CS
		57332, -- 40 Haste
		57334, -- 20 MP5
		57356, -- 40 EXP
		57358, -- 40 ARP
		57360, -- 40 Hit
		57363, -- Track Humanoids
		57365, -- 40 Spirit
		57367, -- 40 AGI
		57371, -- 40 STR
		57373, -- Track Beasts
		57399, -- 80AP, 46SP (fish feast)
		59230, -- 40 DODGE
		65247, -- Pet 40 STR
	},
}
		--27179, --Holy Shield Tester