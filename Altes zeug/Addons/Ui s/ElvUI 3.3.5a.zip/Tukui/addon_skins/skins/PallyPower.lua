﻿--(C)2010 MrRuben5

local TukuiAddOnSkin = CreateFrame("Frame")
TukuiAddOnSkin:RegisterEvent("PLAYER_LOGIN")
TukuiAddOnSkin:SetScript("OnEvent", function(self, event, addon)
	if IsAddOnLoaded("PallyPower") and TukuiCF["skin"].pallypower == true  then
		TukuiDB.SetTemplate(PallyPowerConfigFrame)
		local _G = _G
		local _, frame, tex
		local font = TukuiCF["media"]["font"]

		local one = TukuiDB.Scale(1)
		local two = TukuiDB.Scale(2)
		local three = TukuiDB.Scale(3)
		local four = TukuiDB.Scale(4)
		local thirty = TukuiDB.Scale(30)
		local sixty = TukuiDB.Scale(60)

		-- ZzZzZz....
		PALLYPOWER_DEFAULT_VALUES.cBuffNeedAll     = {r = 99/255, g = 0, b = 0, t = 0.8}
		PALLYPOWER_DEFAULT_VALUES.cBuffNeedSome    = {r = 0.5, g = 0.5, b = 0.5, t = 0.8}
		PALLYPOWER_DEFAULT_VALUES.cBuffNeedSpecial = {r = 0, g = 0, b = 99/255, t = 0.8}
		PALLYPOWER_DEFAULT_VALUES.cBuffGood        = {r = 0.1, g = 0.1, b = 0.1, t = 0.8}
		 
		PallyPower.opt.cBuffNeedAll     = {r = 99/255, g = 0, b = 0, t = 0.8}
		PallyPower.opt.cBuffNeedSome    = {r = 0.5, g = 0.5, b = 0.5, t = 0.8}
		PallyPower.opt.cBuffNeedSpecial = {r = 0, g = 0, b = 99/255, t = 0.8}
		PallyPower.opt.cBuffGood        = {r = 0.1, g = 0.1, b = 0.1, t = 0.8}
		 
		PALLYPOWER_DEFAULT_VALUES.display.gapping = 3
		 
		PallyPower.opt.display.gapping = three
		 
		local _applyskin = PallyPower.ApplySkin
		function PallyPower:ApplySkin(skinname)

			local needSkinning = {PallyPowerAuto, PallyPowerRF, PallyPowerAura}

			for i = 1, PALLYPOWER_MAXCLASSES do
				table.insert(needSkinning, PallyPower.classButtons[i])
				for j = 1, PALLYPOWER_MAXPERCLASS do
					table.insert(needSkinning, PallyPower.playerButtons[i][j])
				end
			end
					
			for _,frame in pairs(needSkinning) do
				frame:SetBackdrop({
				bgFile = TukuiCF["media"].blank,
					insets = { left = two, right = two, top = two, bottom = two }
				})
				if not frame.bg then
					frame.bg = CreateFrame('Frame', nil, frame)
					frame.bg:SetAllPoints(frame)
					frame.bg:SetFrameLevel(frame:GetFrameLevel()-1)
					TukuiDB.SetTemplate(frame.bg)
				end
					
				local fname = frame:GetName()
				for _, fontstring in pairs({"Time", "Time2", "Text", "Player1", "Player2", "Rng", "Dead", "Name"}) do
					local fs = _G[fname..fontstring]
					if fs then
						local _, size = fs:GetFont()
						fs:SetFont(font, size, 'THINOUTLINE')
						fs:SetShadowColor(0,0,0,0)
						if not fname:find("PowerC%d+P%d+$") then
							if fontstring == "Text" then
								fs:ClearAllPoints()
								fs:SetJustifyH("LEFT")
								fs:SetWidth(999)
								fs:SetPoint("LEFT",fname:find("Auto$") and (thirty + two) or (sixty + two), 0)
							elseif fontstring == "Time" or fontstring == "Time2" then
								fs:ClearAllPoints()
								fs:SetWidth(999)
								fs:SetJustifyH("RIGHT")
								fs:SetPoint(fontstring == "Time" and "BOTTOMRIGHT" or "TOPRIGHT", frame, "RIGHT", 0, 0)
							end
						end
					end
				end
				for _, tex in pairs({"Icon", "ClassIcon", "BuffIcon", "IconSeal"}) do
					if _G[fname..tex] and not _G[fname..'New'..tex] then
						local oldicon = _G[fname..tex]
						oldicon:SetAlpha(0)	
						oldicon:ClearAllPoints()
						-- Swap seal and RF icon
						if fname == "PallyPowerRF" then
							if tex == "IconSeal" then
								oldicon:SetPoint('LEFT', four, 0)
							else
								oldicon:SetPoint('LEFT', thirty + four, 0)
							end
						-- Aura icon / Auto icon
						elseif fname:find("(Au[rt][ao])$") then
							oldicon:SetPoint('LEFT', four, 0)
						-- Player frames
						elseif fname:find("PowerC%d+P%d+$") then
							oldicon:SetPoint('TOPLEFT', four, -four)
						-- CLass frames
						elseif fname:find("PowerC%d+$") then
							if tex == "ClassIcon" then
								oldicon:SetPoint('LEFT', four, 0)
							else
								oldicon:SetPoint('LEFT', thirty + four, 0)
							end
						else
							--oldicon:SetPoint('TOPLEFT', four, -four)
						end
						
						local panel = CreateFrame("Frame", fname..'New'..tex, frame)
						panel:SetAllPoints(oldicon)
						TukuiDB.SetTemplate(panel)
							
						local icon = panel:CreateTexture()
						panel.icon = panel
						icon:SetPoint("TOPLEFT", panel, TukuiDB.Scale(2), TukuiDB.Scale(-2))
						icon:SetPoint("BOTTOMRIGHT", panel, TukuiDB.Scale(-2), TukuiDB.Scale(2))
						icon:SetTexCoord(.08, .92, .08, .92)
						icon:SetTexture(oldicon:GetTexture())
						--hacky tacky, yay!
						oldicon.SetTexture = function(tex,texstring)
							icon:SetTexture(texstring)
							--hide the border/bg if icon:SetTexture() is sued to hide the icon
							if not texstring then
								panel:SetAlpha(0)
							else
								panel:SetAlpha(1)
							end
						end
						oldicon.SetVertexColor = function(self, ...)
								icon:SetVertexColor(...)
						end
					end
				end			
			end
		end

		local _updatelayout = PallyPower.UpdateLayout
		function PallyPower:UpdateLayout()
			self.opt.display.gapping = three

				
			_updatelayout(self)
				
			-- Update button layout for aura, rf and auto
			for _, button in pairs({PallyPowerAuto, PallyPowerRF, PallyPowerAura}) do
				local a, p, b, x, y = button:GetPoint()
				
				local align = tonumber(self.opt.display.alignClassButtons)
					
				y = align < 4 and (y - three) or (y + three)
				
				if not InCombatLockdown() then
					button:SetPoint(a,p,b,x,y)
				end
			end
		end
		PallyPower:ApplySkin()
		PallyPower:UpdateLayout()
	end
end)