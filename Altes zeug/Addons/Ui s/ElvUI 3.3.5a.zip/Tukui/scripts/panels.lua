-- BUTTON SIZES
if TukuiCF["general"].minimalistic == true then
	TukuiDB.buttonsize = TukuiDB.Scale(27)
	TukuiDB.buttonspacing = TukuiDB.Scale(4)
	TukuiDB.petbuttonsize = TukuiDB.Scale(24)
	TukuiDB.petbuttonspacing = TukuiDB.Scale(4)
else
	TukuiDB.buttonsize = TukuiDB.Scale(27)
	TukuiDB.buttonspacing = TukuiDB.Scale(4)
	TukuiDB.petbuttonsize = TukuiDB.Scale(24)
	TukuiDB.petbuttonspacing = TukuiDB.Scale(4)
end

-- INFO LEFT (FOR STATS)
local ileft = CreateFrame("Frame", "TukuiInfoLeft", UIParent)
TukuiDB.CreateMinPanel(ileft, TukuiCF["chat"].chatwidth, 23, "BOTTOMLEFT", UIParent, "BOTTOMLEFT", TukuiDB.Scale(4), TukuiDB.Scale(4))

-- INFO RIGHT (FOR STATS)
local iright = CreateFrame("Frame", "TukuiInfoRight", UIParent)
TukuiDB.CreateMinPanel(iright, TukuiCF["chat"].chatwidth, 23, "BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", TukuiDB.Scale(-4), TukuiDB.Scale(4))

-- MINIMAP STAT FRAMES
if TukuiMinimap then
	local minimapstatsleft = CreateFrame("Frame", "TukuiMinimapStatsLeft", TukuiMinimap)
	TukuiDB.CreateMinPanel(minimapstatsleft, ((TukuiMinimap:GetWidth() + 4) / 2) - 2, 19, "TOPLEFT", TukuiMinimap, "BOTTOMLEFT", 0, TukuiDB.Scale(-3))

	local minimapstatsright = CreateFrame("Frame", "TukuiMinimapStatsRight", TukuiMinimap)
	TukuiDB.CreateMinPanel(minimapstatsright, ((TukuiMinimap:GetWidth() + 4) / 2) -2, 19, "TOPRIGHT", TukuiMinimap, "BOTTOMRIGHT", 0, TukuiDB.Scale(-3))
	
	if TukuiCF["general"].minimalistic == true then
		local minimapstatscenter = CreateFrame("Frame", "TukuiMinimapStatsCenter", TukuiMinimap)
		TukuiDB.CreatePanel(minimapstatscenter, ((TukuiMinimap:GetWidth() + 4) / 2.3) -2, 16, "CENTER", TukuiMinimap, "BOTTOM", 0, 0)
		minimapstatscenter:SetFrameLevel(Minimap:GetFrameLevel() +1)
	end
end

-- MAIN ACTION BAR
local barbg = CreateFrame("Frame", "TukuiActionBarBackground", UIParent)
TukuiDB.CreateMinPanel(barbg, 1, 1, "BOTTOM", UIParent, "BOTTOM", 0, TukuiDB.Scale(4))
barbg:SetWidth(((TukuiDB.buttonsize * 12) + (TukuiDB.buttonspacing * 13)))
if TukuiCF["actionbar"].bottomrows == 2 then
	barbg:SetHeight((TukuiDB.buttonsize * 2) + (TukuiDB.buttonspacing * 3))
else
	barbg:SetHeight(TukuiDB.buttonsize + (TukuiDB.buttonspacing * 2))
end

-- INVISIBLE FRAME
local invbarbg = CreateFrame("Frame", "TukuiActionBarInvBackground", UIParent)
invbarbg:SetWidth(barbg:GetWidth())
invbarbg:SetHeight(barbg:GetHeight())
invbarbg:SetPoint("BOTTOM", barbg)

-- VEHICLE BAR
local vehiclebarbg = CreateFrame("Frame", "TukuiVehicleActionBarBackground", UIParent)
TukuiDB.CreateMinPanel(vehiclebarbg, 1, 1, "BOTTOM", UIParent, "BOTTOM", 0, TukuiDB.Scale(4))
vehiclebarbg:SetWidth((TukuiDB.buttonsize * 12) + (TukuiDB.buttonspacing * 13))
vehiclebarbg:SetHeight(TukuiDB.buttonsize + (TukuiDB.buttonspacing * 2))
vehiclebarbg:SetAlpha(0)

--SPLIT BAR PANELS
if TukuiCF["actionbar"].splitbar == true then
	local splitleft = CreateFrame("Frame", "TukuiSplitActionBarLeftBackground", TukuiActionBarBackground)
	TukuiDB.CreateMinPanel(splitleft, (TukuiDB.buttonsize * 3) + (TukuiDB.buttonspacing * 4), TukuiActionBarInvBackground:GetHeight(), "RIGHT", TukuiActionBarInvBackground, "LEFT", TukuiDB.Scale(-4), 0)

	local splitright = CreateFrame("Frame", "TukuiSplitActionBarRightBackground", TukuiActionBarBackground)
	TukuiDB.CreateMinPanel(splitright, (TukuiDB.buttonsize * 3) + (TukuiDB.buttonspacing * 4), TukuiActionBarInvBackground:GetHeight(), "LEFT", TukuiActionBarInvBackground, "RIGHT", TukuiDB.Scale(4), 0)

	local splitbartop = CreateFrame("Frame", nil, TukuiActionBarBackground)
	TukuiDB.CreateMinPanel(splitbartop, (TukuiActionBarBackground:GetWidth() * 1.5), TukuiDB.Scale(2), "CENTER", "TukuiActionBarInvBackground", "CENTER", 0, 15)
	splitbartop:SetFrameLevel(TukuiActionBarBackground:GetFrameLevel() - 1)
	
	local splitbarbottom = CreateFrame("Frame", nil, TukuiActionBarBackground)
	TukuiDB.CreateMinPanel(splitbarbottom, (TukuiActionBarBackground:GetWidth() * 1.5), TukuiDB.Scale(2), "CENTER", "TukuiActionBarInvBackground", "CENTER", 0, -15)
	splitbarbottom:SetFrameLevel(TukuiActionBarBackground:GetFrameLevel() - 1)
end





-- RIGHT BAR
if TukuiCF["actionbar"].enable == true then
	local barbgr = CreateFrame("Frame", "TukuiActionBarBackgroundRight", MultiBarRight)
	TukuiDB.CreateMinPanel(barbgr, 1, (TukuiDB.buttonsize * 12) + (TukuiDB.buttonspacing * 13), "RIGHT", UIParent, "RIGHT", TukuiDB.Scale(-4), TukuiDB.Scale(8))
	if TukuiCF["actionbar"].rightbars == 1 then
		barbgr:SetWidth(TukuiDB.buttonsize + (TukuiDB.buttonspacing * 2))
	elseif TukuiCF["actionbar"].rightbars == 2 then
		barbgr:SetWidth((TukuiDB.buttonsize * 2) + (TukuiDB.buttonspacing * 3))
	elseif TukuiCF["actionbar"].rightbars == 3 then
		barbgr:SetWidth((TukuiDB.buttonsize * 3) + (TukuiDB.buttonspacing * 4))
	else
		barbgr:Hide()
	end

	local petbg = CreateFrame("Frame", "TukuiPetActionBarBackground", PetActionButton1)
	if TukuiCF["actionbar"].rightbars > 0 then
		TukuiDB.CreateMinPanel(petbg, TukuiDB.petbuttonsize + (TukuiDB.petbuttonspacing * 2), (TukuiDB.petbuttonsize * 10) + (TukuiDB.petbuttonspacing * 11), "RIGHT", barbgr, "LEFT", TukuiDB.Scale(-6), 0)
	else
		TukuiDB.CreateMinPanel(petbg, TukuiDB.petbuttonsize + (TukuiDB.petbuttonspacing * 2), (TukuiDB.petbuttonsize * 10) + (TukuiDB.petbuttonspacing * 11), "RIGHT", UIParent, "RIGHT", TukuiDB.Scale(-6), TukuiDB.Scale(-13.5))
	end
	
	local ltpetbg1 = CreateFrame("Frame", "TukuiLineToPetActionBarBackground", petbg)
	TukuiDB.CreateMinPanel(ltpetbg1, 30, 265, "LEFT", petbg, "RIGHT", 0, 0)
	ltpetbg1:SetFrameLevel(0)
	ltpetbg1:SetAlpha(.8)
end

-- CHAT BACKGROUND LEFT
local chatlbg = CreateFrame("Frame", "ChatLBackground", UIParent)

-- CHAT BACKGROUND RIGHT
local chatrbg = CreateFrame("Frame", "ChatRBackground", UIParent)


if TukuiCF["general"].minimalistic == false then
	if TukuiCF["chat"].showbackdrop == true then
		TukuiDB.CreateGradientOverlay("ChatLGradient","LEFT",ChatLBackground,"HORIZONTAL")
		TukuiDB.CreateGradientOverlay("ChatRGradient","RIGHT",ChatRBackground,"HORIZONTAL")
	end
	TukuiDB.CreatePanel(chatlbg, (TukuiInfoLeft:GetWidth()), TukuiCF["chat"].chatheight+6, "BOTTOMLEFT", TukuiInfoLeft, "TOPLEFT", 0,  TukuiDB.Scale(4)) 
	TukuiDB.CreatePanel(chatrbg, (TukuiInfoLeft:GetWidth()), TukuiCF["chat"].chatheight+6, "BOTTOMLEFT", TukuiInfoRight, "TOPLEFT", 0,  TukuiDB.Scale(4)) 	
else
	TukuiDB.CreatePanel(chatlbg, (TukuiInfoLeft:GetWidth()), TukuiCF["chat"].chatheight+6, "BOTTOMLEFT", TukuiInfoLeft, "BOTTOMLEFT", 0, 0) 
	TukuiDB.CreatePanel(chatrbg, (TukuiInfoLeft:GetWidth()), TukuiCF["chat"].chatheight+6, "BOTTOMLEFT", TukuiInfoRight, "BOTTOMLEFT", 0, 0) 	
end

chatrbg:SetBackdropBorderColor(0,0,0,0)	
chatrbg:SetBackdropColor(0,0,0,0)
chatlbg:SetBackdropBorderColor(0,0,0,0)	
chatlbg:SetBackdropColor(0,0,0,0)


-- BATTLEGROUND STATS FRAME LEFT
if TukuiCF["datatext"].battleground == true and not TukuiCF["general"].minimalistic == true then
	local bglframe = CreateFrame("Frame", "TukuiInfoLeftBattleGround", UIParent)
	TukuiDB.CreateMinPanel(bglframe, 1, 1, "TOPLEFT", UIParent, "BOTTOMLEFT", 0, 0)
	bglframe:SetAllPoints(ileft)
	bglframe:SetFrameStrata("LOW")
	bglframe:SetFrameLevel(3)
	bglframe:EnableMouse(true)
	local function OnEvent(self, event)
		if event == "PLAYER_ENTERING_WORLD" then
			inInstance, instanceType = IsInInstance()
			if inInstance and (instanceType == "pvp") then
				bglframe:Show()
				ileft:EnableMouse(true)
				ileft:SetScript("OnMouseDown", function(self) ToggleFrame(TukuiInfoRightBattleGround) ToggleFrame(TukuiInfoLeftBattleGround) end)
			else
				bglframe:Hide()
				ileft:EnableMouse(false)
				ileft:SetScript("OnMouseDown", function(self) ToggleFrame(TukuiInfoRightBattleGround) ToggleFrame(TukuiInfoLeftBattleGround) end)
			end
		end
	end
	bglframe:SetScript("OnEnter", function(self)
	local numScores = GetNumBattlefieldScores()
		for i=1, numScores do
			name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class, classToken, damageDone, healingDone  = GetBattlefieldScore(i);
			if ( name ) then
				if ( name == UnitName("player") ) then
					local color = RAID_CLASS_COLORS[select(2, UnitClass("player"))]
					local classcolor = ("|cff%.2x%.2x%.2x"):format(color.r * 255, color.g * 255, color.b * 255)
					GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT", 0, TukuiDB.Scale(4));
					GameTooltip:ClearLines()
					GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, TukuiDB.Scale(1))
					GameTooltip:ClearLines()
					GameTooltip:AddDoubleLine(tukuilocal.datatext_ttstatsfor, classcolor..name.."|r")
					GameTooltip:AddLine' '
					--Add extra statistics to watch based on what BG you are in.
					if GetRealZoneText() == "Arathi Basin" then --
						GameTooltip:AddDoubleLine(tukuilocal.datatext_basesassaulted,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_basesdefended,GetBattlefieldStatData(i, 2),1,1,1)
					elseif GetRealZoneText() == "Warsong Gulch" then --
						GameTooltip:AddDoubleLine(tukuilocal.datatext_flagscaptured,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_flagsreturned,GetBattlefieldStatData(i, 2),1,1,1)
					elseif GetRealZoneText() == "Eye of the Storm" then --
						GameTooltip:AddDoubleLine(tukuilocal.datatext_flagscaptured,GetBattlefieldStatData(i, 1),1,1,1)
					elseif GetRealZoneText() == "Alterac Valley" then
						GameTooltip:AddDoubleLine(tukuilocal.datatext_graveyardsassaulted,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_graveyardsdefended,GetBattlefieldStatData(i, 2),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_towersassaulted,GetBattlefieldStatData(i, 3),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_towersdefended,GetBattlefieldStatData(i, 4),1,1,1)
					elseif GetRealZoneText() == "Strand of the Ancients" then
						GameTooltip:AddDoubleLine(tukuilocal.datatext_demolishersdestroyed,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_gatesdestroyed,GetBattlefieldStatData(i, 2),1,1,1)
					elseif GetRealZoneText() == "Isle of Conquest" then
						GameTooltip:AddDoubleLine(tukuilocal.datatext_basesassaulted,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_basesdefended,GetBattlefieldStatData(i, 2),1,1,1)
					end					
					GameTooltip:Show()
				end
			end
		end
	end) 

	bglframe:SetScript("OnMouseDown", function(self) ToggleFrame(TukuiInfoRightBattleGround) ToggleFrame(TukuiInfoLeftBattleGround) end)
	bglframe:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	bglframe:RegisterEvent("PLAYER_ENTERING_WORLD")
	bglframe:RegisterEvent("ZONE_CHANGED_NEW_AREA")
	bglframe:SetScript("OnEvent", OnEvent)
end

-- BATTLEGROUND STATS FRAME RIGHT

if TukuiCF["datatext"].battleground == true and not TukuiCF["general"].minimalistic == true then
	local bgrframe = CreateFrame("Frame", "TukuiInfoRightBattleGround", UIParent)
	TukuiDB.CreateMinPanel(bgrframe, 1, 1, "TOPLEFT", UIParent, "BOTTOMLEFT", 0, 0)
	bgrframe:SetAllPoints(iright)
	bgrframe:SetFrameStrata("LOW")
	bgrframe:SetFrameLevel(3)
	bgrframe:EnableMouse(true)
	local function OnEvent(self, event)
		if event == "PLAYER_ENTERING_WORLD" then
			inInstance, instanceType = IsInInstance()
			if inInstance and (instanceType == "pvp") then
				bgrframe:Show()
				iright:EnableMouse(true)
				iright:SetScript("OnMouseDown", function(self) ToggleFrame(TukuiInfoRightBattleGround) ToggleFrame(TukuiInfoLeftBattleGround) end)
			else
				bgrframe:Hide()
				iright:EnableMouse(false)
				iright:SetScript("OnMouseDown", function(self) ToggleFrame(TukuiInfoRightBattleGround) ToggleFrame(TukuiInfoLeftBattleGround) end)
			end
		end
	end
	bgrframe:SetScript("OnEnter", function(self)
	local numScores = GetNumBattlefieldScores()
		for i=1, numScores do
			name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class, classToken, damageDone, healingDone  = GetBattlefieldScore(i);
			if ( name ) then
				if ( name == UnitName("player") ) then
					local color = RAID_CLASS_COLORS[select(2, UnitClass("player"))]
					local classcolor = ("|cff%.2x%.2x%.2x"):format(color.r * 255, color.g * 255, color.b * 255)
					GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT", 0, TukuiDB.Scale(4));
					GameTooltip:ClearLines()
					GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, TukuiDB.Scale(1))
					GameTooltip:ClearLines()
					GameTooltip:AddDoubleLine(tukuilocal.datatext_ttstatsfor, classcolor..name.."|r")
					GameTooltip:AddLine' '
					--Add extra statistics to watch based on what BG you are in.
					if GetRealZoneText() == "Arathi Basin" then --
						GameTooltip:AddDoubleLine(tukuilocal.datatext_basesassaulted,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_basesdefended,GetBattlefieldStatData(i, 2),1,1,1)
					elseif GetRealZoneText() == "Warsong Gulch" then --
						GameTooltip:AddDoubleLine(tukuilocal.datatext_flagscaptured,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_flagsreturned,GetBattlefieldStatData(i, 2),1,1,1)
					elseif GetRealZoneText() == "Eye of the Storm" then --
						GameTooltip:AddDoubleLine(tukuilocal.datatext_flagscaptured,GetBattlefieldStatData(i, 1),1,1,1)
					elseif GetRealZoneText() == "Alterac Valley" then
						GameTooltip:AddDoubleLine(tukuilocal.datatext_graveyardsassaulted,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_graveyardsdefended,GetBattlefieldStatData(i, 2),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_towersassaulted,GetBattlefieldStatData(i, 3),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_towersdefended,GetBattlefieldStatData(i, 4),1,1,1)
					elseif GetRealZoneText() == "Strand of the Ancients" then
						GameTooltip:AddDoubleLine(tukuilocal.datatext_demolishersdestroyed,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_gatesdestroyed,GetBattlefieldStatData(i, 2),1,1,1)
					elseif GetRealZoneText() == "Isle of Conquest" then
						GameTooltip:AddDoubleLine(tukuilocal.datatext_basesassaulted,GetBattlefieldStatData(i, 1),1,1,1)
						GameTooltip:AddDoubleLine(tukuilocal.datatext_basesdefended,GetBattlefieldStatData(i, 2),1,1,1)
					end					
					GameTooltip:Show()
				end
			end
		end
	end) 

	bgrframe:SetScript("OnMouseDown", function(self) ToggleFrame(TukuiInfoRightBattleGround) ToggleFrame(TukuiInfoLeftBattleGround) end)
	bgrframe:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	bgrframe:RegisterEvent("PLAYER_ENTERING_WORLD")
	bgrframe:RegisterEvent("ZONE_CHANGED_NEW_AREA")
	bgrframe:SetScript("OnEvent", OnEvent)
end

--BOTTOM FRAME
local bottompanel = CreateFrame("Frame", "TukuiBottomPanel", UIParent)
TukuiDB.CreateMinPanel(bottompanel, (TukuiDB.Scale(UIParent:GetWidth()) + (TukuiDB.mult * 2))*2, 23, "BOTTOMLEFT", UIParent, "BOTTOMLEFT", TukuiDB.Scale(-TukuiDB.mult), TukuiDB.Scale(-20/2))
bottompanel:SetFrameLevel(TukuiInfoLeft:GetFrameLevel() - 1)



