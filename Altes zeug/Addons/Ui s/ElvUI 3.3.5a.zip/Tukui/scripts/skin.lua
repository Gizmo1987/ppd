-- NOTE: i'm not reskinning everything, too much thing to do and anyway, 80% of all frames are redone for Cataclysm
-- I don't want to loose my time reskinning all panels/frame, because in a couple of month we need to redo it. :x
-- thank to karudon for helping me reskinning some elements in default interface.

local function SetModifiedBackdrop(self)
	local color = RAID_CLASS_COLORS[TukuiDB.myclass]
	self:SetBackdropColor(color.r, color.g, color.b, 0.3)
	self:SetBackdropBorderColor(color.r, color.g, color.b)
end

local function SetOriginalBackdrop(self)
	self:SetBackdropColor(unpack(TukuiCF["media"].backdropcolor))
	self:SetBackdropBorderColor(unpack(TukuiCF["media"].bordercolor))
end

local function SkinButton(f)
	f:SetNormalTexture("")
	f:SetHighlightTexture("")
	f:SetPushedTexture("")
	f:SetDisabledTexture("")
	TukuiDB.SetTemplate(f)
	f:HookScript("OnEnter", SetModifiedBackdrop)
	f:HookScript("OnLeave", SetOriginalBackdrop)
end

local TukuiSkin = CreateFrame("Frame")
TukuiSkin:RegisterEvent("ADDON_LOADED")
TukuiSkin:SetScript("OnEvent", function(self, event, addon)
	if IsAddOnLoaded("Skinner") then return end
	
	-- stuff not in Blizzard load-on-demand
	if addon == "Tukui" then
		-- Blizzard frame we want to reskin
		local skins = {
			"StaticPopup1",
			"StaticPopup2",
			"GameMenuFrame",
			"InterfaceOptionsFrame",
			"VideoOptionsFrame",
			"AudioOptionsFrame",
			"LFDDungeonReadyStatus",
			"BNToastFrame",
			"TicketStatusFrameButton",
			"DropDownList1MenuBackdrop",
			"DropDownList2MenuBackdrop",
			"DropDownList1Backdrop",
			"DropDownList2Backdrop",
			"LFDSearchStatus",
			"AutoCompleteBox",
			"ColorPickerFrame",
			"ConsolidatedBuffsTooltip",
			"ReadyCheckFrame",
		}
		
		local ChatMenus = {
			"ChatMenu",
			"EmoteMenu",
			"LanguageMenu",
			"VoiceMacroMenu",		
		}
		--
		for i = 1, getn(ChatMenus) do
			if _G[ChatMenus[i]] == _G["ChatMenu"] then
				_G[ChatMenus[i]]:HookScript("OnShow", function(self) TukuiDB.SetTemplate(self) self:SetBackdropColor(unpack(TukuiCF["media"].backdropfadecolor)) self:ClearAllPoints() self:SetPoint("BOTTOMLEFT", ChatFrame1, "TOPLEFT", 0, TukuiDB.Scale(30)) end)
			else
				_G[ChatMenus[i]]:HookScript("OnShow", function(self) TukuiDB.SetTemplate(self) self:SetBackdropColor(unpack(TukuiCF["media"].backdropfadecolor)) end)
			end
		end

		-- reskin popup buttons
		for i = 1, 2 do
			for j = 1, 2 do
				SkinButton(_G["StaticPopup"..i.."Button"..j])
			end
		end
		
		for i = 1, getn(skins) do
			TukuiDB.SetTemplate(_G[skins[i]])
			_G[skins[i]]:SetBackdropColor(unpack(TukuiCF["media"].backdropfadecolor))
		end
		
		-- reskin all esc/menu buttons
		local BlizzardMenuButtons = {
			"Options", 
			"SoundOptions", 
			"UIOptions", 
			"Keybindings", 
			"Macros", 
			"AddOns", 
			"Logout", 
			"Quit", 
			"Continue", 
			"MacOptions"
		}
		
		for i = 1, getn(BlizzardMenuButtons) do
			local TukuiMenuButtons = _G["GameMenuButton"..BlizzardMenuButtons[i]]
			if TukuiMenuButtons then
				SkinButton(TukuiMenuButtons)
			end
		end
		
		if IsAddOnLoaded("OptionHouse") then
			SkinButton(GameMenuButtonOptionHouse)
		end
		
		-- hide header textures and move text/buttons.
		local BlizzardHeader = {
			"GameMenuFrame", 
			"InterfaceOptionsFrame", 
			"AudioOptionsFrame", 
			"VideoOptionsFrame",
			"ColorPickerFrame"
		}
		
		for i = 1, getn(BlizzardHeader) do
			local title = _G[BlizzardHeader[i].."Header"]			
			if title then
				title:SetTexture("")
				title:ClearAllPoints()
				if title == _G["GameMenuFrameHeader"] then
					title:SetPoint("TOP", GameMenuFrame, 0, 7)
				else
					title:SetPoint("TOP", BlizzardHeader[i], 0, 0)
				end
			end
		end
		
		-- here we reskin all "normal" buttons
		local BlizzardButtons = {
			"VideoOptionsFrameOkay", 
			"VideoOptionsFrameCancel", 
			"VideoOptionsFrameDefaults", 
			"VideoOptionsFrameApply", 
			"AudioOptionsFrameOkay", 
			"AudioOptionsFrameCancel", 
			"AudioOptionsFrameDefaults", 
			"InterfaceOptionsFrameDefaults", 
			"InterfaceOptionsFrameOkay", 
			"InterfaceOptionsFrameCancel",
			"ColorPickerOkayButton",
			"ColorPickerCancelButton",
			"ReadyCheckFrameYesButton",
			"ReadyCheckFrameNoButton",
		}
		
		for i = 1, getn(BlizzardButtons) do
		local TukuiButtons = _G[BlizzardButtons[i]]
			if TukuiButtons then
				SkinButton(TukuiButtons)
			end
		end
		
		-- if a button position is not really where we want, we move it here
		_G["VideoOptionsFrameCancel"]:ClearAllPoints()
		_G["VideoOptionsFrameCancel"]:SetPoint("RIGHT",_G["VideoOptionsFrameApply"],"LEFT",-4,0)		 
		_G["VideoOptionsFrameOkay"]:ClearAllPoints()
		_G["VideoOptionsFrameOkay"]:SetPoint("RIGHT",_G["VideoOptionsFrameCancel"],"LEFT",-4,0)	
		_G["AudioOptionsFrameOkay"]:ClearAllPoints()
		_G["AudioOptionsFrameOkay"]:SetPoint("RIGHT",_G["AudioOptionsFrameCancel"],"LEFT",-4,0)
		_G["InterfaceOptionsFrameOkay"]:ClearAllPoints()
		_G["InterfaceOptionsFrameOkay"]:SetPoint("RIGHT",_G["InterfaceOptionsFrameCancel"],"LEFT", -4,0)
		_G["ColorPickerCancelButton"]:ClearAllPoints()
		_G["ColorPickerOkayButton"]:ClearAllPoints()
		_G["ColorPickerCancelButton"]:SetPoint("BOTTOMRIGHT", ColorPickerFrame, "BOTTOMRIGHT", -6, 6)
		_G["ColorPickerOkayButton"]:SetPoint("RIGHT",_G["ColorPickerCancelButton"],"LEFT", -4,0)
		_G["ReadyCheckFrameYesButton"]:SetParent(_G["ReadyCheckFrame"])
		_G["ReadyCheckFrameNoButton"]:SetParent(_G["ReadyCheckFrame"]) 
		_G["ReadyCheckFrameYesButton"]:SetPoint("RIGHT", _G["ReadyCheckFrame"], "CENTER", -1, 0)
		_G["ReadyCheckFrameNoButton"]:SetPoint("LEFT", _G["ReadyCheckFrameYesButton"], "RIGHT", 3, 0)
		_G["ReadyCheckFrameText"]:SetParent(_G["ReadyCheckFrame"])	
		_G["ReadyCheckFrameText"]:ClearAllPoints()
		_G["ReadyCheckFrameText"]:SetPoint("TOP", 0, -12)
		
		-- others
		_G["ReadyCheckListenerFrame"]:SetAlpha(0)
		_G["ReadyCheckFrame"]:HookScript("OnShow", function(self) if UnitIsUnit("player", self.initiator) then self:Hide() end end) -- bug fix, don't show it if initiator
	end
		
	-- mac menu/option panel, made by affli.
	if IsMacClient() then
		-- Skin main frame and reposition the header
		TukuiDB.SetTemplate(MacOptionsFrame)
		MacOptionsFrameHeader:SetTexture("")
		MacOptionsFrameHeader:ClearAllPoints()
		MacOptionsFrameHeader:SetPoint("TOP", MacOptionsFrame, 0, 0)
 
		--Skin internal frames
		TukuiDB.SetTemplate(MacOptionsFrameMovieRecording)
		TukuiDB.SetTemplate(MacOptionsITunesRemote)
 
		--Skin buttons
		SkinButton(_G["MacOptionsFrameCancel"])
		SkinButton(_G["MacOptionsFrameOkay"])
		SkinButton(_G["MacOptionsButtonKeybindings"])
		SkinButton(_G["MacOptionsFrameDefaults"])
		SkinButton(_G["MacOptionsButtonCompress"])
 
		--Reposition and resize buttons
		tPoint, tRTo, tRP, tX, tY =  _G["MacOptionsButtonCompress"]:GetPoint()
		_G["MacOptionsButtonCompress"]:SetWidth(136)
		_G["MacOptionsButtonCompress"]:SetPoint(tPoint, tRTo, tRP, tX+4, tY)
 
		_G["MacOptionsFrameCancel"]:SetWidth(96)
		_G["MacOptionsFrameCancel"]:SetHeight(22)
		tPoint, tRTo, tRP, tX, tY =  _G["MacOptionsFrameCancel"]:GetPoint()
		_G["MacOptionsFrameCancel"]:SetPoint(tPoint, tRTo, tRP, tX-2, tY)
 
		_G["MacOptionsFrameOkay"]:ClearAllPoints()
		_G["MacOptionsFrameOkay"]:SetWidth(96)
		_G["MacOptionsFrameOkay"]:SetHeight(22)
		_G["MacOptionsFrameOkay"]:SetPoint("LEFT",_G["MacOptionsFrameCancel"],-99,0)
 
		_G["MacOptionsButtonKeybindings"]:ClearAllPoints()
		_G["MacOptionsButtonKeybindings"]:SetWidth(96)
		_G["MacOptionsButtonKeybindings"]:SetHeight(22)
		_G["MacOptionsButtonKeybindings"]:SetPoint("LEFT",_G["MacOptionsFrameOkay"],-99,0)
 
		_G["MacOptionsFrameDefaults"]:SetWidth(96)
		_G["MacOptionsFrameDefaults"]:SetHeight(22)
	end
end)

if not TukuiCF["actionbar"].enable == true or IsAddOnLoaded("Skinner") then return end

--[[

    Shaman Totem Bar Skin by Darth Android / Telroth-Black Dragonflight
    This script skins the totem bar to fit TukUI.
    
]]

local buttonsize = TukuiDB.Scale(27)
local flyoutsize = TukuiDB.Scale(24)
local buttonspacing = TukuiDB.Scale(3)
local borderspacing = TukuiDB.Scale(2)

local bordercolors = {
	{.23,.45,.13},    -- Earth
	{.58,.23,.10},    -- Fire
	{.19,.48,.60},   -- Water
	{.42,.18,.74},   -- Air
	{.39,.39,.12}    -- Summon / Recall
}

local function SkinFlyoutButton(button)
	button.skin = CreateFrame("Frame",nil,button)
	TukuiDB.SetTemplate(button.skin)
	button.skin:SetBackdropBorderColor(button:GetParent():GetBackdropBorderColor())
	button:GetNormalTexture():SetTexture(nil)
	button:ClearAllPoints()
	button.skin:ClearAllPoints()
	button.skin:SetFrameStrata("LOW")

	button:SetWidth(buttonsize+borderspacing)
	button:SetHeight(buttonspacing*3 + borderspacing-1)
	button.skin:SetWidth(button:GetParent():GetWidth())
	button.skin:SetHeight(buttonspacing*2)
	if TukuiCF["others"].totembardirection == "DOWN" then
		button:SetPoint("TOP",button:GetParent(),"BOTTOM",0,1)    
		button.skin:SetPoint("BOTTOM",button,"BOTTOM",0,0)
	else
		button:SetPoint("BOTTOM",button:GetParent(),"TOP",0,-1)    
		button.skin:SetPoint("TOP",button,"TOP",0,0)	
	end

	button:GetHighlightTexture():SetTexture([[Interface\Buttons\ButtonHilight-Square]],"HIGHLIGHT")
	button:GetHighlightTexture():ClearAllPoints()
	button:GetHighlightTexture():SetPoint("TOPLEFT",button.skin,"TOPLEFT",borderspacing,-borderspacing)
	button:GetHighlightTexture():SetPoint("BOTTOMRIGHT",button.skin,"BOTTOMRIGHT",-borderspacing,borderspacing)
end

local function SkinActionButton(button, colorr, colorg, colorb)
	TukuiDB.SetTemplate(button)
	button:SetBackdropBorderColor(colorr,colorg,colorb)
	button:SetBackdropColor(0,0,0,0)
	button:ClearAllPoints()
	button:SetAllPoints(button.slotButton)
	button.overlay:SetTexture(nil)
	button:GetRegions():SetDrawLayer("ARTWORK")
end

local function SkinButton(button,colorr, colorg, colorb)
	TukuiDB.SetTemplate(button)
	if button.actionButton then
		TukuiDB.SetTemplate(button.actionButton)
		button.actionButton:SetPushedTexture("")
		button.actionButton:SetCheckedTexture("")
	end
	button.background:SetDrawLayer("ARTWORK")
	button.background:ClearAllPoints()
	button.background:SetPoint("TOPLEFT",button,"TOPLEFT",borderspacing,-borderspacing)
	button.background:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-borderspacing,borderspacing)
	button.overlay:SetTexture(nil)
	button:SetSize(TukuiDB.Scale(27),TukuiDB.Scale(27))
	button:SetBackdropBorderColor(colorr,colorg,colorb)
end

local function SkinSummonButton(button,colorr, colorg, colorb)
	local icon = select(1,button:GetRegions())
	icon:SetDrawLayer("ARTWORK")
	icon:ClearAllPoints()
	icon:SetPoint("TOPLEFT",button,"TOPLEFT",borderspacing,-borderspacing)
	icon:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-borderspacing,borderspacing)
	icon:SetTexCoord(.09,.91,.09,.91)

	select(12,button:GetRegions()):SetTexture(nil)
	select(7,button:GetRegions()):SetTexture(nil)
	TukuiDB.SetTemplate(button)
	button:SetSize(buttonsize,buttonsize)
	button:SetPushedTexture("")
	button:SetCheckedTexture("")
end

local function SkinFlyoutTray(tray)
	local parent = tray.parent
	local buttons = {select(2,tray:GetChildren())}
	local closebutton = tray:GetChildren()
	local numbuttons = 0


	for i,k in ipairs(buttons) do
		local prev = i > 1 and buttons[i-1] or tray

		if k:IsVisible() then numbuttons = numbuttons + 1 end

		if k.icon then
			k.icon:SetDrawLayer("ARTWORK")
			k.icon:ClearAllPoints()
			k.icon:SetPoint("TOPLEFT",k,"TOPLEFT",borderspacing,-borderspacing)
			k.icon:SetPoint("BOTTOMRIGHT",k,"BOTTOMRIGHT",-borderspacing,borderspacing)

			TukuiDB.SetTemplate(k)
			k:SetBackdropBorderColor(unpack(bordercolors[((parent.idx-1)%5)+1]))
			if k.icon:GetTexture() ~= [[Interface\Buttons\UI-TotemBar]] then
				k.icon:SetTexCoord(.09,.91,.09,.91)
			end
		end

		k:ClearAllPoints()
		k:SetPoint("BOTTOM",prev,"TOP",0,buttonspacing)
	end

	tray.middle:SetTexture(nil)
	tray.top:SetTexture(nil)
	TukuiDB.SetTemplate(tray)
	TukuiDB.SetTemplate(closebutton)
	tray:SetBackdropBorderColor(unpack(bordercolors[((parent.idx-1)%5)+1]))
	closebutton:SetBackdropBorderColor(unpack(bordercolors[((parent.idx-1)%5)+1]))
	closebutton:GetHighlightTexture():SetTexture([[Interface\Buttons\ButtonHilight-Square]])
	closebutton:GetHighlightTexture():SetPoint("TOPLEFT",closebutton,"TOPLEFT",borderspacing,-borderspacing)
	closebutton:GetHighlightTexture():SetPoint("BOTTOMRIGHT",closebutton,"BOTTOMRIGHT",-borderspacing,borderspacing)
	closebutton:GetNormalTexture():SetTexture(nil)
	
	tray:ClearAllPoints()
	closebutton:ClearAllPoints()
	
	tray:SetWidth(flyoutsize + buttonspacing*2)
	tray:SetHeight((flyoutsize+buttonspacing) * numbuttons + buttonspacing)
	closebutton:SetHeight(buttonspacing * 2)
	closebutton:SetWidth(tray:GetWidth())

	if TukuiCF["others"].totembardirection == "DOWN" then
		tray:SetPoint("TOP",parent,"BOTTOM",0,-buttonspacing + TukuiDB.Scale(-1))
		closebutton:SetPoint("TOP",tray,"BOTTOM",0,TukuiDB.Scale(-1))
	else
		tray:SetPoint("BOTTOM",parent,"TOP",0,buttonspacing + TukuiDB.Scale(1))
		closebutton:SetPoint("BOTTOM",tray,"TOP",0,TukuiDB.Scale(1))	
	end
	buttons[1]:SetPoint("BOTTOM",tray,"BOTTOM",0,buttonspacing)
end

function pack(...) return {...} end

local AddOn = CreateFrame("Frame")
local OnEvent = function(self, event, ...) self[event](self, event, ...) end
AddOn:SetScript("OnEvent", OnEvent)

function AddOn:PLAYER_ENTERING_WORLD()
	if select(2,UnitClass("player")) == "SHAMAN" then
		local bgframe = CreateFrame("Frame","TotemBG",MultiCastSummonSpellButton)
		TukuiDB.SetTemplate(bgframe)
		bgframe:SetHeight(buttonsize + buttonspacing*2)
		bgframe:SetWidth(buttonspacing + (buttonspacing + buttonsize)*6)
		bgframe:SetFrameStrata("LOW")
		bgframe:ClearAllPoints()

		bgframe:SetHeight(buttonsize + buttonspacing*2)
		bgframe:SetWidth(buttonspacing + (buttonspacing + buttonsize)*6)
		bgframe:SetPoint("BOTTOMLEFT",MultiCastSummonSpellButton,"BOTTOMLEFT",-buttonspacing,-buttonspacing)

		for i = 1,12 do
			if i < 6 then
				local button = _G["MultiCastSlotButton"..i] or MultiCastRecallSpellButton
				local prev = _G["MultiCastSlotButton"..(i-1)] or MultiCastSummonSpellButton
				prev.idx = i - 1
				if i == 1 or i == 5 then
					SkinSummonButton(i == 5 and button or prev,unpack(bordercolors[5]))
				end
				if i < 5 then
					SkinButton(button,unpack(bordercolors[((i-1) % 4) + 1]))
				end
				button:ClearAllPoints()
				ActionButton1.SetPoint(button,"LEFT",prev,"RIGHT",buttonspacing,0)
			end
			SkinActionButton(_G["MultiCastActionButton"..i],unpack(bordercolors[((i-1) % 4) + 1]))
		end
		MultiCastFlyoutFrame:HookScript("OnShow",SkinFlyoutTray)
		MultiCastFlyoutFrameOpenButton:HookScript("OnShow", function(self) if MultiCastFlyoutFrame:IsShown() then MultiCastFlyoutFrame:Hide() end SkinFlyoutButton(self) end)
		MultiCastFlyoutFrame:SetFrameLevel(4)
	end
end

AddOn:RegisterEvent("PLAYER_ENTERING_WORLD")
