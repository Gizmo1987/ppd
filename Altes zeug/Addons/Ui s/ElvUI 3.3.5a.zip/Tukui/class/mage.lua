-- credits: Foof and Tohveli

if TukuiDB.myclass ~= "MAGE" then return end

local TUKUI_HOVER = TukuiCF["media"].valuecolor
local TUKUI_NORMAL = TukuiCF["media"].bordercolor
 
if TukuiCF["others"].portals == true then


	if (UnitFactionGroup("player") == "Horde") then
		portals = {
			{ tukuilocal.dalaran },
			{ tukuilocal.orgrimmar },
			{ tukuilocal.undercity },
			{ tukuilocal.thunder_bluff },
			{ tukuilocal.silvermoon },
			{ tukuilocal.shattrath },
			{ tukuilocal.stonard },
		}
	else
		portals = {
			{ tukuilocal.dalaran },
			{ tukuilocal.ironforge },
			{ tukuilocal.stormwind },
			{ tukuilocal.darnassus },
			{ tukuilocal.exodar },
			{ tukuilocal.shattrath },
			{ tukuilocal.theramore },
		}
	end

	local buttons = {}

	function ToggleButtons()
		for idx, button in pairs(buttons) do
			if (button:IsShown()) then
				button:Hide()
			else
				button:Show()
			end
		end
	end

	local menu
	do
		menu = CreateFrame("Button", "TukuiPortalsMenuButton", UIParent)
		TukuiDB.CreatePanel(menu, TukuiMinimap:GetWidth() + 4, 20, "CENTER")
		
		menu:SetFrameStrata("HIGH")
		menu:EnableMouse(true)
		menu:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(unpack(TUKUI_HOVER)) end)
		menu:SetScript("OnLeave", function(self) self:SetBackdropBorderColor(unpack(TUKUI_NORMAL)) end)
		menu:SetScript("OnClick", ToggleButtons)
		menu:RegisterForClicks("AnyUp")

		menu.text = menu:CreateFontString(nil, "OVERLAY")
		menu.text:SetFont(TukuiCF["media"].font, 12)
		menu.text:SetPoint("CENTER", 0, 0)
		local function Update()
			if RaidBuffReminder and not InCombatLockdown() then
				if RaidBuffReminder:GetAlpha() ~= 0 then
					menu:SetPoint("TOPLEFT", RaidBuffReminder, "BOTTOMLEFT", 0, -TukuiDB.Scale(3))
				else
					menu:SetPoint("TOPLEFT", TukuiMinimapStatsLeft, "BOTTOMLEFT", 0, -TukuiDB.Scale(3))
				end
			else
				menu:SetPoint("TOPLEFT", TukuiMinimapStatsLeft, "BOTTOMLEFT", 0, -TukuiDB.Scale(3))
			end
			local RoP = GetItemCount(17031)
			local RoT = GetItemCount(17032) 
			menu.text:SetText(valuecolor..RoP.." |r- Portals - "..valuecolor..RoT)
		end
		menu:SetScript("OnUpdate", Update)
		Update(menu, 10)
	end

	local CreateButton
	do
		CreateButton = function(name, anchor, func)
		local button = CreateFrame("Button", "TukuiPortalsButton" .. #buttons + 1, menu, "SecureActionButtonTemplate")
		TukuiDB.CreatePanel(button, menu:GetWidth(), menu:GetHeight(), "TOP", anchor, "BOTTOM", 0, -3)
		button:SetFrameStrata("HIGH")
		button:EnableMouse(true)
		button:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(unpack(TUKUI_HOVER)) end)
		button:SetScript("OnLeave", function(self) self:SetBackdropBorderColor(unpack(TUKUI_NORMAL)) end)
		button:RegisterForClicks("LeftButtonDown", "RightButtonDown")
		button:SetAttribute("type1", "spell")
		button:SetAttribute("spell1", tukuilocal.teleport..name)
		button:SetAttribute("type2", "spell")
		button:SetAttribute("spell2", tukuilocal.portal..name)
		
		button:RegisterEvent("UNIT_SPELLCAST_START");
		button:SetScript("OnEvent",
		function(self)
			if self:IsShown() then
				self:Hide()
			end
		end)
		
		button.text = button:CreateFontString(nil, "OVERLAY")
		button.text:SetFont(TukuiCF["media"].font, 12)
		button.text:SetPoint("CENTER", 0, 0)
		button.text:SetText(name)
		
		button:Hide()
		tinsert(buttons, button)
		end
	end

	--We don't need to see this in combat..
	local menushown = true
	local function OnEvent(self, event)
		if event == "PLAYER_REGEN_DISABLED" then
			if menushown == true then
				UIFrameFadeOut(menu, 0.5)
				menu:EnableMouse(false)
				for i=1, 7 do
					_G["TukuiPortalsButton"..i]:EnableMouse(false)
				end
				menushown = false
			end
		elseif event == "PLAYER_REGEN_ENABLED" then
			if menushown == false then
				UIFrameFadeIn(menu, 0.5)
				menu:EnableMouse(true)
				for i=1, 7 do
					_G["TukuiPortalsButton"..i]:EnableMouse(true)
				end
				menushown = true				
			end		
		end
	end
	menu:RegisterEvent("PLAYER_REGEN_ENABLED")
	menu:RegisterEvent("PLAYER_REGEN_DISABLED")
	menu:SetScript("OnEvent", OnEvent)


	for idx, button in pairs(portals) do
		local anchor = menu
		if (#buttons > 0) then
			anchor = buttons[#buttons]
		end
		CreateButton(button[1], anchor, button[2])
	end
end


local spellStealerText = CreateFrame("Frame")
local function OnTextEvent(self, event, ...)
	if (event == "COMBAT_LOG_EVENT_UNFILTERED")	 then
		local cEvent, sourceGUID, sourceName, _, destGUID, destName, _ = select(2, ...)
		local spellID = select(12,...)
	
		if (cEvent == "SPELL_STOLEN" and sourceGUID == UnitGUID("player")) then
			if(GetCVar("enableCombatText") == '1') then
				CombatText_AddMessage("Stole:"..GetSpellLink(spellID), CombatText_StandardScroll, 0.10, 0, 1, "sticky", nil);
			end
		end
	end
end
spellStealerText:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
spellStealerText:SetScript("OnEvent", OnTextEvent)