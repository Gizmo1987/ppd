--------------------------------------------------------------------
-- BGScore (original feature by elv22, edited by Tukz)
--------------------------------------------------------------------

if TukuiCF["datatext"].battleground == true and not TukuiCF["general"].minimalistic == true then
	local Stat = CreateFrame("Frame")
	Stat:EnableMouse(true)
	
	local Text1  = TukuiInfoLeftBattleGround:CreateFontString(nil, "OVERLAY")
	Text1:SetFont(TukuiCF.media.font, TukuiCF["datatext"].fontsize)
	Text1:SetPoint("LEFT", TukuiInfoLeftBattleGround, 30, 0.5)
	Text1:SetHeight(TukuiInfoLeft:GetHeight())

	local Text2  = TukuiInfoLeftBattleGround:CreateFontString(nil, "OVERLAY")
	Text2:SetFont(TukuiCF.media.font, TukuiCF["datatext"].fontsize)
	Text2:SetPoint("CENTER", TukuiInfoLeftBattleGround, 0, 0.5)
	Text2:SetHeight(TukuiInfoLeft:GetHeight())

	local Text3  = TukuiInfoLeftBattleGround:CreateFontString(nil, "OVERLAY")
	Text3:SetFont(TukuiCF.media.font, TukuiCF["datatext"].fontsize)
	Text3:SetPoint("RIGHT", TukuiInfoLeftBattleGround, -30, 0.5)
	Text3:SetHeight(TukuiInfoLeft:GetHeight())
	
	local Text4  = TukuiInfoLeftBattleGround:CreateFontString(nil, "OVERLAY")
	Text4:SetFont(TukuiCF.media.font, TukuiCF["datatext"].fontsize)
	Text4:SetPoint("LEFT", TukuiInfoRightBattleGround, 30, 0.5)
	Text4:SetHeight(TukuiInfoLeft:GetHeight())

	local Text5  = TukuiInfoLeftBattleGround:CreateFontString(nil, "OVERLAY")
	Text5:SetFont(TukuiCF.media.font, TukuiCF["datatext"].fontsize)
	Text5:SetPoint("CENTER", TukuiInfoRightBattleGround, 0, 0.5)
	Text5:SetHeight(TukuiInfoLeft:GetHeight())

	local Text6  = TukuiInfoLeftBattleGround:CreateFontString(nil, "OVERLAY")
	Text6:SetFont(TukuiCF.media.font, TukuiCF["datatext"].fontsize)
	Text6:SetPoint("RIGHT", TukuiInfoRightBattleGround, -30, 0.5)
	Text6:SetHeight(TukuiInfoLeft:GetHeight())

	local int = 1
	local function Update(self, t)
		int = int - t
		if int < 0 then
			RequestBattlefieldScoreData()
			local numScores = GetNumBattlefieldScores()
			for i=1, numScores do
				name, killingBlows, honorKills, deaths, honorGained, faction, rank, race, class, classToken, damageDone, healingDone  = GetBattlefieldScore(i);
				if ( name ) then
					if ( name == UnitName("player") ) then
						Text1:SetText(tukuilocal.datatext_damage..valuecolor..damageDone)
						Text2:SetText(tukuilocal.datatext_honor..valuecolor..honorGained)
						Text3:SetText(tukuilocal.datatext_killingblows..valuecolor..killingBlows)
						Text4:SetText(tukuilocal.datatext_ttdeaths..valuecolor..deaths)
						Text5:SetText(tukuilocal.datatext_tthonorkills..valuecolor..honorKills)
						Text6:SetText(tukuilocal.datatext_healing..valuecolor..healingDone)
					end   
				end
			end 
			int  = 1
		end
	end
	
	--hide text when not in an bg
	local function OnEvent(self, event)
		if event == "PLAYER_ENTERING_WORLD" then
			inInstance, instanceType = IsInInstance()
			if (not inInstance) or (instanceType == "none") then
				Text1:SetText("")
				Text2:SetText("")
				Text3:SetText("")
			end
		end
	end
	
	Stat:RegisterEvent("PLAYER_ENTERING_WORLD")
	Stat:SetScript("OnEvent", OnEvent)
	Stat:SetScript("OnUpdate", Update)
	Update(Stat, 10)
end