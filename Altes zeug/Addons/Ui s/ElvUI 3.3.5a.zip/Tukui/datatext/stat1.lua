-----------------------------------------
-- Stat 1 
-----------------------------------------

if TukuiCF["datatext"].stat1 and TukuiCF["datatext"].stat1 > 0 and not TukuiCF["general"].minimalistic == true then
	local Stat = CreateFrame("Frame")
	Stat:EnableMouse(true)
	Stat:SetFrameStrata("BACKGROUND")
	Stat:SetFrameLevel(3)

	local Text  = TukuiInfoLeft:CreateFontString(nil, "LOW")
	Text:SetFont(TukuiCF.media.font, TukuiCF["datatext"].fontsize)
	TukuiDB.PP(TukuiCF["datatext"].stat1, Text)
	
	local int = 1	
	local function Update(self, t)
		int = int - t
		if int < 0 then
			if TukuiDB.Role == "Tank" then
				if TukuiCF["datatext"].stat1tankstat == "avd" then
					local format = string.format
					local targetlv, playerlv = UnitLevel("target"), UnitLevel("player")
					if targetlv == -1 then
						basemisschance = (5 - (3*.2))  --Boss Value
						leveldifference = 3
					elseif targetlv > playerlv then
						basemisschance = (5 - ((targetlv - playerlv)*.2)) --Mobs above player level
						leveldifference = (targetlv - playerlv)
					elseif targetlv < playerlv and targetlv > 0 then
						basemisschance = (5 + ((playerlv - targetlv)*.2)) --Mobs below player level
						leveldifference = (targetlv - playerlv)
					else
						basemisschance = 5 --Sets miss chance of attacker level if no target exists, lv80=5, 81=4.2, 82=3.4, 83=2.6
						leveldifference = 0
					end

					if leveldifference >= 0 then
						dodge = (GetDodgeChance()-leveldifference*.2)
						parry = (GetParryChance()-leveldifference*.2)
						block = (GetBlockChance()-leveldifference*.2)
						MissChance = (basemisschance + 1/(0.0625 + 0.956/(GetCombatRating(CR_DEFENSE_SKILL)/4.91850*0.04)))
						avoidance = (dodge+parry+block+MissChance)	
					else
						dodge = (GetDodgeChance()+abs(leveldifference*.2))
						parry = (GetParryChance()+abs(leveldifference*.2))
						block = (GetBlockChance()+abs(leveldifference*.2))
						MissChance = (basemisschance + 1/(0.0625 + 0.956/(GetCombatRating(CR_DEFENSE_SKILL)/4.91850*0.04)))
						avoidance = (dodge+parry+block+MissChance)
					end
					
					Text:SetText(tukuilocal.datatext_playeravd..valuecolor..format("%.2f", avoidance))
					--Setup Avoidance Tooltip
					self:SetAllPoints(Text)
					self:SetScript("OnEnter", function()
						if TukuiDB.Role == "Tank" then
							GameTooltip:SetOwner(this, "ANCHOR_TOP", 0, TukuiDB.Scale(6));
							GameTooltip:ClearAllPoints()
							GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, TukuiDB.mult)
							GameTooltip:ClearLines()
							if targetlv > 1 then
								GameTooltip:AddDoubleLine(tukuilocal.datatext_avoidancebreakdown," ("..tukuilocal.datatext_lvl.." "..targetlv..")")
							elseif targetlv == -1 then
								GameTooltip:AddDoubleLine(tukuilocal.datatext_avoidancebreakdown," ("..tukuilocal.datatext_boss..")")
							else
								GameTooltip:AddDoubleLine(tukuilocal.datatext_avoidancebreakdown," ("..tukuilocal.datatext_lvl.." "..playerlv..")")
							end
							GameTooltip:AddLine' '
							GameTooltip:AddDoubleLine(tukuilocal.datatext_miss,format("%.2f",MissChance) .. "%",1,1,1)
							GameTooltip:AddDoubleLine(tukuilocal.datatext_dodge,format("%.2f",dodge) .. "%",1,1,1)
							GameTooltip:AddDoubleLine(tukuilocal.datatext_parry,format("%.2f",parry) .. "%",1,1,1)
							GameTooltip:AddDoubleLine(tukuilocal.datatext_block,format("%.2f",block) .. "%",1,1,1)
							GameTooltip:Show()
						end
					end)
					self:SetScript("OnLeave", function() GameTooltip:Hide() end)			
				elseif TukuiCF["datatext"].stat1tankstat == "armor" then
					local baseArmor , effectiveArmor, armor, posBuff, negBuff = UnitArmor("player");
					Text:SetText("Armor: "..valuecolor..(effectiveArmor))
					--Setup Armor Tooltip
					self:SetAllPoints(Text)
					self:SetScript("OnEnter", function()
					
						if TukuiDB.Role == "Tank" then
							GameTooltip:SetOwner(this, "ANCHOR_TOP", 0, TukuiDB.Scale(6));
							GameTooltip:ClearAllPoints()
							GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, TukuiDB.mult)
							GameTooltip:ClearLines()
							GameTooltip:AddLine(tukuilocal.datatext_mitigation)
							GameTooltip:AddLine(' ')
							local lv = 83
							for i = 1, 4 do
								local format = string.format
								local mitigation = (effectiveArmor/(effectiveArmor+(467.5*lv-22167.5)));
								if mitigation > .75 then
									mitigation = .75
								end
								GameTooltip:AddDoubleLine(lv,format("%.2f", mitigation*100) .. "%",1,1,1)
								lv = lv - 1
							end
							if UnitLevel("target") > 0 and UnitLevel("target") < UnitLevel("player") then
								mitigation = (effectiveArmor/(effectiveArmor+(467.5*(UnitLevel("target"))-22167.5)));
								if mitigation > .75 then
									mitigation = .75
								end
								GameTooltip:AddDoubleLine(UnitLevel("target"),format("%.2f", mitigation*100) .. "%",1,1,1)
							end
							GameTooltip:Show()
						end
					end)
					self:SetScript("OnLeave", function() GameTooltip:Hide() end)				
				end
			elseif TukuiDB.Role == "Caster" then
				if TukuiCF["datatext"].stat1casterstat == "sp" then
					if GetSpellBonusHealing() > GetSpellBonusDamage(7) then
						spellpwr = GetSpellBonusHealing()
					else
						spellpwr = GetSpellBonusDamage(7)
					end
					
					Text:SetText(tukuilocal.datatext_playersp.." "..valuecolor..spellpwr)      
					
				elseif TukuiCF["datatext"].stat1casterstat == "crit" then
					Text:SetText(tukuilocal.datatext_playercrit.." "..valuecolor..format("%.2f", GetSpellCritChance(1)) .. "%")
					
				elseif TukuiCF["datatext"].stat1casterstat == "haste" then
					Text:SetText(tukuilocal.datatext_playerhaste.." "..valuecolor..GetCombatRating(20))
					
				end
			elseif TukuiDB.Role == "Melee" then
				if TukuiCF["datatext"].stat1meleestat == "ap" then	
					local base, posBuff, negBuff = UnitAttackPower("player");
					local effective = base + posBuff + negBuff;
					local Rbase, RposBuff, RnegBuff = UnitRangedAttackPower("player");
					local Reffective = Rbase + RposBuff + RnegBuff;
					local pwr
					
					if select(2, UnitClass("Player")) == "HUNTER" then
						pwr = Reffective
					else
						pwr = effective
					end
				
					Text:SetText(tukuilocal.datatext_playerap.." "..valuecolor..pwr)      
		
				elseif TukuiCF["datatext"].stat1meleestat == "crit" then	
					local meleecrit = GetCritChance()
					local rangedcrit = GetRangedCritChance()
					local CritChance
					
					if select(2, UnitClass("Player")) == "HUNTER" then    
						CritChance = rangedcrit
					else
						CritChance = meleecrit
					end

					Text:SetText(tukuilocal.datatext_playercrit.." "..valuecolor..format("%.2f", CritChance) .. "%")
				
				elseif TukuiCF["datatext"].stat1meleestat == "arp" then	
					Text:SetText(tukuilocal.datatext_playerarp.." "..valuecolor..GetCombatRating(25))
					
				elseif TukuiCF["datatext"].stat1meleestat == "haste" then	
					if select(2, UnitClass("Player")) == "HUNTER" then
						haste = GetCombatRating(19)
					else
						haste = GetCombatRating(18)
					end
				
					Text:SetText(tukuilocal.datatext_playerhaste.." "..valuecolor..haste)
					
				end
			end
			int = 1
		end
	end
	
	Stat:SetScript("OnUpdate", Update)
	Update(Stat, 10)
end