--------------------------------------------------------------------
-- SUPPORT FOR TPS Feed... 
--------------------------------------------------------------------
if not TukuiDB.IsElvsEdit then
	valuecolor = "|cffFFFFFF"
	function round(number, decimals)
		return (("%%.%df"):format(decimals)):format(number)
	end
end

if TukuiCF["datatext"].tps_text and TukuiCF["datatext"].tps_text > 0 and not TukuiCF["general"].minimalistic == true then
	local TPS_FEED = CreateFrame("Frame")
	local cmbt_time = 0
	
	tText = TukuiInfoLeft:CreateFontString(nil, "LOW")
	tText:SetFont(TukuiCF.media.font, TukuiCF["datatext"].fontsize)
	tText:SetText("TPS: "..valuecolor.."0")

	TukuiDB.PP(TukuiCF["datatext"].tps_text, tText)

	TPS_FEED:EnableMouse(true)
	TPS_FEED:SetHeight(TukuiDB.Scale(20))
	TPS_FEED:SetWidth(TukuiDB.Scale(100))
	TPS_FEED:SetAllPoints(tText)

	TPS_FEED:SetScript("OnUpdate", function(self, elap)
		if UnitDetailedThreatSituation("player", "target") then
			local threatOnTarget = (select(5, UnitDetailedThreatSituation("player", "target")))/100
			local tpsOnTarget = round((threatOnTarget/(GetTime()-cmbt_time)))
			tText:SetText("TPS: "..valuecolor..tpsOnTarget)
		else
			tText:SetText("TPS: "..valuecolor.."0")
		end
	end)
     	
	local function OnEvent(self, event)
		if event == "PLAYER_REGEN_ENABLED" then
			cmbt_time = 0
		end
		if event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_TARGET_CHANGED" then
			cmbt_time = GetTime()	
		end
	end
     
	TPS_FEED:RegisterEvent("PLAYER_REGEN_ENABLED")
	TPS_FEED:RegisterEvent("PLAYER_REGEN_DISABLED")
	TPS_FEED:RegisterEvent("PLAYER_TARGET_CHANGED")
	TPS_FEED:SetScript("OnEvent", OnEvent)
end